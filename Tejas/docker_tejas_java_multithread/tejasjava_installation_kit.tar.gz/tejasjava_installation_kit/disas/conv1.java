import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.StringTokenizer; 
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.File;
import java.io.PrintWriter;
import java.io.OutputStreamWriter;
import java.io.Writer;

public class conv1 {

public static String padRight(String s, int n)
{
	return String.format("%1$-" +n +"s",s);
}

 
public static void main(String[] args) {


 try
  {
  int eip_prev=-1, eip_curr=0, eip_next=1, flag1=0;
  FileInputStream in = new FileInputStream("out_trace.txt");
  BufferedReader br = new BufferedReader(new InputStreamReader(in));
  String s1, s2;

  File statText = new File("fin_trace.txt_0");
  FileOutputStream is = new FileOutputStream(statText);
  OutputStreamWriter osw = new OutputStreamWriter(is);    
  Writer w = new BufferedWriter(osw);

  FileInputStream in_temp = new FileInputStream("temp_file1.txt");
  BufferedReader br_temp = new BufferedReader(new InputStreamReader(in_temp));
  String eip="";
  while((s1 = br_temp.readLine())!= null)
	{
	    s2 = br.readLine();
	    StringTokenizer st = new StringTokenizer(s2, "...."); 
	    String l_s = st.nextToken();
	    eip = st.nextToken();
	
	    eip_prev = eip_curr;
	    eip_curr = Integer.parseInt(eip);

	    if(flag1 ==1){
		if(eip_curr == (eip_prev + 1)){
			w.write(eip + " 5 " + "100\n");
		}
		else{
			w.write(eip + " 4 " + "100\n");
		}
		flag1 = 0;
	    }

	    if(s1.charAt(0)=='j' && (s1.charAt(1)=='a' || s1.charAt(1)=='l' || s1.charAt(1)=='z' || s1.charAt(1)=='s') ){
		flag1 = 1;
	    }		
	    String address = st.nextToken();
	    w.write(eip + " 27 "+ padRight(s1,63) + "\n");
	    
	    if(!address.equals("          ")){
		w.write(eip + " " + l_s +" "+ Long.parseLong(address.substring(2), 16) + "\n");
	    }
	}
  w.write(eip + " -1 " + "100\n");
  w.close();
  }
  catch(Exception e){
   System.out.println(e);
  }


}

}
