import os
import sys

file = open(sys.argv[1], 'r')
file1 = open('temp_file.txt','w')
file2 = open('out_trace.txt','w')
list1 ={}
for line in file:
	line = line.strip()
  	cols = line.split()
	if( cols[0] == '1'):
		if(cols[3] in list1):
			if(int(list1[cols[3]]) < int(cols[4])):
				list1[int(cols[3])] = int(cols[4])
		else:
			list1[int(cols[3])] = int(cols[4])
print list1
keys = sorted(list1.keys())
for k in range(1, len(keys)):
		list1[keys[k]] = list1[keys[k-1]] + list1[keys[k]] + 1
print list1
file.seek(0, 0)
ip = ' 0 '
prevLine = "........."
for line in file:
	line = line.strip()
  	cols = line.split()
	if( cols[0] == '1'):

		s = cols[1]
		if( s[0:2]=='0x'):
			a1 = s[8:]+' ' + s[6:8] + ' ' + s[4:6] + ' ' + s[2:4]
		
		else:
			a = hex(int(s))
			a = a[2:]
			a = a.rjust(8, '0')
			a1 = a[6:]+' ' + a[4:6] + ' ' + a[2:4] + ' ' + a[0:2]
			

		s = cols[2]
		if( s[0:2]=='0x'):
			a2 = s[8:]+' ' + s[6:8] + ' ' + s[4:6] + ' ' + s[2:4]
		
		else:
			a = hex(int(s))
			a = a[2:]
			a = a.rjust(8, '0')
			a2 = a[6:]+' ' + a[4:6] + ' ' + a[2:4] + ' ' + a[0:2]
		
		if(int(cols[3]) - 1 in list1):
			ip = list1[int(cols[3])-1] + int(cols[4]) + 1
		else:
			ip = cols[4]
		#print ip
				
		file1.write(a1 + ' ' + a2 + '\n')
		
		cols = prevLine.split()
		if( cols[0] =='2' or cols[0] =='3'):
			file2.write(cols[0] + '....' + str(ip) + '....' + cols[1] + '\n')
		else:
			file2.write('0' + '....' + str(ip) + '....' + '          ' + '\n')
	prevLine = line
	
			
