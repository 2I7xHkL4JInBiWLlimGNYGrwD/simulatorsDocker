#include <udis86.h>
#include <bits/stdc++.h>
using namespace std;

FILE* fptr = NULL;
ifstream in;
ofstream out;
string line;
int input_hook_x(ud_t* u);

int eol(int c, FILE *stream)
{
        if (c == '\n')
                return 1;
        if (c == '\r') {
                if ((c = getc(stream)) != '\n')
                        ungetc(c, stream);
                return 1;
        }
        return 0;
}


int skipline(FILE *stream)
{
        int c;

        while ((c = getc(stream)) != EOF && !eol(c, stream))
                ;
        return c == EOF;
}

int main()
{
  in.open("temp_file.txt");
  out.open("temp_file1.txt");
    
    //fptr = stdin;
    ud_t ud_obj;

    ud_init(&ud_obj);
    //  ud_set_input_file(&ud_obj, stdin);
    ud_set_mode(&ud_obj, 32);
    ud_set_syntax(&ud_obj, UD_SYN_INTEL);
   //char label[20] = "ffb6dc000000";
   //ud_set_input_buffer(&ud_obj, label, 20);

    ud_set_input_hook(&ud_obj, input_hook_x);

    while(ud_disassemble(&ud_obj)) {    
      //fprintf(fp,"%s\n", ud_insn_asm(&ud_obj));
      out << ud_insn_asm(&ud_obj)<<"\n";
      //skipline(fptr);
      getline(in, line);
    }
    return 0;
} 

int input_hook_x(ud_t* u)
{
  unsigned int c, i;

  //i = fscanf(fptr, "%x", &c);
  in >> line;
  c = stoul(line, nullptr, 16);
  if(in.eof())
    return UD_EOI;
  /*if (i == EOF)
	return UD_EOI;
  if (i == 0) {
	fprintf(stderr, "Error: Invalid input, should be in hexadecimal form (8-bit).\n");
	return UD_EOI;
	}*/
  if (c > 0xFF)
	fprintf(stderr, "Warning: Casting non-8-bit input (%x), to %x.\n", c, c & 0xFF);
  return (int) (c & 0xFF);
}	

