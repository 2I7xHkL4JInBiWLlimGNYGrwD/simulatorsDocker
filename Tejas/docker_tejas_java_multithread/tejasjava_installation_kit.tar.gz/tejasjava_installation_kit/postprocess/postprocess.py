import os
import sys

flag = 0
file = open(sys.argv[1], 'r')
file1 = open('trace_file.txt','w')
prevLine = " "
pprevLine = " "
ppprevLine = " "
for line in file:
	line = line.strip()
	if('push dword 0xbee' in line):
                if(flag == 1):
			cols = prevLine.split();
			if(cols[1]=='2' or cols[1]=='3'):
				line = cols[0] + ' ' + '37' + ' ' + cols[2]
				flag = 0
			else:	
				cols = pprevLine.split();
				if(cols[1]=='2' or cols[1]=='3'):
					line = cols[0] + ' ' + '37' + ' ' + cols[2]
					flag = 0
				else:	
					cols = ppprevLine.split();
					if(cols[1]=='2' or cols[1]=='3'):
						line = cols[0] + ' ' + '37' + ' ' + cols[2]
						flag = 0		
					#print pprevLine
					#print prevLine
					#print line
				 	else:
						##print ppprevLine
						#print pprevLine
						#print prevLine
						#print line
						print 'Invalid Address1'
		else:
   			#remove that line  push dword 0xbee
			flag = 1

	if('push dword 0xdea' in line):
			cols = prevLine.split();
			if(cols[1]=='2' or cols[1]=='3'):
				line = cols[0] + ' ' + '38' + ' ' + cols[2]
				#print line
			else:	
				cols = pprevLine.split();
				if(cols[1]=='2' or cols[1]=='3'):
					line = cols[0] + ' ' + '38' + ' ' + cols[2]
				else:
					cols = ppprevLine.split();
					if(cols[1]=='2' or cols[1]=='3'):
						line = cols[0] + ' ' + '38' + ' ' + cols[2] 

					else :
						#print ppprevLine
						#print pprevLine
						#print prevLine
						#print line
						print 'Invalid Address'

	if('push dword 0xdee' in line):
			cols = prevLine.split();
			if(cols[1]=='2' or cols[1]=='3'):
				line = cols[0] + ' ' + '39' + ' ' + cols[2]
				#print line
			else:			
				cols = pprevLine.split();
				if(cols[1]=='2' or cols[1]=='3'):
					line = cols[0] + ' ' + '39' + ' ' + cols[2]
				else:
					cols = ppprevLine.split();
					if(cols[1]=='2' or cols[1]=='3'):
						line = cols[0] + ' ' + '39' + ' ' + cols[2]

					else:
						#print ppprevLine
						#print pprevLine
						#print prevLine
						#print line
						print 'Invalid Address'

        file1.write(line + '\n');
	ppprevLine = pprevLine
	pprevLine = prevLine
	prevLine = line
	
 
