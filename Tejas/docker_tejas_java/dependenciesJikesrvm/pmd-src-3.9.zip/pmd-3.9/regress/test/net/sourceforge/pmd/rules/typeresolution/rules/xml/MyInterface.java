package test.net.sourceforge.pmd.rules.typeresolution.rules.xml;

public interface MyInterface extends Cloneable {

}
