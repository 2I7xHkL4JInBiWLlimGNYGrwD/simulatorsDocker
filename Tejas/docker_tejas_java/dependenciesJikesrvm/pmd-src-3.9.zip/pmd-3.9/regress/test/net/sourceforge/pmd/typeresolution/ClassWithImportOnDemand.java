package test.net.sourceforge.pmd.typeresolution;

import java.util.*;

public class ClassWithImportOnDemand {

    public List foo() {
        return new ArrayList();
    }
}
