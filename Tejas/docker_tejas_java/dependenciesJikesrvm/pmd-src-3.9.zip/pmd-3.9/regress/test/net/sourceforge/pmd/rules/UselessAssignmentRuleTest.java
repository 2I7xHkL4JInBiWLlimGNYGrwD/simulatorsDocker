
 package test.net.sourceforge.pmd.rules;
 
 import net.sourceforge.pmd.Rule;
 import test.net.sourceforge.pmd.testframework.SimpleAggregatorTst;
 
 public class UselessAssignmentRuleTest extends SimpleAggregatorTst {
     private Rule rule;
 
     public void setUp() {
         //rule = findRule("rulesets/scratchpad.xml", "UselessAssignment");
     }
 
     public void testAll() {
         //FIXME: runTests(rule);
     }
 }
