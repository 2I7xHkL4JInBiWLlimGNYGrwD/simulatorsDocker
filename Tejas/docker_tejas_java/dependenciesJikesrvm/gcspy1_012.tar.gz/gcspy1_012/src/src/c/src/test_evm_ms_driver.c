/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  gcspy_test_ms_driver.c
 **
 **  Tests the MS Driver
 **/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "evm_ms_driver.h"
#include "evm_fl_driver.h"
#include "gcspy_main_server.h"
#include "gcspy_timer.h"

#ifdef _SPARC_
#include <thread.h>
#endif //_SPARC_

#ifdef _LINUX_
#include <pthread.h>
#endif //_LINUX_

#define MAX_LEN      ( 64 * 1024 )
#define TILE_SIZE    ( 32 * 1024 )

static gcspy_main_server_t server;
static ms_driver_t msDriver;
static fl_driver_t flDriver;

#define FULL ( 512 * 1024 )
#define HALF ( 256 * 1024 )
#define ONE  0
#define TWO ( 512 * 1024 )
#define THREE ( 1024 * 1024 )
#define FOUR ( (1024 + 512) * 1024 )
#define FIVE ( 2 * 1024 * 1024 )
#define CARD_SIZE  1024

#define MARKING_EVENT      0
#define SWEEPING_EVENT     1

#ifdef  __cplusplus
extern "C" {
#endif //__cplusplus
static void *
mainLoop (void *arg) {
  int event = MARKING_EVENT;

  while ( 1 ) {
    gcspy_wait(500);

    if (gcspy_mainServerIsConnected(&server, event)) {
      gcspy_mainServerStartCompensationTimer(&server);

      flDriverZero(&flDriver);
      msDriverZero(&msDriver, (char *) (FIVE + FULL));

      msDriverFreeChunk(&msDriver, (char *) ONE, 100);
      msDriverFreeChunk(&msDriver, (char *) TWO - 100, 100);
      msDriverFreeChunk(&msDriver, (char *) TWO + 1000, FULL);
      msDriverFreeChunk(&msDriver, (char *) FOUR - 1000, 2 * FULL + 1000);

      msDriverObject(&msDriver, (char *) ONE + 200, 100);
      msDriverObject(&msDriver, (char *) TWO + HALF, FULL);
      msDriverObject(&msDriver, (char *) FOUR - 1000, 2 * FULL);

      msDriverCard(&msDriver, (char *) ONE, CARD_SIZE,
		   MS_CARD_STATE_DIRTY);
      msDriverCard(&msDriver, (char *) ONE + CARD_SIZE, CARD_SIZE,
		   MS_CARD_STATE_CLEAN);

      msDriverCard(&msDriver, (char *) TWO, CARD_SIZE,
		   MS_CARD_STATE_SUMMARISED);
      msDriverCard(&msDriver, (char *) TWO + CARD_SIZE, CARD_SIZE,
		   MS_CARD_STATE_CLEAN);

      msDriverCard(&msDriver, (char *) THREE, CARD_SIZE,
		   MS_CARD_STATE_SUMMARISED);
      msDriverCard(&msDriver, (char *) THREE + CARD_SIZE, CARD_SIZE,
		   MS_CARD_STATE_CLEAN);
      msDriverCard(&msDriver, (char *) THREE + 2*CARD_SIZE, CARD_SIZE,
		   MS_CARD_STATE_DIRTY);

      msDriverCard(&msDriver, (char *) FOUR, CARD_SIZE,
		   MS_CARD_STATE_SUMMARISED);
      msDriverCard(&msDriver, (char *) FOUR + CARD_SIZE, CARD_SIZE,
		   MS_CARD_STATE_DIRTY);

      msDriverMarked(&msDriver, (char *) ONE);
      msDriverMarked(&msDriver, (char *) ONE + 200);
      msDriverMarked(&msDriver, (char *) ONE + 300);
      msDriverMarked(&msDriver, (char *) TWO);

      flDriverFreeChunk(&flDriver, 0, 1);
      flDriverFreeChunk(&flDriver, 0, 1);
      flDriverFreeChunk(&flDriver, 0, 1);
      flDriverFreeChunk(&flDriver, 2, 3);
      flDriverFreeChunk(&flDriver, 3, 4);
      flDriverFreeChunk(&flDriver, 3, 6);
      flDriverFreeChunk(&flDriver, 4, 10);
      flDriverFreeChunk(&flDriver, 5, 30);

      gcspy_mainServerStopCompensationTimer(&server);

      if (gcspy_mainServerIsConnected(&server, event)) {
	printf("CONNECTED\n");
	flDriverSend(&flDriver, event);
	msDriverSend(&msDriver, event);
      }
    }
    gcspy_mainServerSafepoint(&server, event);
    if (event == MARKING_EVENT)
      event = SWEEPING_EVENT;
    else
      event = MARKING_EVENT;
  }
}
#ifdef  __cplusplus
}
#endif //__cplusplus

int
main (int argc, char *argv[]) {
  char generalInfo[256];
  gcspy_date_time_t time;

#ifdef _SPARC_
  thread_t tid;
#endif //_SPARC_

#ifdef _LINUX_
  pthread_t tid;
#endif //_LINUX_

  gcspy_gc_driver_t *driver;
  int port;
  int res;

  if (argc != 2) {
    gcspy_raise_error("Wrong number of arguments");
  }
  port = atoi(argv[1]);

  printf("-- Initialising main server on port %d\n", port);
  gcspy_mainServerInit(&server, port, MAX_LEN, "M&S Driver Test", 1);

  time = gcspy_getDateTime();
  strcpy(generalInfo, "GCspy Test\n\n");
  strcat(generalInfo, "Start Time:\n  ");
  strcat(generalInfo, gcspy_formatDateTime(time));
  strcat(generalInfo, "\nApplication:\n  M&S Driver Test\n\n");
  strcat(generalInfo, "2 Spaces");
  gcspy_mainServerSetGeneralInfo(&server, generalInfo);

  printf("--   Setting event 0\n");
  gcspy_mainServerAddEvent(&server, MARKING_EVENT, "Marking Phase");
  printf("--   Setting event 1\n");
  gcspy_mainServerAddEvent(&server, SWEEPING_EVENT, "Sweeping Phase");

  printf("--   Setting up driver 0\n");
  driver = gcspy_mainServerAddDriver(&server);
  flDriverInit(&flDriver, driver, 
	       "Single Generation",
	       6, 1024 * 1024);
  flDriverSetTileNameExact(&flDriver, 0, 1);
  flDriverSetTileNameExact(&flDriver, 1, 2);
  flDriverSetTileNameExact(&flDriver, 2, 3);
  flDriverSetTileNameRange(&flDriver, 3, 4, 7);
  flDriverSetTileNameRange(&flDriver, 4, 8, 15);
  flDriverSetTileNameLarge(&flDriver, 5, 16);

  printf("--   Setting up driver 1\n");
  driver = gcspy_mainServerAddDriver(&server);
  msDriverInit(&msDriver, driver, 
	       "Single Generation",
	       TILE_SIZE,
	       (char *) 0, (char *) (FIVE + FULL));

#ifdef _SPARC_
  res = thr_create(NULL, 0, mainLoop, NULL, THR_BOUND, &tid);
#endif //_SPARC_

#ifdef _LINUX_
  res = pthread_create(&tid, NULL, mainLoop, NULL);
#endif //_LINUX_

  if (res != 0) {
    printf("Couldn't create thread.\n");
    exit(-1);
  }

  gcspy_mainServerMainLoop(&server);
}
