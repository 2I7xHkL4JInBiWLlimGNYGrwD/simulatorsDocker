/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  gcspy_buffered_io_test.c
 **
 **  Tests the buffered I/O facilities
 **/

#include "gcspy_buffered_input.h"
#include "gcspy_buffered_output.h"

#define check_err() \
do { \
  if (err != GCSPY_OK) { \
    gcspy_printError(err); \
    exit(-1); \
  } \
} while (0)

int
main (int argc, char *argv[]) {
  gcspy_err_t err;
  char buffer[1024];
  gcspy_buffered_input_t input;
  gcspy_buffered_input_t output;

  err = 
}
