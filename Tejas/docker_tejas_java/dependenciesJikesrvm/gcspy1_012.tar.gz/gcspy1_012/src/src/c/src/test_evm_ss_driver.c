/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  gcspy_test_ss_driver.c
 **
 **  Tests the S-S Driver
 **/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "evm_ss_driver.h"
#include "gcspy_main_server.h"
#include "gcspy_timer.h"

#ifdef _SPARC_
#include <thread.h>
#endif //_SPARC_

#ifdef _LINUX_
#include <pthread.h>
#endif //_LINUX_

#define MAX_LEN      ( 64 * 1024 )
#define TILE_SIZE    ( 32 * 1024 )

static gcspy_main_server_t server;
static ss_driver_t ssDriver;

#define ONE  0
#define TWO ( 2 * 1024 * 1024 )
#define THREE ( 4 * 1024 * 1024 )

#define START_GC_EVENT      0
#define END_GC_EVENT        1

#ifdef  __cplusplus
extern "C" {
#endif //__cplusplus
static void *
mainLoop (void *arg) {
  int semi = 0;
  char *limit;
  int event = START_GC_EVENT;

  while ( 1 ) {
    gcspy_wait(200);

    if (gcspy_mainServerIsConnected(&server, event)) {
      gcspy_mainServerStartCompensationTimer(&server);

      ssDriverZero(&ssDriver);

      if (semi == 0) {
	limit = (char *) (ONE + (512*1024 + 45*1000));
      } else {
	limit = (char *) (TWO + (1024*1024));
      }
      ssDriverSetSemispace(&ssDriver, semi, limit);
      if (semi == 0)
	semi = 1;
      else 
	semi = 0;

      gcspy_mainServerStopCompensationTimer(&server);

      if (gcspy_mainServerIsConnected(&server, event)) {
	printf("CONNECTED\n");
	ssDriverSend(&ssDriver, event);
      }
    }
    gcspy_mainServerSafepoint(&server, event);
    if (event == START_GC_EVENT)
      event = END_GC_EVENT;
    else
      event = START_GC_EVENT;
  }
}
#ifdef  __cplusplus
}
#endif //__cplusplus

int
main (int argc, char *argv[]) {
  char generalInfo[256];
  gcspy_date_time_t time;

#ifdef _SPARC_
  thread_t tid;
#endif //_SPARC_

#ifdef _LINUX_
  pthread_t tid;
#endif //_LINUX_

  gcspy_gc_driver_t *driver;
  int port;
  int res;

  if (argc != 2) {
    gcspy_raise_error("Wrong number of arguments");
  }
  port = atoi(argv[1]);

  printf("-- Initialising main server on port %d\n", port);
  gcspy_mainServerInit(&server, port, MAX_LEN, "S-S Driver Test", 1);

  time = gcspy_getDateTime();
  strcpy(generalInfo, "GCspy Test\n\n");
  strcat(generalInfo, "Start Time:\n  ");
  strcat(generalInfo, gcspy_formatDateTime(time));
  strcat(generalInfo, "\nApplication:\n  S-S Driver Test\n\n");
  strcat(generalInfo, "1 Space");
  gcspy_mainServerSetGeneralInfo(&server, generalInfo);

  printf("--   Setting event 0\n");
  gcspy_mainServerAddEvent(&server, START_GC_EVENT, "Start S-S GC");
  printf("--   Setting event 1\n");
  gcspy_mainServerAddEvent(&server, END_GC_EVENT, "End S-S GC");

  printf("--   Setting up driver 0\n");
  driver = gcspy_mainServerAddDriver(&server);

  ssDriverInit(&ssDriver, driver, 
	       "Single Generation",
	       TILE_SIZE,
	       (char *) ONE,
	       (char *) TWO,
	       (char *) TWO,
	       (char *) THREE);

#ifdef _SPARC_
  res = thr_create(NULL, 0, mainLoop, NULL, THR_BOUND, &tid);
#endif //_SPARC_

#ifdef _LINUX_
  res = pthread_create(&tid, NULL, mainLoop, NULL);
#endif //_LINUX_

  if (res != 0) {
    printf("Couldn't create thread.\n");
    exit(-1);
  }

  gcspy_mainServerMainLoop(&server);
}
