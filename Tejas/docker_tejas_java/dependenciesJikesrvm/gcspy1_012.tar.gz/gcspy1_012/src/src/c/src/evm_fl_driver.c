/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  evm_fl_driver.c
 **
 **  Driver instance for the EVM M&S free lists
 **/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "gcspy_gc_stream.h"
#include "gcspy_d_utils.h"
#include "evm_fl_driver.h"

static fl_driver_tile_t *
flDriverGetTile (fl_driver_t *flDriver, int index) {
  return &flDriver->tiles[index];
}

void
flDriverZero (fl_driver_t *flDriver) {
  int i;
  fl_driver_tile_t *tile;

  for (i = 0; i < flDriver->tileNum; ++i) {
    tile = flDriverGetTile(flDriver, i);
    tile->length = 0;
    tile->size = 0;
  }

  flDriver->totalLength = 0;
  flDriver->totalSize[0] = 0;
  flDriver->totalSize[1] = flDriver->spaceSize;
}

void
flDriverSend (fl_driver_t *flDriver, unsigned event) {
  int i;
  fl_driver_tile_t *tile;
  gcspy_gc_driver_t *driver = flDriver->driver;

  gcspy_driverStartComm(driver);


  gcspy_driverStream(driver, FL_LENGTH_STREAM, flDriver->tileNum);
  for (i = 0; i < flDriver->tileNum; ++i) {
    tile = flDriverGetTile(flDriver, i);
    gcspy_driverStreamIntValue(driver, tile->length);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, FL_LENGTH_STREAM, 1);
  gcspy_driverSummaryValue(driver, flDriver->totalLength);
  gcspy_driverSummaryEnd(driver);


  gcspy_driverStream(driver, FL_SIZE_STREAM, flDriver->tileNum);
  for (i = 0; i < flDriver->tileNum; ++i) {
    tile = flDriverGetTile(flDriver, i);
    gcspy_driverStreamIntValue(driver, tile->size);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, FL_SIZE_STREAM, 2);
  gcspy_driverSummaryValue(driver, flDriver->totalSize[0]);
  gcspy_driverSummaryValue(driver, flDriver->totalSize[1]);
  gcspy_driverSummaryEnd(driver);


  gcspy_driverControl(driver);
  gcspy_driverControlValues(driver,
			    GCSPY_GC_DRIVER_CONTROL_SEPARATOR,
			    flDriver->exactLimit, 1);
  gcspy_driverControlValues(driver,
			    GCSPY_GC_DRIVER_CONTROL_SEPARATOR,
			    flDriver->rangeLimit, 1);
  gcspy_driverControlEnd(driver);

  gcspy_driverEndComm(driver);
}

void
flDriverFreeChunk (fl_driver_t *flDriver,
		   int list,
		   int size) {
  fl_driver_tile_t *tile;
  tile = flDriverGetTile(flDriver, list);  

  ++tile->length;
  tile->size += size;

  ++flDriver->totalLength;
  flDriver->totalSize[0] += size;
}

void
flDriverSetTileNameExact (fl_driver_t *flDriver,
			  int list,
			  int len) {
  char buffer[256];
  gcspy_gc_driver_t *gcDriver = flDriver->driver;
  sprintf(buffer, "   Exact: %d bytes", len);
  gcspy_driverSetTileName(gcDriver, list, buffer);
}

void
flDriverSetTileNameRange (fl_driver_t *flDriver,
			  int list,
			  int min,
			  int max) {
  char buffer[256];
  gcspy_gc_driver_t *gcDriver = flDriver->driver;
  sprintf(buffer, "   Range: [%d,%d) bytes", min, max);
  gcspy_driverSetTileName(gcDriver, list, buffer);
  if (flDriver->exactLimit == -1) {
    flDriver->exactLimit = list;
  }
}

void
flDriverSetTileNameLarge (fl_driver_t *flDriver,
			  int list,
			  int min){
  char buffer[256];
  gcspy_gc_driver_t *gcDriver = flDriver->driver;
  sprintf(buffer, "   Large: [%d,...) bytes", min);
  gcspy_driverSetTileName(gcDriver, list, buffer);
  if (flDriver->rangeLimit == -1) {
    flDriver->rangeLimit = list;
  }
}

void
flDriverInit (fl_driver_t *flDriver,
	      gcspy_gc_driver_t *gcDriver,
	      const char *name,
	      int tileNum,
	      int spaceSize) {
  int i;
  char tmp[256];
  gcspy_gc_stream_t *stream;
  int len = tileNum * sizeof(fl_driver_tile_t);
  fl_driver_tile_t *tiles = (fl_driver_tile_t *) malloc(len);

  if (tiles == NULL) {
    char buffer[256];
    sprintf(buffer, "F-L Driver: could not allocate %d bytes tile data", len);
    gcspy_raise_error(buffer);
  }    

  flDriver->driver = gcDriver;
  flDriver->tileNum = tileNum;
  flDriver->tiles = tiles;
  flDriver->spaceSize = spaceSize;

  flDriver->exactLimit = -1;
  flDriver->rangeLimit = -1;

  gcspy_driverInit(gcDriver, -1, name, "Free Lists",
		   "List ", "", tileNum, NULL, 0);

  stream = gcspy_driverAddStream(gcDriver, FL_LENGTH_STREAM);
  gcspy_streamInit(stream, FL_LENGTH_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Length",
		   0, gcspy_d_utils_chunks_per_block(spaceSize) / tileNum,
		   0, 0,
		   "Length: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Blue"));

  stream = gcspy_driverAddStream(gcDriver, FL_SIZE_STREAM);
  gcspy_streamInit(stream, FL_SIZE_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Size",
		   0, spaceSize,
		   0, 0,
		   "Size: ", " bytes",
		   GCSPY_GC_STREAM_PRESENTATION_PERCENT,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Red"));

  flDriverZero(flDriver);
}
