/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  evm_ms_driver.h
 **
 **  Driver instance for the EVM M&S collector
 **/

#ifndef _EVM_MS_DRIVER_H_

#define _EVM_MS_DRIVER_H_

#include "gcspy_gc_driver.h"
#include "gcspy_d_utils.h"

#define MS_USED_SPACE_STREAM    0
#define MS_CARD_TABLE_STREAM    1
#define MS_PROMOTION_STREAM     2
#define MS_ROOTS_STREAM         3
#define MS_MARKING_STREAM       4
#define MS_CHUNKS_STREAM        5
#define MS_OBJECTS_STREAM       6

#define MS_CARD_STATE_CLEAN          2
#define MS_CARD_STATE_SUMMARISED     1
#define MS_CARD_STATE_DIRTY          0

typedef struct {
  int usedSpace;
  int cards;
  int promotion;
  int roots;
  int marking;
  int freeChunks;
  int objects;
} ms_driver_tile_t;

typedef struct {
  gcspy_gc_driver_t     *driver;
  gcspy_d_utils_area_t   area;

  int                    totalUsedSpace[2];
  int                    totalCardTable[3];
  int                    totalPromotion[2];
  int                    totalRoots;
  int                    totalMarking;
  int                    totalChunks;
  int                    totalObjects;
} ms_driver_t;

void
msDriverInit (ms_driver_t *msDriver,
	      gcspy_gc_driver_t *gcDriver,
	      const char *name,
	      unsigned blockSize,
	      char *start,
	      char *end);

void
msDriverZero (ms_driver_t *msDriver,
	      char *limit);

#if 0
void
msDriverLimit (ms_driver_t *msDriver,
	       char *limit);
#endif //0

void
msDriverObject (ms_driver_t *msDriver,
		char *start,
		int size);

void
msDriverFreeChunk (ms_driver_t *msDriver,
		   char *start,
		   int size);

void
msDriverCard (ms_driver_t *msDriver,
	      char *start,
	      int size,
	      int state);

void
msDriverPromoted (ms_driver_t *msDriver,
		  char *start,
		  int size);

void
msDriverRoot (ms_driver_t *msDriver,
	      char *start);

void
msDriverMarked (ms_driver_t *msDriver,
		char *start);

void
msDriverSend (ms_driver_t *msDriver,
	      unsigned event);

#endif //_EVM_MS_DRIVER_H_
