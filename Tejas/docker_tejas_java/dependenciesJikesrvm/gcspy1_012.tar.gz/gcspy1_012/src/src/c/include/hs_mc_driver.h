/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  hs_mc_driver.h
 **
 **  Driver instance for the H-S M&C collector
 **/

#ifndef _HS_MC_DRIVER_H_

#define _HS_MC_DRIVER_H_

#include "gcspy_gc_driver.h"
#include "gcspy_d_utils.h"

#define MC_USED_SPACE_STREAM       0
#define MC_DEAD_SPACE_STREAM       1
#define MC_CARD_TABLE_STREAM       2
#define MC_DIRECT_ALLOC_STREAM     3
#define MC_PROMOTION_STREAM        4
#define MC_OBJECTS_STREAM          5
#define MC_MARKING_STREAM          6
#define MC_REFS_STREAM             7
#define MC_REFS_TO_LEFT_STREAM     8
#define MC_REFS_TO_RIGHT_STREAM    9
#define MC_REFS_TO_YOUNG_STREAM   10
#define MC_REFS_TO_PERM_STREAM    11
#define MC_INTERNAL_REFS_STREAM   12

#define MC_CARD_STATE_CLEAN       2
/* #define MC_CARD_STATE_LAST        3 */
#define MC_CARD_STATE_YOUNGER     1
/* #define MC_CARD_STATE_PRECLEANED  1 */
#define MC_CARD_STATE_DIRTY       0

#define MC_CARD_STATE_NUM           3

#define MC_REF_LENGTH_MAX_MULT     100

typedef struct {
  int usedSpace;
  int deadSpace;
  int cards;
  int directAlloc;
  int promotion;
  int objects;
  int marks;
  int refs;
  int refsToLeft;
  int refsToRight;
  int refsToYoung;
  int refsToPerm;
  int internalRefs;
} mc_driver_tile_t;

typedef struct {
  char *start;
  char *end;
} dead_space_t;

typedef struct {
  gcspy_gc_driver_t     *driver;
  gcspy_d_utils_area_t   area;
  unsigned cardSize;

  int totalUsedSpace[2];
  int totalDeadSpace[2];
  int totalCards[MC_CARD_STATE_NUM];
  int totalDirectAlloc[2];
  int totalPromotion[2];
  int totalObjects;
  int totalMarks;
  int totalRefs;
  int totalRefsToLeft;
  int totalRefsToRight;
  int totalRefsToYoung;
  int totalRefsToPerm;
  int totalInternalRefs;
} mc_driver_t;

void
hsMCDriverInit (mc_driver_t *mcDriver,
		gcspy_gc_driver_t *gcDriver,
		const char *name,
		unsigned blockSize,
		unsigned cardSize,
		char *start,
		char *end);

void
hsMCDriverZero (mc_driver_t *mcDriver,
		char *end);

void
hsMCDriverSetLimit (mc_driver_t *mcDriver,
		    char *limit);

void
hsMCDriverDeadSpace (mc_driver_t *mcDriver,
		     char *start, char *end);

void
hsMCDriverDirectAlloc (mc_driver_t *mcDriver,
		       char *start, char *end);

void
hsMCDriverPromotion (mc_driver_t *mcDriver,
		     char *start, char *end);

void
hsMCDriverObject (mc_driver_t *mcDriver,
		  char *start, int size);

void
hsMCDriverMark (mc_driver_t *mcDriver,
		char *start);

void
hsMCDriverCard (mc_driver_t *mcDriver,
		char *start,
		int state);

void
hsMCDriverRef (mc_driver_t *mcDriver,
	       char *addr);

void
hsMCDriverRefToLeft (mc_driver_t *mcDriver,
		     char *addr);

void
hsMCDriverRefToRight (mc_driver_t *mcDriver,
		      char *addr);

void
hsMCDriverRefToYoung (mc_driver_t *mcDriver,
		      char *addr);

void
hsMCDriverRefToPerm (mc_driver_t *mcDriver,
		     char *addr);

void
hsMCDriverInternalRef (mc_driver_t *mcDriver,
		       char *addr);

void
hsMCDriverSend (mc_driver_t *mcDriver,
		unsigned event);

#endif //_HS_MC_DRIVER_H_
