/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  evm_cms_driver.c
 **
 **  Driver instance for the EVM CM&S collector
 **/

#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include "gcspy_gc_stream.h"
#include "evm_cms_driver.h"

static cms_driver_tile_t *
cmsDriverAllocateStats (int tileNum) {
  int len = tileNum * sizeof(cms_driver_tile_t);
  cms_driver_tile_t *tiles = (cms_driver_tile_t *) malloc(len);
  if (tiles == NULL) {
    char buffer[256];
    sprintf(buffer, "M&S Driver: could not allocate %d bytes for tile data",
	    len);
    gcspy_raise_error(buffer);
  }
  return tiles;
}

static void
cmsDriverSetupTileNames (cms_driver_t *cmsDriver,
			 int from,
			 int to) {
  int i;
  char tmp[256];
  for (i = from; i < to; ++i) {
    gcspy_dUtilsRangeString(&(cmsDriver->area), i, tmp);
    gcspy_driverSetTileName(cmsDriver->driver, i, tmp);
  }
}

static cms_driver_tile_t *
cmsDriverGetTile (cms_driver_t *cmsDriver, int index) {
  return (cms_driver_tile_t *)
    gcspy_d_utils_get_stats_struct(&(cmsDriver->area), index, 0);
}

static int
cmsDriverGetTileIndex (cms_driver_t *cmsDriver, char *addr) {
  return gcspy_d_utils_get_index(&(cmsDriver->area), addr);
}

static int
cmsDriverGetTileEndIndex (cms_driver_t *cmsDriver, char *addr) {
  gcspy_d_utils_area_t *area = &(cmsDriver->area);
  int index = gcspy_d_utils_get_index(area, addr);
  if (!gcspy_d_utils_is_boundary(area, addr))
    ++index;
  return index;
}

static char *
cmsDriverGetTileAddr (cms_driver_t *cmsDriver, int index) {
  return gcspy_d_utils_get_addr(&(cmsDriver->area), index);
}

void
cmsDriverZero (cms_driver_t *cmsDriver,
	       char *limit) {
  int i;
  cms_driver_tile_t *tile;
  int totalSpace = limit - cmsDriver->area.start;

  if (limit != cmsDriver->area.end) {
    int tileNum = gcspy_dUtilsTileNum(cmsDriver->area.start,
				      limit,
				      cmsDriver->area.blockSize); 
    /* printf("resizing to %8x, tileNum = %d\n", limit, tileNum); */
    cmsDriver->area.end = limit;
    cmsDriver->area.blockNum = tileNum;
    free(cmsDriver->area.stats);
    cmsDriver->area.stats = (char *) cmsDriverAllocateStats(tileNum);

    gcspy_driverResize(cmsDriver->driver, tileNum);
    cmsDriverSetupTileNames(cmsDriver, 0, tileNum);
  }

  for (i = 0; i < cmsDriver->area.blockNum; ++i) {
    tile = cmsDriverGetTile(cmsDriver, i);
    tile->usedSpace = 0;
    tile->cards = CMS_CARD_STATE_CLEAN;
    tile->promotion = 0;
    tile->roots = 0;
    tile->marking = 0;
    tile->freeChunks = 0;
    tile->objects = 0;
    tile->modUnion = CMS_MOD_UNION_STATE_CLEAN;
  }

  cmsDriver->totalUsedSpace[0] = 0;
  cmsDriver->totalUsedSpace[1] = totalSpace;
  for (i = 0; i < 5; ++i) {
    cmsDriver->totalCardTable[i] = 0;
  }
  cmsDriver->totalPromotion[0] = 0;
  cmsDriver->totalPromotion[1] = totalSpace;
  cmsDriver->totalRoots = 0;
  cmsDriver->totalMarking = 0;
  cmsDriver->totalChunks = 0;
  cmsDriver->totalObjects = 0;
  for (i = 0; i < 2; ++i) {
    cmsDriver->totalModUnion[i] = 0;
  }

  cmsDriver->sweepingFront = 0;
  cmsDriver->markingFront = 0;
}

void
cmsDriverObject (cms_driver_t *cmsDriver,
		 char *start,
		 int size) {
  ++cmsDriver->totalObjects;
  cmsDriver->totalUsedSpace[0] += size;
  gcspy_dUtilsSetPerc(&(cmsDriver->area), start, start + size,
		      offsetof(cms_driver_tile_t, usedSpace));
  gcspy_dUtilsAddOne(&(cmsDriver->area), start, start + size,
		     offsetof(cms_driver_tile_t, objects));
}

void
cmsDriverFreeChunk (cms_driver_t *cmsDriver,
		    char *start,
		    int size) {
  ++cmsDriver->totalChunks;
  gcspy_dUtilsAddOne(&(cmsDriver->area), start, start + size,
		     offsetof(cms_driver_tile_t, freeChunks));
}

void
cmsDriverCard (cms_driver_t *cmsDriver,
	       char *start,
	       int size,
	       int state) {
  ++cmsDriver->totalCardTable[state];
  gcspy_dUtilsUpdateEnumDesc(&(cmsDriver->area), start, start + size,
			     offsetof(cms_driver_tile_t, cards), state);
}

void
cmsDriverModUnion (cms_driver_t *cmsDriver,
		   char *start,
		   int size,
		   int state) {
  ++cmsDriver->totalModUnion[state];
  gcspy_dUtilsUpdateEnumDesc(&(cmsDriver->area), start, start + size,
			     offsetof(cms_driver_tile_t, modUnion), state);
}

void
cmsDriverPromoted (cms_driver_t *cmsDriver,
		   char *start,
		   int size) {
  cmsDriver->totalPromotion[0] += size;
  gcspy_dUtilsSetPerc(&(cmsDriver->area), start, start + size,
		      offsetof(cms_driver_tile_t, promotion));
}

void
cmsDriverRoot (cms_driver_t *cmsDriver,
	       char *start) {
  ++cmsDriver->totalRoots;
  gcspy_dUtilsAddSingle(&(cmsDriver->area), start, 
			offsetof(cms_driver_tile_t, roots));
}

void
cmsDriverMarked (cms_driver_t *cmsDriver,
		 char *start) {
  ++cmsDriver->totalMarking;
  gcspy_dUtilsAddSingle(&(cmsDriver->area), start, 
			offsetof(cms_driver_tile_t, marking));
}

void
cmsDriverMarkingFront (cms_driver_t *cmsDriver,
		       char *markingFront) {
  cmsDriver->markingFront = markingFront;
}

void
cmsDriverSweepingFront (cms_driver_t *cmsDriver,
			char *sweepingFront) {
  cmsDriver->sweepingFront = sweepingFront;
}

void
cmsDriverSend (cms_driver_t *cmsDriver, unsigned event) {
  int i;
  cms_driver_tile_t *tile;
  gcspy_gc_driver_t *driver = cmsDriver->driver;
  int tileNum = cmsDriver->area.blockNum;
  double perc;
  char tmp[128];
  int size;

  gcspy_driverStartComm(driver);

  gcspy_driverStream(driver, CMS_USED_SPACE_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = cmsDriverGetTile(cmsDriver, i);
    gcspy_driverStreamIntValue(driver, tile->usedSpace);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, CMS_USED_SPACE_STREAM, 2);
  gcspy_driverSummaryValue(driver, cmsDriver->totalUsedSpace[0]);
  gcspy_driverSummaryValue(driver, cmsDriver->totalUsedSpace[1]);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, CMS_CARD_TABLE_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = cmsDriverGetTile(cmsDriver, i);
    gcspy_driverStreamByteValue(driver, tile->cards);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, CMS_CARD_TABLE_STREAM, 5);
  for (i = 0; i < 5; ++i) {
    gcspy_driverSummaryValue(driver, cmsDriver->totalCardTable[i]);
  }
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, CMS_PROMOTION_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = cmsDriverGetTile(cmsDriver, i);
    gcspy_driverStreamIntValue(driver, tile->promotion);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, CMS_PROMOTION_STREAM, 2);
  gcspy_driverSummaryValue(driver, cmsDriver->totalPromotion[0]);
  gcspy_driverSummaryValue(driver, cmsDriver->totalPromotion[1]);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, CMS_ROOTS_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = cmsDriverGetTile(cmsDriver, i);
    gcspy_driverStreamShortValue(driver, tile->roots);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, CMS_ROOTS_STREAM, 1);
  gcspy_driverSummaryValue(driver, cmsDriver->totalRoots);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, CMS_MARKING_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = cmsDriverGetTile(cmsDriver, i);
    gcspy_driverStreamIntValue(driver, tile->marking);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, CMS_MARKING_STREAM, 1);
  gcspy_driverSummaryValue(driver, cmsDriver->totalMarking);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, CMS_CHUNKS_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = cmsDriverGetTile(cmsDriver, i);
    gcspy_driverStreamIntValue(driver, tile->freeChunks);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, CMS_CHUNKS_STREAM, 1);
  gcspy_driverSummaryValue(driver, cmsDriver->totalChunks);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, CMS_OBJECTS_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = cmsDriverGetTile(cmsDriver, i);
    gcspy_driverStreamIntValue(driver, tile->objects);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, CMS_OBJECTS_STREAM, 1);
  gcspy_driverSummaryValue(driver, cmsDriver->totalObjects);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, CMS_MOD_UNION_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = cmsDriverGetTile(cmsDriver, i);
    gcspy_driverStreamByteValue(driver, tile->modUnion);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, CMS_MOD_UNION_STREAM, 2);
  for (i = 0; i < 2; ++i) {
    gcspy_driverSummaryValue(driver, cmsDriver->totalModUnion[i]);
  }
  gcspy_driverSummaryEnd(driver);



  gcspy_driverControl(driver);
  if (cmsDriver->markingFront != 0) {
    i = cmsDriverGetTileEndIndex(cmsDriver, cmsDriver->markingFront);
    gcspy_driverControlValues(driver,
			      GCSPY_GC_DRIVER_CONTROL_SEPARATOR,
			      i, 1);
  }
  if (cmsDriver->sweepingFront != 0) {
    i = cmsDriverGetTileEndIndex(cmsDriver, cmsDriver->sweepingFront);
    gcspy_driverControlValues(driver, GCSPY_GC_DRIVER_CONTROL_SEPARATOR,
			      i, 1);
  }
  gcspy_driverControlEnd(driver);

  size = cmsDriver->area.end - cmsDriver->area.start;
  sprintf(tmp, "Current Size: %s\n", gcspy_formatSize(size));
  gcspy_driverSpaceInfo(driver, tmp);

  gcspy_driverEndComm(driver);
}

void
cmsDriverInit (cms_driver_t *cmsDriver,
	       gcspy_gc_driver_t *gcDriver,
	       char *name,
	       unsigned blockSize,
	       char *start,
	       char *end) {
  int i;
  char tmp[256];
  gcspy_gc_stream_t *stream;
  int tileNum = gcspy_dUtilsTileNum(start, end, blockSize);
  cms_driver_tile_t *tiles = cmsDriverAllocateStats(tileNum);

  cmsDriver->driver = gcDriver;
  gcspy_dUtilsInit(&(cmsDriver->area),
		   start, end,
		   0, blockSize, tileNum, 
		   (char *) tiles, sizeof(cms_driver_tile_t));

  if (blockSize < 1024)
    sprintf(tmp, "Block Size: %d bytes\n", blockSize);
  else
    sprintf(tmp, "Block Size: %dK\n", (blockSize / 1024));
  gcspy_driverInit(gcDriver, -1, name, "CM&S GC",
		   "Block ", tmp, tileNum,
		   NULL, 1);
  cmsDriverSetupTileNames(cmsDriver, 0, tileNum);

  stream = gcspy_driverAddStream(gcDriver, CMS_USED_SPACE_STREAM);
  gcspy_streamInit(stream, CMS_USED_SPACE_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Used Space",
		   0, blockSize,
		   0, 0,
		   "Used Space: ", " bytes",
		   GCSPY_GC_STREAM_PRESENTATION_PERCENT,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Red"));

  stream = gcspy_driverAddStream(gcDriver, CMS_CARD_TABLE_STREAM);
  gcspy_streamInit(stream, CMS_CARD_TABLE_STREAM,
		   GCSPY_GC_STREAM_BYTE_TYPE,
		   "Card Table",
		   0, 4,
		   4, 4,
		   "Card State: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_ENUM,
		   GCSPY_GC_STREAM_PAINT_STYLE_PLAIN, 0,
		   gcspy_colorDBGetColorWithName("Off White"));
  gcspy_streamAddEnumName(stream, CMS_CARD_STATE_DIRTY, "DIRTY");
  gcspy_streamAddEnumName(stream, CMS_CARD_STATE_PRECLEANED, "PRECLEANED");
  gcspy_streamAddEnumName(stream, CMS_CARD_STATE_OVERFLOWN, "OVERFLOWN");
  gcspy_streamAddEnumName(stream, CMS_CARD_STATE_SUMMARISED, "SUMMARISED");
  gcspy_streamAddEnumName(stream, CMS_CARD_STATE_CLEAN, "CLEAN");

  stream = gcspy_driverAddStream(gcDriver, CMS_PROMOTION_STREAM);
  gcspy_streamInit(stream, CMS_PROMOTION_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Promotion",
		   0, blockSize,
		   0, 0,
		   "Promoted: ", " bytes",
		   GCSPY_GC_STREAM_PRESENTATION_PERCENT,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Magenta"));

  stream = gcspy_driverAddStream(gcDriver, CMS_ROOTS_STREAM);
  gcspy_streamInit(stream, CMS_ROOTS_STREAM,
		   GCSPY_GC_STREAM_SHORT_TYPE,
		   "Roots",
		   0, gcspy_d_utils_roots_per_block(blockSize),
		   0, 0,
		   "Roots: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Green"));

  stream = gcspy_driverAddStream(gcDriver, CMS_MARKING_STREAM);
  gcspy_streamInit(stream, CMS_MARKING_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Marking",
		   0, gcspy_d_utils_objects_per_block(blockSize),
		   0, 0,
		   "Marked: ", " objects",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Orange"));

  stream = gcspy_driverAddStream(gcDriver, CMS_CHUNKS_STREAM);
  gcspy_streamInit(stream, CMS_CHUNKS_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Free Chunks",
		   0, gcspy_d_utils_chunks_per_block(blockSize),
		   0, 0,
		   "Free Chunks: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Blue"));

  stream = gcspy_driverAddStream(gcDriver, CMS_OBJECTS_STREAM);
  gcspy_streamInit(stream, CMS_OBJECTS_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Objects",
		   0, gcspy_d_utils_objects_per_block(blockSize),
		   0, 0,
		   "Objects: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Yellow"));

  stream = gcspy_driverAddStream(gcDriver, CMS_MOD_UNION_STREAM);
  gcspy_streamInit(stream, CMS_MOD_UNION_STREAM,
		   GCSPY_GC_STREAM_BYTE_TYPE,
		   "Mod Union Table",
		   0, 1,
		   1, 1,
		   "Mod Union State: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_ENUM,
		   GCSPY_GC_STREAM_PAINT_STYLE_PLAIN, 0,
		   gcspy_colorDBGetColorWithName("Off White"));
  gcspy_streamAddEnumName(stream, CMS_MOD_UNION_STATE_DIRTY, "DIRTY");
  gcspy_streamAddEnumName(stream, CMS_MOD_UNION_STATE_CLEAN, "CLEAN");
}
