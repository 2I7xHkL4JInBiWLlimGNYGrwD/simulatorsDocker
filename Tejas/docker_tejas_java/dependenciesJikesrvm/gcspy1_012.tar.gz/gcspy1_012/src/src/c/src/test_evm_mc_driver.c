/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  gcspy_test_mc_driver.c
 **
 **  Tests the M&C Driver
 **/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "evm_mc_driver.h"
#include "gcspy_main_server.h"
#include "gcspy_timer.h"

#ifdef _SPARC_
#include <thread.h>
#endif //_SPARC_

#ifdef _LINUX_
#include <pthread.h>
#endif //_LINUX_

#define MAX_LEN      ( 128 * 1024 )
#define TILE_SIZE    ( 32 * 1024 )

static gcspy_main_server_t server;
static mc_driver_t mcDriver;

#define START     0
#define FIRST   ( ONE - (5 * 1024) )
#define ONE     ( 2 * 1024 * 1024 )
#define END     ( 4 * 1024 * 1024 )

#define CARD_SIZE  1024

#define START_GC_EVENT      0
#define END_GC_EVENT        1

#ifdef  __cplusplus
extern "C" {
#endif //__cplusplus
static void *
mainLoop (void *arg) {
  int count = -1;
  char *limit;
  char *end;
  char *promStart;
  char *promEnd;
  int event = START_GC_EVENT;

  while ( 1 ) {
    gcspy_wait(1000);

    if (gcspy_mainServerIsConnected(&server, event)) {
      gcspy_mainServerStartCompensationTimer(&server);

      ++count;
      switch (count) {
      case 0:
	limit = (char *) FIRST;
	end = (char *) START;
	promStart = (char *) START + 1000;
	promEnd = (char *) (START + 30000);
	break;
      case 1:
	limit = (char *) ONE;
	end = (char *) (ONE * 2 / 3);
	promStart = (char *) START;
	promEnd = (char *) (ONE / 2);
	break;
      case 2:
	limit = (char *) END;
	end = (char *) (3 * ONE / 2);
	promStart = (char *) (START + 50000);
	promEnd = (char *) ((ONE / 2) + 50000);
	break;
      case 3:
	limit = (char *) END;
	end = (char *) ((3 * ONE / 2) + 4000);
	promStart = (char *) (START + 50000);
	promEnd = (char *) ((ONE / 2) + 50000);

	count = -1;
	break;
      }

      mcDriverZero(&mcDriver, limit);
#if 0
      mcDriverLimit(&mcDriver, limit);
#endif //0
      mcDriverSetEnd(&mcDriver, end);
      mcDriverPromotion(&mcDriver, promStart, promEnd);

      switch ((count+1) % 2) {
      case 0:
	mcDriverRoot(&mcDriver, (char *) START + 2);
	mcDriverRoot(&mcDriver, (char *) START + 100);
	mcDriverRoot(&mcDriver, (char *) START + 100);
	mcDriverRoot(&mcDriver, (char *) START + 100);
	mcDriverRoot(&mcDriver, (char *) START + 101);
	mcDriverRoot(&mcDriver, (char *) START + 2 * (TILE_SIZE) + 2);
	mcDriverRoot(&mcDriver, (char *) START + 2 * (TILE_SIZE) + 10);
	break;
      case 1:
	mcDriverRoot(&mcDriver, (char *) START + 101);
	mcDriverRoot(&mcDriver, (char *) START + 2 * (TILE_SIZE) + 10);
	mcDriverRoot(&mcDriver, (char *) START + 2 * (TILE_SIZE) + 2);
	break;
      }

      mcDriverCard(&mcDriver, (char *) START, CARD_SIZE,
		   MC_CARD_STATE_DIRTY);
      mcDriverCard(&mcDriver, (char *) START + CARD_SIZE, CARD_SIZE,
		   MC_CARD_STATE_CLEAN);

      mcDriverCard(&mcDriver, (char *) (ONE / 2), CARD_SIZE,
		   MC_CARD_STATE_SUMMARISED);
      mcDriverCard(&mcDriver, (char *) (ONE / 2 + CARD_SIZE), CARD_SIZE,
		   MC_CARD_STATE_CLEAN);

      gcspy_mainServerStopCompensationTimer(&server);

      if (gcspy_mainServerIsConnected(&server, event)) {
	printf("CONNECTED\n");
	mcDriverSend(&mcDriver, event);
      }
    }
    gcspy_mainServerSafepoint(&server, event);
    if (event == START_GC_EVENT)
      event = END_GC_EVENT;
    else
      event = START_GC_EVENT;
  }
}
#ifdef  __cplusplus
}
#endif //__cplusplus

int
main (int argc, char *argv[]) {
  char generalInfo[256];
  gcspy_date_time_t time;

#ifdef _SPARC_
  thread_t tid;
#endif //_SPARC_

#ifdef _LINUX_
  pthread_t tid;
#endif //_LINUX_

  gcspy_gc_driver_t *driver;
  int port;
  int res;

  if (argc != 2) {
    gcspy_raise_error("Wrong number of arguments");
  }
  port = atoi(argv[1]);

  printf("-- Initialising main server on port %d\n", port);
  gcspy_mainServerInit(&server, port, MAX_LEN, "M&C Driver Test", 1);

  time = gcspy_getDateTime();
  strcpy(generalInfo, "GCspy Test\n\n");
  strcat(generalInfo, "Start Time:\n  ");
  strcpy(generalInfo, gcspy_formatDateTime(time));
  strcat(generalInfo, "\nApplication:\n  M&C Driver Test\n\n");
  strcat(generalInfo, "1 Space");
  gcspy_mainServerSetGeneralInfo(&server, generalInfo);

  printf("--   Setting event 0\n");
  gcspy_mainServerAddEvent(&server, START_GC_EVENT, "Start M&C GC");
  printf("--   Setting event 1\n");
  gcspy_mainServerAddEvent(&server, END_GC_EVENT, "End M&C GC");

  printf("--   Setting up driver 0\n");
  driver = gcspy_mainServerAddDriver(&server);

  mcDriverInit(&mcDriver, driver, 
	       "Single Generation",
	       TILE_SIZE,
	       (char *) START,
	       (char *) FIRST);

#ifdef _SPARC_
  res = thr_create(NULL, 0, mainLoop, NULL, THR_BOUND, &tid);
#endif //_SPARC_

#ifdef _LINUX_
  res = pthread_create(&tid, NULL, mainLoop, NULL);
#endif //_LINUX_

  if (res != 0) {
    printf("Couldn't create thread.\n");
    exit(-1);
  }

  gcspy_mainServerMainLoop(&server);
}
