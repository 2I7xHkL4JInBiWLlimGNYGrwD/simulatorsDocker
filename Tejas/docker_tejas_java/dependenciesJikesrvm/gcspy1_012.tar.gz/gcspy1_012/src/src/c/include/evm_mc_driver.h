/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  evm_mc_driver.h
 **
 **  Driver instance for the EVM M&C collector
 **/

#ifndef _EVM_MC_DRIVER_H_

#define _EVM_MC_DRIVER_H_

#include "gcspy_gc_driver.h"
#include "gcspy_d_utils.h"

#define MC_USED_SPACE_STREAM    0
#define MC_CARD_TABLE_STREAM    1
#define MC_PROMOTION_STREAM     2
#define MC_ROOTS_STREAM         3
#define MC_MARKING_STREAM       4

#define MC_CARD_STATE_CLEAN          2
#define MC_CARD_STATE_SUMMARISED     1
#define MC_CARD_STATE_DIRTY          0

typedef struct {
  int usedSpace;
  int cards;
  int promotion;
  int roots;
  int marking;
} mc_driver_tile_t;

typedef struct {
  gcspy_gc_driver_t     *driver;
  gcspy_d_utils_area_t   area;

  int totalUsedSpace[2];
  int totalCardTable[3];
  int totalPromotion[2];
  int totalRoots;
  int totalMarking;
} mc_driver_t;

void
mcDriverInit (mc_driver_t *mcDriver,
	      gcspy_gc_driver_t *gcDriver,
	      const char *name,
	      unsigned tileSize,
	      char *start,
	      char *end);

void
mcDriverZero (mc_driver_t *mcDriver,
	      char *limit);

#if 0
void
mcDriverLimit (mc_driver_t *mcDriver,
	       char *limit);
#endif //0

void
mcDriverSetEnd (mc_driver_t *mcDriver,
		char *end);

void
mcDriverCard (mc_driver_t *mcDriver,
	      char *start,
	      int size,
	      int state);

void
mcDriverPromotion (mc_driver_t *mcDriver,
		   char *start,
		   char *end);

void
mcDriverRoot (mc_driver_t *mcDriver,
	      char *start);

void
mcDriverMarked (mc_driver_t *mcDriver,
		char *start);

void
mcDriverSend (mc_driver_t *mcDriver,
	      unsigned event);

#endif //_EVM_MC_DRIVER_H_
