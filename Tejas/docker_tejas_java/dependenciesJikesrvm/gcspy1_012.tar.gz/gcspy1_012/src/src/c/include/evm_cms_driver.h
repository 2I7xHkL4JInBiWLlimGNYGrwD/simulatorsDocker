/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  evm_cms_driver.h
 **
 **  Driver instance for the EVM CM&S collector
 **/

#ifndef _EVM_CMS_DRIVER_H_

#define _EVM_CMS_DRIVER_H_

#include "gcspy_gc_driver.h"
#include "gcspy_d_utils.h"

#define CMS_USED_SPACE_STREAM    0
#define CMS_CARD_TABLE_STREAM    1
#define CMS_PROMOTION_STREAM     2
#define CMS_ROOTS_STREAM         3
#define CMS_MARKING_STREAM       4
#define CMS_CHUNKS_STREAM        5
#define CMS_OBJECTS_STREAM       6
#define CMS_MOD_UNION_STREAM     7

#define CMS_CARD_STATE_CLEAN          4
#define CMS_CARD_STATE_SUMMARISED     3
#define CMS_CARD_STATE_OVERFLOWN      2
#define CMS_CARD_STATE_PRECLEANED     1
#define CMS_CARD_STATE_DIRTY          0

#define CMS_MOD_UNION_STATE_CLEAN     1
#define CMS_MOD_UNION_STATE_DIRTY     0

typedef struct {
  int usedSpace;
  int cards;
  int promotion;
  int roots;
  int marking;
  int freeChunks;
  int objects;
  int modUnion;
} cms_driver_tile_t;

typedef struct {
  gcspy_gc_driver_t     *driver;
  gcspy_d_utils_area_t   area;

  char                  *markingFront;
  char                  *sweepingFront;

  int                    totalUsedSpace[2];
  int                    totalCardTable[5];
  int                    totalPromotion[2];
  int                    totalRoots;
  int                    totalMarking;
  int                    totalChunks;
  int                    totalObjects;
  int                    totalModUnion[2];
} cms_driver_t;

void
cmsDriverInit (cms_driver_t *cmsDriver,
	       gcspy_gc_driver_t *gcDriver,
	       char *name,
	       unsigned blockSize,
	       char *start,
	       char *end);

void
cmsDriverZero (cms_driver_t *cmsDriver,
	       char *limit);

void
cmsDriverObject (cms_driver_t *cmsDriver,
		 char *start,
		 int size);

void
cmsDriverFreeChunk (cms_driver_t *cmsDriver,
		    char *start,
		    int size);

void
cmsDriverCard (cms_driver_t *cmsDriver,
	       char *start,
	       int size,
	       int state);

void
cmsDriverModUnion (cms_driver_t *cmsDriver,
		   char *start,
		   int size,
		   int state);

void
cmsDriverPromoted (cms_driver_t *cmsDriver,
		   char *start,
		   int size);

void
cmsDriverRoot (cms_driver_t *cmsDriver,
	       char *start);

void
cmsDriverMarked (cms_driver_t *cmsDriver,
		 char *start);

void
cmsDriverMarkingFront (cms_driver_t *cmsDriver,
		       char *markingFront);

void
cmsDriverSweepingFront (cms_driver_t *cmsDriver,
			char *sweepingFront);

void
cmsDriverSend (cms_driver_t *cmsDriver,
	       unsigned event);

#endif //_EVM_CMS_DRIVER_H_
