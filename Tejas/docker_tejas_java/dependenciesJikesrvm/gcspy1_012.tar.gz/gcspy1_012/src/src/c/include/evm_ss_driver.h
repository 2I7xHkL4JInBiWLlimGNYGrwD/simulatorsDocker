/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  evm_ss_driver.h
 **
 **  Driver instance for the EVM S-S collector
 **/

#ifndef _EVM_SS_DRIVER_H_

#define _EVM_SS_DRIVER_H_

#include "gcspy_gc_driver.h"
#include "gcspy_d_utils.h"

#define SS_USED_SPACE_STREAM    0
#define SS_ROOTS_STREAM         1

typedef struct {
  int usedSpace;
  int roots;
} ss_driver_tile_t;

typedef struct {
  gcspy_gc_driver_t     *driver;
  gcspy_d_utils_area_t   areas[2];
  ss_driver_tile_t      *tiles;
  int                    semispace;
  /* allTileNum includes the middle unused tiles */
  int                    allTileNum;
  int                    blockSize;

  int                    totalRoots;
  int                    totalUsedSpace[2];
} ss_driver_t;

void
ssDriverInit (ss_driver_t *ssDriver,
	      gcspy_gc_driver_t *gcDriver,
	      const char *name,
	      unsigned tileSize,
	      char *start0,
	      char *end0,
	      char *start1,
	      char *end1);

void
ssDriverZero (ss_driver_t *ssDriver);

void
ssDriverSetSemispace (ss_driver_t *ssDriver,
		      int semispace,
		      char *limit);

void
ssDriverRoot (ss_driver_t *ssDriver,
	      char *start);

void
ssDriverSend (ss_driver_t *ssDriver,
	      unsigned event);

#endif //_EVM_SS_DRIVER_H_
