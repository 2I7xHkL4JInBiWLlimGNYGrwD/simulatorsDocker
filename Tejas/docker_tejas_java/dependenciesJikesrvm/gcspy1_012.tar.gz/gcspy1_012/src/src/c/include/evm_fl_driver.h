/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  evm_fl_driver.h
 **
 **  Driver instance for the EVM M&S free lists
 **/

#ifndef _EVM_FL_DRIVER_H_

#define _EVM_FL_DRIVER_H_

#include "gcspy_gc_driver.h"
#include "gcspy_d_utils.h"

#define FL_LENGTH_STREAM         0
#define FL_SIZE_STREAM           1

typedef struct {
  int length;
  int size;
} fl_driver_tile_t;

typedef struct {
  gcspy_gc_driver_t     *driver;

  int                    tileNum;
  fl_driver_tile_t      *tiles;

  int                    spaceSize;

  int                    exactLimit;
  int                    rangeLimit;

  int                    totalLength;
  int                    totalSize[2];
} fl_driver_t;

void
flDriverInit (fl_driver_t *flDriver,
	      gcspy_gc_driver_t *gcDriver,
	      const char *name,
	      int tileNum,
	      int spaceSize);

void
flDriverFreeChunk (fl_driver_t *flDriver,
		   int list,
		   int size);

void
flDriverSetTileNameExact (fl_driver_t *flDriver,
			  int list,
			  int size);

void
flDriverSetTileNameRange (fl_driver_t *flDriver,
			  int list,
			  int min,
			  int max);

void
flDriverSetTileNameLarge (fl_driver_t *flDriver,
			  int list,
			  int min);

void
flDriverZero (fl_driver_t *flDriver);

void
flDriverSend (fl_driver_t *flDriver,
	      unsigned event);

#endif //_EVM_FL_DRIVER_H_
