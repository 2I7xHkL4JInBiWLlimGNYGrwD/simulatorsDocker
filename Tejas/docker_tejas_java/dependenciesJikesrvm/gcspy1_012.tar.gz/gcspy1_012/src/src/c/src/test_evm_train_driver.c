/**
 **  gcspy_test_train_driver.c
 **
 **  Tests the Train Driver
 **/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "evm_train_driver.h"
#include "gcspy_main_server.h"
#include "gcspy_timer.h"

#ifdef _SPARC_
#include <thread.h>
#endif //_SPARC_

#ifdef _LINUX_
#include <pthread.h>
#endif //_LINUX_

#define MAX_LEN      ( 128 * 1024 )

#define REGION_SIZE   ( 64 * 1024 )

#define START           0

#define FIRST_REGION    0
#define SECOND_REGION   REGION_SIZE
#define THIRD_REGION    ( 2 * REGION_SIZE )
#define FOURTH_REGION   ( 3 * REGION_SIZE )
#define FIFTH_REGION    ( 4 * REGION_SIZE )

#define CAR_NUM         10
#define TRAIN_NUM        4

#define END           ( 4 * 1024 * 1024 )

static gcspy_main_server_t server;
static train_driver_t driver;

#define CARD_SIZE  512

#define START_GC_EVENT      0
#define END_GC_EVENT        1

#ifdef  __cplusplus
extern "C" {
#endif //__cplusplus
static void *
mainLoop (void *arg) {
  int count = 0;
  int stage;
  char *end;
  int event = START_GC_EVENT;

  while ( 1 ) {
    gcspy_wait(1000);

    if (gcspy_mainServerIsConnected(&server, event)) {
      gcspy_mainServerStartCompensationTimer(&server);

      stage = count % 2;
      ++count;

#if 0
      if ((count % 16) < 8)
	end = (char *) (END / 2);
      else
	end = (char *) END;
#endif //0
      end = (char *) END;
      trainZero(&driver, end,
		(stage == 0) ? 0 : CAR_NUM,
		(stage == 0) ? TRAIN_NUM : (TRAIN_NUM + 2));

      trainStandardRegion(&driver, 0, 1, 0, 10000,
			  1000, 2000, 3000, 4000);
      trainStandardRegion(&driver, 1, 2, 0, 20000,
			  8000, 4000, 2000, 1000);
      trainStandardRegion(&driver, 17, 0, 1, 10000,
			  1000, 2000, 3000, 4000);
      trainStandardRegion(&driver, 18, 0, 2, 20000,
			  8000, 4000, 2000, 1000);
      trainStandardRegion(&driver, 20, 0, 0, 20000,
			  1000, 2000, 3000, 4000);

      trainOversizedRegion(&driver, 4, 3, 2, 1, 80000,
			  1, 0, 0, 1);
      trainOversizedRegion(&driver, 10, 2, 1, 2, 90000,
			  1, 1, 0, 0);
      trainOversizedRegion(&driver, 13, 2, 1, 1, 10000,
			  0, 0, 0, 0);

      trainPopularRegion(&driver, 7, 30000,
			 1000, 2000, 3000, 4000);
      trainPopularRegion(&driver, 2, 40000,
			  8000, 4000, 2000, 1000);
      trainPopularRegion(&driver, 19, 10000,
			 1000, 2000, 3000, 4000);

      trainCard(&driver, (char *) SECOND_REGION, CARD_SIZE, 
		REGION_CARD_STATE_SUMMARISED);
      trainCard(&driver, (char *) THIRD_REGION, CARD_SIZE, 
		REGION_CARD_STATE_OVERFLOWN);
      trainCard(&driver, (char *) THIRD_REGION + CARD_SIZE, CARD_SIZE, 
		REGION_CARD_STATE_SUMMARISED);
      trainCard(&driver, (char *) FIFTH_REGION, CARD_SIZE, 
		REGION_CARD_STATE_SUMMARISED);
      trainCard(&driver, (char *) FIFTH_REGION + CARD_SIZE, CARD_SIZE, 
		REGION_CARD_STATE_DIRTY);

      if (stage == 1) {
	trainCar(&driver, 0,
		 0, 0, CAR_TYPE_STANDARD,
		 REGION_SIZE - 12, REGION_SIZE, 546,
		 100, 2000, 10, 1000,
		 CAR_HIGHER_REFS_YES,
		 CAR_IN_CS_YES, REGION_SIZE / 100,
		 REGION_SIZE / 100, REGION_SIZE / 10,
		 REGION_SIZE / 50, REGION_SIZE / 80);
	trainCar(&driver, 1,
		 0, 1, CAR_TYPE_STANDARD,
		 REGION_SIZE - 24, REGION_SIZE, 600,
		 110, 3000, 7, 2000,
		 CAR_HIGHER_REFS_NO,
		 CAR_IN_CS_NO, 0,
		 REGION_SIZE / 100, REGION_SIZE / 10,
		 REGION_SIZE / 50, REGION_SIZE / 80);
	trainCar(&driver, 2,
		 0, 2, CAR_TYPE_STANDARD,
		 REGION_SIZE - 3000, REGION_SIZE, 234,
		 90, 2000, 9, 1000,
		 CAR_HIGHER_REFS_NO,
		 CAR_IN_CS_YES, 0,
		 REGION_SIZE / 100, REGION_SIZE / 10,
		 REGION_SIZE / 50, REGION_SIZE / 80);
	trainCar(&driver, 3,
		 1, 0, CAR_TYPE_OVERSIZED,
		 3*REGION_SIZE - 200, 3*REGION_SIZE, 1,
		 23, 2000, 13, 1000,
		 CAR_HIGHER_REFS_YES,
		 CAR_IN_CS_YES, REGION_SIZE / 10,
		 REGION_SIZE / 100, REGION_SIZE / 10,
		 REGION_SIZE / 50, REGION_SIZE / 80);
	trainCar(&driver, 4,
		 1, 1, CAR_TYPE_STANDARD,
		 REGION_SIZE - 10000, REGION_SIZE, 234,
		 90, 5000, 7, 1000,
		 CAR_HIGHER_REFS_YES,
		 CAR_IN_CS_YES, REGION_SIZE / 10,
		 REGION_SIZE / 100, REGION_SIZE / 10,
		 REGION_SIZE / 50, REGION_SIZE / 80);
	trainCar(&driver, 5,
		 1, 2, CAR_TYPE_OVERSIZED,
		 4*REGION_SIZE - 2000, 4*REGION_SIZE, 1,
		 50, 2000, 7, 5000,
		 CAR_HIGHER_REFS_NO,
		 CAR_IN_CS_NO, 0,
		 REGION_SIZE / 100, REGION_SIZE / 10,
		 REGION_SIZE / 50, REGION_SIZE / 80);
	trainCar(&driver, 6,
		 2, 0, CAR_TYPE_STANDARD,
		 REGION_SIZE - 128, REGION_SIZE, 516,
		 50, 3000, 7, 2000,
		 CAR_HIGHER_REFS_YES,
		 CAR_IN_CS_NO, 0,
		 REGION_SIZE / 100, REGION_SIZE / 10,
		 REGION_SIZE / 50, REGION_SIZE / 80);
	trainCar(&driver, 7,
		 2, 1, CAR_TYPE_POPULAR,
		 48, 64, 1,
		 1045, 6000, 9, 5000,
		 CAR_HIGHER_REFS_NO,
		 CAR_IN_CS_YES, 64,
		 64 / 100, 64 / 10, 64 / 50, 64 / 80);
	trainCar(&driver, 8,
		 2, 2, CAR_TYPE_POPULAR,
		 56, 64, 1,
		 2034, 5000, 8, 3000,
		 CAR_HIGHER_REFS_YES,
		 CAR_IN_CS_NO, 0,
		 64 / 100, 64 / 10, 64 / 50, 64 / 80);
	trainCar(&driver, 9,
		 3, 0, CAR_TYPE_STANDARD,
		 REGION_SIZE - 245, REGION_SIZE, 1000,
		 120, 2000, 7, 2000,
		 CAR_HIGHER_REFS_YES,
		 CAR_IN_CS_YES, REGION_SIZE / 100,
		 REGION_SIZE / 100, REGION_SIZE / 10,
		 REGION_SIZE / 50, REGION_SIZE / 80);
      }

      trainTrain(&driver, 0,
		 0, 5*REGION_SIZE, 10000, 5,
		 10, 6*REGION_SIZE, 156, TRAIN_HIGHER_REFS_YES,
		 0, 0,
		 6*REGION_SIZE / 40, 6*REGION_SIZE / 25,
		 6*REGION_SIZE / 20, 6*REGION_SIZE / 50);
      trainTrain(&driver, 1,
		 1, 3*REGION_SIZE, 20000, 10,
		 20, 4*REGION_SIZE, 1000, TRAIN_HIGHER_REFS_NO,
		 0, 0,
		 4*REGION_SIZE / 40, 4*REGION_SIZE / 25,
		 4*REGION_SIZE / 20, 4*REGION_SIZE / 50);
      trainTrain(&driver, 2,
		 2, 10*REGION_SIZE, 40000, 20,
		 30, 11*REGION_SIZE, 200, TRAIN_HIGHER_REFS_YES,
		 14, REGION_SIZE,
		 11*REGION_SIZE / 40, 11*REGION_SIZE / 25,
		 11*REGION_SIZE / 20, 11*REGION_SIZE / 50);
      trainTrain(&driver, 3,
		 3, 9*REGION_SIZE, 20000, 30,
		 5, 10*REGION_SIZE, 500, TRAIN_HIGHER_REFS_YES,
		 10, 3*REGION_SIZE,
		 10*REGION_SIZE / 40, 10*REGION_SIZE / 25,
		 10*REGION_SIZE / 20, 10*REGION_SIZE / 50);
      if (stage == 1) {
	trainTrain(&driver, 4,
		   4, 5*REGION_SIZE, 50000, 10,
		   3, 7*REGION_SIZE, 300, TRAIN_HIGHER_REFS_NO,
		   0, 0,
		   7*REGION_SIZE / 40, 7*REGION_SIZE / 25,
		   7*REGION_SIZE / 20, 7*REGION_SIZE / 50);
	trainTrain(&driver, 5,
		   5, 3*REGION_SIZE, 30000, 20,
		   20, 8*REGION_SIZE, 1000, TRAIN_HIGHER_REFS_YES,
		   200, 7*REGION_SIZE,
		   8*REGION_SIZE / 40, 8*REGION_SIZE / 25,
		   8*REGION_SIZE / 20, 8*REGION_SIZE / 50);
      }

      gcspy_mainServerStopCompensationTimer(&server);

      if (gcspy_mainServerIsConnected(&server, event)) {
	printf("CONNECTED\n");
	trainSend(&driver, event);
      }
      gcspy_mainServerSafepoint(&server, event);
      if (event == START_GC_EVENT)
	event = END_GC_EVENT;
      else
	event = START_GC_EVENT;
    }
  }

  return NULL;
}
#ifdef  __cplusplus
}
#endif //__cplusplus

int
main (int argc, char *argv[]) {
  char generalInfo[256];
  gcspy_date_time_t time;

#ifdef _SPARC_
  thread_t tid;
#endif //_SPARC_

#ifdef _LINUX_
  pthread_t tid;
#endif //_LINUX_

  gcspy_gc_driver_t *regionDriver;
  gcspy_gc_driver_t *carDriver;
  gcspy_gc_driver_t *trainDriver;
  int port;
  int res;

  if (argc != 2) {
    gcspy_raise_error("Wrong number of arguments");
  }
  port = atoi(argv[1]);

  printf("-- Initialising main server on port %d\n", port);
  gcspy_mainServerInit(&server, port, MAX_LEN, "Train Driver Test", 1);

  time = gcspy_getDateTime();
  strcpy(generalInfo, "GCspy Test\n\n");
  strcat(generalInfo, "Start Time:\n  ");
  strcpy(generalInfo, gcspy_formatDateTime(time));
  strcat(generalInfo, "\nApplication:\n  Train Driver Test\n\n");
  strcat(generalInfo, "2 Spaces");
  gcspy_mainServerSetGeneralInfo(&server, generalInfo);

  printf("--   Setting event 0\n");
  gcspy_mainServerAddEvent(&server, START_GC_EVENT, "Start Young GC");
  printf("--   Setting event 1\n");
  gcspy_mainServerAddEvent(&server, END_GC_EVENT, "End Young GC");
 
  printf("--   Setting up driver 0\n");
  trainDriver = gcspy_mainServerAddDriver(&server);
  printf("--   Setting up driver 1\n");
  carDriver = gcspy_mainServerAddDriver(&server);
  printf("--   Setting up driver 2\n");
  regionDriver = gcspy_mainServerAddDriver(&server);

  trainInit(&driver,
	    regionDriver, carDriver, trainDriver,
	    "Train Generation",
	    REGION_SIZE,
	    (char *) START,
	    (char *) END,
	    0,
	    0);

#ifdef _SPARC_
  res = thr_create(NULL, 0, mainLoop, NULL, THR_BOUND, &tid);
#endif //_SPARC_

#ifdef _LINUX_
  res = pthread_create(&tid, NULL, mainLoop, NULL);
#endif //_LINUX_

  if (res != 0) {
    printf("Couldn't create thread.\n");
    exit(-1);
  }

  gcspy_mainServerOuterLoop(&server);
}
