/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  evm_ss_driver.c
 **
 **  Driver instance for the EVM S-S collector
 **/

#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "gcspy_gc_stream.h"
#include "evm_ss_driver.h"
#include "gcspy_utils.h"

#define MIDDLE_TILES 0

static int
ssDriverGetTileIndex (ss_driver_t *ssDriver, char *addr) {
  int i;
  for (i = 0; i < 2; ++i) {
    if (gcspy_d_utils_addr_in_range(&(ssDriver->areas[i]), addr))
      return gcspy_d_utils_get_index(&(ssDriver->areas[i]), addr);
  }
  printf("BARF 1!\n");
  return -1;
}

static char *
ssDriverGetTileAddr (ss_driver_t *ssDriver, int index) {
  int i;
  for (i = 0; i < 2; ++i) {
    if (gcspy_d_utils_index_in_range(&(ssDriver->areas[i]), index))
      return gcspy_d_utils_get_addr(&(ssDriver->areas[i]), index);
  }
  printf("BARF 2!\n");
  return NULL;
}

static ss_driver_tile_t *
ssDriverGetTile (ss_driver_t *ssDriver, int index) {
  return &ssDriver->tiles[index];
}

void
ssDriverZero (ss_driver_t *ssDriver) {
  int i;
  ss_driver_tile_t *tile;

  for (i = 0; i < ssDriver->allTileNum; ++i) {
    tile = ssDriverGetTile(ssDriver, i);
    tile->usedSpace = 0;
    tile->roots = 0;
  }

  ssDriver->totalRoots = 0;
  ssDriver->totalUsedSpace[0] = 0;
}

void
ssDriverSetSemispace (ss_driver_t *ssDriver,
		      int semispace,
		      char *limit) {
  gcspy_d_utils_area_t *area = &ssDriver->areas[semispace];

  ssDriver->semispace = semispace;
  ssDriver->totalUsedSpace[1] = area->end - area->start;
  ssDriver->totalUsedSpace[0] += (limit - area->start);
  gcspy_dUtilsSetPerc(area,
		      area->start,
		      limit,
		      offsetof(ss_driver_tile_t, usedSpace));
}

void
ssDriverRoot (ss_driver_t *ssDriver,
	      char *start) {
  int i;
  ++ssDriver->totalRoots;
  for (i = 0; i < 2; ++i) {
    if (gcspy_d_utils_addr_in_range(&(ssDriver->areas[i]), start)) {
      gcspy_dUtilsAddSingle(&(ssDriver->areas[i]), start, 
			    offsetof(ss_driver_tile_t, roots));
      return;
    }
  }
  printf("BARF 3!\n");
}

void
ssDriverSend (ss_driver_t *ssDriver, unsigned event) {
  int i;
  ss_driver_tile_t *tile;
  gcspy_gc_driver_t *driver = ssDriver->driver;
  int semispace = ssDriver->semispace;
  double perc;
  char tmp[128];
  int size;

  gcspy_driverStartComm(driver);

  gcspy_driverStream(driver, SS_USED_SPACE_STREAM, ssDriver->allTileNum);
  for (i = 0; i < ssDriver->allTileNum; ++i) {
    tile = ssDriverGetTile(ssDriver, i);
    gcspy_driverStreamIntValue(driver, tile->usedSpace);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, SS_USED_SPACE_STREAM, 2);
  gcspy_driverSummaryValue(driver, ssDriver->totalUsedSpace[0]);
  gcspy_driverSummaryValue(driver, ssDriver->totalUsedSpace[1]);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, SS_ROOTS_STREAM, ssDriver->allTileNum);
  for (i = 0; i < ssDriver->allTileNum; ++i) {
    tile = ssDriverGetTile(ssDriver, i);
    gcspy_driverStreamShortValue(driver, tile->roots);
  }
  gcspy_driverStreamEnd(driver);

#if 0
  /* currently not available */
  gcspy_driverSummary(driver, SS_ROOTS_STREAM, 1);
  gcspy_driverSummaryValue(driver, ssDriver->totalRoots);
  gcspy_driverSummaryEnd(driver);
#endif //0


  gcspy_driverControl(driver);
  gcspy_driverControlValues(driver,
			    GCSPY_GC_DRIVER_CONTROL_UNUSED,
			    ssDriver->areas[1-semispace].firstIndex,
			    ssDriver->areas[1-semispace].blockNum);
  gcspy_driverControlValues(driver,
			    GCSPY_GC_DRIVER_CONTROL_BACKGROUND,
			    ssDriver->areas[0].firstIndex +
			    ssDriver->areas[0].blockNum,
			    MIDDLE_TILES);
  gcspy_driverControlValues(driver,
			    GCSPY_GC_DRIVER_CONTROL_SEPARATOR,
			    ssDriver->areas[1].firstIndex, 1);
  gcspy_driverControlEnd(driver);

  size = (int) ssDriver->areas[semispace].end - 
    (int) ssDriver->areas[semispace].start;
  sprintf(tmp, "Current Size: %s\n", gcspy_formatSize(size));
  gcspy_driverSpaceInfo(driver, tmp);

  gcspy_driverEndComm(driver);
}

void
ssDriverInit (ss_driver_t *ssDriver,
	      gcspy_gc_driver_t *gcDriver,
	      const char *name,
	      unsigned blockSize,
	      char *start0,
	      char *end0,
	      char *start1,
	      char *end1) {
  int i;
  char tmp[256];
  gcspy_gc_stream_t *stream;
  int tileNum0 = gcspy_dUtilsTileNum(start0, end0, blockSize);
  int tileNum1 = gcspy_dUtilsTileNum(start1, end1, blockSize);
  /* tile num for the two spaces */
  int tileNum = tileNum0 + tileNum1;
  /* tile num for the two spaces + middle tiles */
  int allTileNum = tileNum + MIDDLE_TILES;
  int len = allTileNum * sizeof(ss_driver_tile_t);
  ss_driver_tile_t *tiles = (ss_driver_tile_t *) malloc(len);

  if (tiles == NULL) {
    char buffer[256];
    sprintf(buffer, "S-S Driver: could not allocate %d bytes for tile data",
	    len);
    gcspy_raise_error(buffer);
  }    
  
  ssDriver->driver = gcDriver;
  ssDriver->tiles = tiles;
  ssDriver->allTileNum = allTileNum;
  ssDriver->blockSize = blockSize;
  gcspy_dUtilsInit(&(ssDriver->areas[0]),
		   start0, end0,
		   0, blockSize, tileNum0,
		   (char *) tiles, 
		   sizeof(ss_driver_tile_t));
  gcspy_dUtilsInit(&(ssDriver->areas[1]),
		   start1, end1,
		   tileNum0 + MIDDLE_TILES, blockSize, tileNum1,
		   (char *) tiles +
		   (tileNum0 + MIDDLE_TILES) * sizeof(ss_driver_tile_t), 
		   sizeof(ss_driver_tile_t));

  if (blockSize < 1024)
    sprintf(tmp, "Block Size: %d bytes\n", blockSize);
  else
    sprintf(tmp, "Block Size: %dK\n", (blockSize / 1024));
  gcspy_driverInit(gcDriver, -1, name, "S-S GC",
		   "Block ", tmp, allTileNum, NULL, 0);
  for (i = 0; i < allTileNum; ++i) {
    if (gcspy_d_utils_index_in_range(&(ssDriver->areas[0]), i))
      gcspy_dUtilsRangeString(&(ssDriver->areas[0]), i, tmp);
    else if (gcspy_d_utils_index_in_range(&(ssDriver->areas[1]), i))
      gcspy_dUtilsRangeString(&(ssDriver->areas[1]), i, tmp);
    else
      strcpy(tmp, "");
    gcspy_driverSetTileName(gcDriver, i, tmp);
  }

  stream = gcspy_driverAddStream(gcDriver, SS_USED_SPACE_STREAM);
  gcspy_streamInit(stream, SS_USED_SPACE_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Used Space",
		   0, blockSize,
		   0, 0,
		   "Used Space: ", " bytes",
		   GCSPY_GC_STREAM_PRESENTATION_PERCENT,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Red"));

  stream = gcspy_driverAddStream(gcDriver, SS_ROOTS_STREAM);
  gcspy_streamInit(stream, SS_ROOTS_STREAM,
		   GCSPY_GC_STREAM_SHORT_TYPE,
		   "Roots",
		   0, gcspy_d_utils_roots_per_block(blockSize),
		   0, 0,
		   "Roots: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Green"));

  ssDriverZero(ssDriver);
}
