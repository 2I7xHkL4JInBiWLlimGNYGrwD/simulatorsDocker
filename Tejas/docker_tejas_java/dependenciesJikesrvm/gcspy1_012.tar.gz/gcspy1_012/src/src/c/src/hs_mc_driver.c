/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  hs_mc_driver.c
 **
 **  Driver instance for the H-S M&C collector
 **/

#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include "gcspy_gc_stream.h"
#include "hs_mc_driver.h"

static mc_driver_tile_t *
mcDriverAllocateStats (int tileNum) {
  int len = tileNum * sizeof(mc_driver_tile_t);
  mc_driver_tile_t *tiles = (mc_driver_tile_t *) malloc(len);
  if (tiles == NULL) {
    char buffer[256];
    sprintf(buffer, "M&C Driver: could not allocate %d bytes for tile data",
	    len);
    gcspy_raise_error(buffer);
  }
  return tiles;
}

static void
mcDriverSetupTileNames (mc_driver_t *mcDriver,
			int from,
			int to) {
  int i;
  char tmp[256];
  for (i = from; i < to; ++i) {
    gcspy_dUtilsRangeString(&(mcDriver->area), i, tmp);
    gcspy_driverSetTileName(mcDriver->driver, i, tmp);
  }
}

static mc_driver_tile_t *
mcDriverGetTile (mc_driver_t *mcDriver, int index) {
  return (mc_driver_tile_t *)
    gcspy_d_utils_get_stats_struct(&(mcDriver->area), index, 0);
}

static int
mcDriverGetTileIndex (mc_driver_t *mcDriver, char *addr) {
  return gcspy_d_utils_get_index(&(mcDriver->area), addr);
}

static char *
mcDriverGetTileAddr (mc_driver_t *mcDriver, int index) {
  return gcspy_d_utils_get_addr(&(mcDriver->area), index);
}

void
hsMCDriverZero (mc_driver_t *mcDriver,
		char *end) {
  int i;
  mc_driver_tile_t *tile;
  int totalSpace = end - mcDriver->area.start;

  if (end != mcDriver->area.end) {
    int tileNum = gcspy_dUtilsTileNum(mcDriver->area.start,
				      end,
				      mcDriver->area.blockSize); 
    /* printf("resizing to %8x, tileNum = %d\n", end, tileNum); */
    mcDriver->area.end = end;
    mcDriver->area.blockNum = tileNum;
    free(mcDriver->area.stats);
    mcDriver->area.stats = (char *) mcDriverAllocateStats(tileNum);

    gcspy_driverResize(mcDriver->driver, tileNum);
    mcDriverSetupTileNames(mcDriver, 0, tileNum);
  }

  for (i = 0; i < mcDriver->area.blockNum; ++i) {
    tile = mcDriverGetTile(mcDriver, i);
    tile->usedSpace = 0;
    tile->deadSpace = 0;
    tile->cards = MC_CARD_STATE_CLEAN;
    tile->directAlloc = 0;
    tile->promotion = 0;
    tile->objects = 0;
    tile->marks = 0;
    tile->refs = 0;
    tile->refsToLeft = 0;
    tile->refsToRight = 0;
    tile->refsToYoung = 0;
    tile->refsToPerm = 0;
    tile->internalRefs = 0;
  }

  mcDriver->totalUsedSpace[0] = 0;
  mcDriver->totalUsedSpace[1] = totalSpace;
  mcDriver->totalDeadSpace[0] = 0;
  mcDriver->totalDeadSpace[1] = totalSpace;
  for (i = 0; i < MC_CARD_STATE_NUM; ++i)
    mcDriver->totalCards[i] = 0;
  mcDriver->totalDirectAlloc[0] = 0;
  mcDriver->totalDirectAlloc[1] = totalSpace;
  mcDriver->totalPromotion[0] = 0;
  mcDriver->totalPromotion[1] = totalSpace;
  mcDriver->totalObjects = 0;
  mcDriver->totalMarks = 0;
  mcDriver->totalRefs = 0;
  mcDriver->totalRefsToLeft = 0;
  mcDriver->totalRefsToRight = 0;
  mcDriver->totalRefsToYoung = 0;
  mcDriver->totalRefsToPerm = 0;
  mcDriver->totalInternalRefs = 0;
}

void
hsMCDriverSetLimit (mc_driver_t *mcDriver,
		    char *limit) {
  mcDriver->totalUsedSpace[0] += (limit - mcDriver->area.start);
  gcspy_dUtilsSetPerc(&(mcDriver->area),
		      mcDriver->area.start,
		      limit,
		      offsetof(mc_driver_tile_t, usedSpace));
}

void
hsMCDriverDeadSpace (mc_driver_t *mcDriver,
		     char *start, char *end) {
  mcDriver->totalDeadSpace[0] += (end - start);
  gcspy_dUtilsSetPerc(&(mcDriver->area), start, end,
		      offsetof(mc_driver_tile_t, deadSpace));
}

void
hsMCDriverCard (mc_driver_t *mcDriver,
		char *start,
		int state) {
  char *end = start + mcDriver->cardSize;
  ++mcDriver->totalCards[state];
  gcspy_dUtilsUpdateEnumDesc(&(mcDriver->area),
			     start, end,
			     offsetof(mc_driver_tile_t, cards),
			     state);
}

void
hsMCDriverDirectAlloc (mc_driver_t *mcDriver,
		       char *start, char *end) {
  mcDriver->totalDirectAlloc[0] += (end - start);
  gcspy_dUtilsSetPerc(&(mcDriver->area), start, end,
		      offsetof(mc_driver_tile_t, directAlloc));
}

void
hsMCDriverPromotion (mc_driver_t *mcDriver,
		     char *start, char *end) {
  mcDriver->totalPromotion[0] += (end - start);
  gcspy_dUtilsSetPerc(&(mcDriver->area), start, end,
		      offsetof(mc_driver_tile_t, promotion));
}

void
hsMCDriverObject (mc_driver_t *mcDriver,
		  char *start, int size) {
  ++mcDriver->totalObjects;
  gcspy_dUtilsAddOne(&(mcDriver->area), start, start + size,
		     offsetof(mc_driver_tile_t, objects));
}

void
hsMCDriverMark (mc_driver_t *mcDriver,
		char *start) {
  ++mcDriver->totalMarks;
  gcspy_dUtilsAddSingle(&(mcDriver->area), start, 
			offsetof(mc_driver_tile_t, marks));
}

void
hsMCDriverRef (mc_driver_t *mcDriver,
	       char *addr) {
  ++mcDriver->totalRefs;
  gcspy_dUtilsAddSingle(&(mcDriver->area), addr, 
			offsetof(mc_driver_tile_t, refs));
}

void
hsMCDriverRefToLeft (mc_driver_t *mcDriver,
		     char *addr) {
  ++mcDriver->totalRefsToLeft;
  gcspy_dUtilsAddSingle(&(mcDriver->area), addr, 
			offsetof(mc_driver_tile_t, refsToLeft));
}

void
hsMCDriverRefToRight (mc_driver_t *mcDriver,
		      char *addr) {
  ++mcDriver->totalRefsToRight;
  gcspy_dUtilsAddSingle(&(mcDriver->area), addr, 
   			offsetof(mc_driver_tile_t, refsToRight));
}

void
hsMCDriverRefToYoung (mc_driver_t *mcDriver,
		      char *addr) {
  ++mcDriver->totalRefsToYoung;
  gcspy_dUtilsAddSingle(&(mcDriver->area), addr, 
			offsetof(mc_driver_tile_t, refsToYoung));
}

void
hsMCDriverRefToPerm (mc_driver_t *mcDriver,
		     char *addr) {
  ++mcDriver->totalRefsToPerm;
  gcspy_dUtilsAddSingle(&(mcDriver->area), addr, 
			offsetof(mc_driver_tile_t, refsToPerm));
}

void
hsMCDriverInternalRef (mc_driver_t *mcDriver,
		       char *addr) {
  char *r = *((char **) addr);

  ++mcDriver->totalInternalRefs;
  gcspy_dUtilsAddSingle(&(mcDriver->area), r, 
			offsetof(mc_driver_tile_t, internalRefs));
  if (r < addr) {
    hsMCDriverRefToLeft(mcDriver, addr);
  } else if (r > addr) {
    hsMCDriverRefToRight(mcDriver, addr);
  }
}

void
hsMCDriverSend (mc_driver_t *mcDriver, unsigned event) {
  int i;
  mc_driver_tile_t *tile;
  gcspy_gc_driver_t *driver = mcDriver->driver;
  int tileNum = mcDriver->area.blockNum;
  char tmp[128];
  int size;

  gcspy_driverStartComm(driver);

  gcspy_driverStream(driver, MC_USED_SPACE_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = mcDriverGetTile(mcDriver, i);
    gcspy_driverStreamIntValue(driver, tile->usedSpace);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, MC_USED_SPACE_STREAM, 2);
  gcspy_driverSummaryValue(driver, mcDriver->totalUsedSpace[0]);
  gcspy_driverSummaryValue(driver, mcDriver->totalUsedSpace[1]);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, MC_DEAD_SPACE_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = mcDriverGetTile(mcDriver, i);
    gcspy_driverStreamIntValue(driver, tile->deadSpace);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, MC_DEAD_SPACE_STREAM, 2);
  gcspy_driverSummaryValue(driver, mcDriver->totalDeadSpace[0]);
  gcspy_driverSummaryValue(driver, mcDriver->totalDeadSpace[1]);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, MC_CARD_TABLE_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = mcDriverGetTile(mcDriver, i);
    gcspy_driverStreamByteValue(driver, tile->cards);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, MC_CARD_TABLE_STREAM, MC_CARD_STATE_NUM);
  for (i = 0; i < MC_CARD_STATE_NUM; ++i)
    gcspy_driverSummaryValue(driver, mcDriver->totalCards[i]);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, MC_DIRECT_ALLOC_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = mcDriverGetTile(mcDriver, i);
    gcspy_driverStreamIntValue(driver, tile->directAlloc);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, MC_DIRECT_ALLOC_STREAM, 2);
  gcspy_driverSummaryValue(driver, mcDriver->totalDirectAlloc[0]);
  gcspy_driverSummaryValue(driver, mcDriver->totalDirectAlloc[1]);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, MC_PROMOTION_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = mcDriverGetTile(mcDriver, i);
    gcspy_driverStreamIntValue(driver, tile->promotion);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, MC_PROMOTION_STREAM, 2);
  gcspy_driverSummaryValue(driver, mcDriver->totalPromotion[0]);
  gcspy_driverSummaryValue(driver, mcDriver->totalPromotion[1]);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, MC_OBJECTS_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = mcDriverGetTile(mcDriver, i);
    gcspy_driverStreamIntValue(driver, tile->objects);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, MC_OBJECTS_STREAM, 1);
  gcspy_driverSummaryValue(driver, mcDriver->totalObjects);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, MC_MARKING_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = mcDriverGetTile(mcDriver, i);
    gcspy_driverStreamIntValue(driver, tile->marks);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, MC_MARKING_STREAM, 1);
  gcspy_driverSummaryValue(driver, mcDriver->totalMarks);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, MC_REFS_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = mcDriverGetTile(mcDriver, i);
    gcspy_driverStreamIntValue(driver, tile->refs);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, MC_REFS_STREAM, 1);
  gcspy_driverSummaryValue(driver, mcDriver->totalRefs);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, MC_REFS_TO_LEFT_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = mcDriverGetTile(mcDriver, i);
    gcspy_driverStreamIntValue(driver, tile->refsToLeft);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, MC_REFS_TO_LEFT_STREAM, 1);
  gcspy_driverSummaryValue(driver, mcDriver->totalRefsToLeft);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, MC_REFS_TO_RIGHT_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = mcDriverGetTile(mcDriver, i);
    gcspy_driverStreamIntValue(driver, tile->refsToRight);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, MC_REFS_TO_RIGHT_STREAM, 1);
  gcspy_driverSummaryValue(driver, mcDriver->totalRefsToRight);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, MC_REFS_TO_YOUNG_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = mcDriverGetTile(mcDriver, i);
    gcspy_driverStreamIntValue(driver, tile->refsToYoung);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, MC_REFS_TO_YOUNG_STREAM, 1);
  gcspy_driverSummaryValue(driver, mcDriver->totalRefsToYoung);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, MC_REFS_TO_PERM_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = mcDriverGetTile(mcDriver, i);
    gcspy_driverStreamIntValue(driver, tile->refsToPerm);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, MC_REFS_TO_PERM_STREAM, 1);
  gcspy_driverSummaryValue(driver, mcDriver->totalRefsToPerm);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, MC_INTERNAL_REFS_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = mcDriverGetTile(mcDriver, i);
    gcspy_driverStreamIntValue(driver, tile->internalRefs);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, MC_INTERNAL_REFS_STREAM, 1);
  gcspy_driverSummaryValue(driver, mcDriver->totalInternalRefs);
  gcspy_driverSummaryEnd(driver);



  size = gcspy_d_utils_get_area_size(&mcDriver->area);
  sprintf(tmp, "Current Size: %s\nCard Size: %d bytes\n",
	  gcspy_formatSize(size),
	  mcDriver->cardSize);
  gcspy_driverSpaceInfo(driver, tmp);

  gcspy_driverEndComm(driver);
}

void
hsMCDriverInit (mc_driver_t *mcDriver,
		gcspy_gc_driver_t *gcDriver,
		const char *name,
		unsigned blockSize,
		unsigned cardSize,
		char *start,
		char *end) {
  char tmp[256];
  gcspy_gc_stream_t *stream;
  int tileNum = gcspy_dUtilsTileNum(start, end, blockSize);
  mc_driver_tile_t *tiles = mcDriverAllocateStats(tileNum);
  
  mcDriver->driver = gcDriver;
  mcDriver->cardSize = cardSize;

  gcspy_dUtilsInit(&(mcDriver->area),
		   start, end,
		   0, blockSize, tileNum,
		   (char *) tiles, sizeof(mc_driver_tile_t));

  if (blockSize < 1024)
    sprintf(tmp, "Block Size: %d bytes\n", blockSize);
  else
    sprintf(tmp, "Block Size: %dK\n", (blockSize / 1024));
  gcspy_driverInit(gcDriver, -1, name, "M&C GC",
		   "Block ", tmp, tileNum, NULL, 1);
  mcDriverSetupTileNames(mcDriver, 0, tileNum);

  stream = gcspy_driverAddStream(gcDriver, MC_USED_SPACE_STREAM);
  gcspy_streamInit(stream, MC_USED_SPACE_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Used Space",
		   0, blockSize,
		   0, 0,
		   "Used Space: ", " bytes",
		   GCSPY_GC_STREAM_PRESENTATION_PERCENT,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Red"));

  stream = gcspy_driverAddStream(gcDriver, MC_DEAD_SPACE_STREAM);
  gcspy_streamInit(stream, MC_DEAD_SPACE_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Dead Space",
		   0, blockSize,
		   0, 0,
		   "Dead Space: ", " bytes",
		   GCSPY_GC_STREAM_PRESENTATION_PERCENT,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Red"));

  stream = gcspy_driverAddStream(gcDriver, MC_CARD_TABLE_STREAM);
  gcspy_streamInit(stream, MC_CARD_TABLE_STREAM,
		   GCSPY_GC_STREAM_BYTE_TYPE,
		   "Card Table",
		   0, MC_CARD_STATE_NUM-1,
		   MC_CARD_STATE_NUM-1, MC_CARD_STATE_NUM-1, 
		   "Card State: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_ENUM,
		   GCSPY_GC_STREAM_PAINT_STYLE_PLAIN, 0,
		   gcspy_colorDBGetColorWithName("Off White"));
  gcspy_streamAddEnumName(stream, MC_CARD_STATE_DIRTY, "DIRTY");
  /* gcspy_streamAddEnumName(stream, MC_CARD_STATE_PRECLEANED, "PRECLEANED"); */
  gcspy_streamAddEnumName(stream, MC_CARD_STATE_YOUNGER, "YOUNGER");
  /* gcspy_streamAddEnumName(stream, MC_CARD_STATE_LAST, "LAST"); */
  gcspy_streamAddEnumName(stream, MC_CARD_STATE_CLEAN, "CLEAN");

  stream = gcspy_driverAddStream(gcDriver, MC_DIRECT_ALLOC_STREAM);
  gcspy_streamInit(stream, MC_DIRECT_ALLOC_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Direct Allocation",
		   0, blockSize,
		   0, 0,
		   "Direct Allocation: ", " bytes",
		   GCSPY_GC_STREAM_PRESENTATION_PERCENT,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Magenta"));

  stream = gcspy_driverAddStream(gcDriver, MC_PROMOTION_STREAM);
  gcspy_streamInit(stream, MC_PROMOTION_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Promotion",
		   0, blockSize,
		   0, 0,
		   "Promotion: ", " bytes",
		   GCSPY_GC_STREAM_PRESENTATION_PERCENT,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Magenta"));

  stream = gcspy_driverAddStream(gcDriver, MC_OBJECTS_STREAM);
  gcspy_streamInit(stream, MC_OBJECTS_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Objects",
		   0, gcspy_d_utils_objects_per_block(blockSize),
		   0, 0,
		   "Objects: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Yellow"));

  stream = gcspy_driverAddStream(gcDriver, MC_MARKING_STREAM);
  gcspy_streamInit(stream, MC_MARKING_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Marking",
		   0, gcspy_d_utils_objects_per_block(blockSize),
		   0, 0,
		   "Marked: ", " objects",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Orange"));

  stream = gcspy_driverAddStream(gcDriver, MC_REFS_STREAM);
  gcspy_streamInit(stream, MC_REFS_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Reference Fields",
		   0, gcspy_d_utils_refs_per_block(blockSize),
		   0, 0,
		   "Reference Fields: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Green"));

  stream = gcspy_driverAddStream(gcDriver, MC_REFS_TO_LEFT_STREAM);
  gcspy_streamInit(stream, MC_REFS_TO_LEFT_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Refs To Left",
		   0, gcspy_d_utils_refs_per_block(blockSize),
		   0, 0,
		   "Refs To Left: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Green"));

  stream = gcspy_driverAddStream(gcDriver, MC_REFS_TO_RIGHT_STREAM);
  gcspy_streamInit(stream, MC_REFS_TO_RIGHT_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Refs To Right",
		   0, gcspy_d_utils_refs_per_block(blockSize),
		   0, 0,
		   "Refs To Right: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Green"));

  stream = gcspy_driverAddStream(gcDriver, MC_REFS_TO_YOUNG_STREAM);
  gcspy_streamInit(stream, MC_REFS_TO_YOUNG_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Refs To Young",
		   0, gcspy_d_utils_refs_per_block(blockSize),
		   0, 0,
		   "Refs To Young: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Green"));

  stream = gcspy_driverAddStream(gcDriver, MC_REFS_TO_PERM_STREAM);
  gcspy_streamInit(stream, MC_REFS_TO_PERM_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Refs To Permanent",
		   0, gcspy_d_utils_refs_per_block(blockSize),
		   0, 0,
		   "Refs To Permanent: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Green"));

  stream = gcspy_driverAddStream(gcDriver, MC_INTERNAL_REFS_STREAM);
  gcspy_streamInit(stream, MC_INTERNAL_REFS_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Internal Refs",
		   0, gcspy_d_utils_refs_per_block(blockSize),
		   0, 0,
		   "Internal Refs: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Green"));
}
