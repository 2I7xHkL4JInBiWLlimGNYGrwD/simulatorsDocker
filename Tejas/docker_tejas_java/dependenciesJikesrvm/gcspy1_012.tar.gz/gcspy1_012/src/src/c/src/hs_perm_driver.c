/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  hs_perm_driver.c
 **
 **  Driver instance for the H-S permanent space
 **/

#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include "gcspy_gc_stream.h"
#include "hs_perm_driver.h"

static perm_driver_tile_t *
permDriverAllocateStats (int tileNum) {
  int len = tileNum * sizeof(perm_driver_tile_t);
  perm_driver_tile_t *tiles = (perm_driver_tile_t *) malloc(len);
  if (tiles == NULL) {
    char buffer[256];
    sprintf(buffer, "Perm Driver: could not allocate %d bytes for tile data",
	    len);
    gcspy_raise_error(buffer);
  }
  return tiles;
}

static void
permDriverSetupTileNames (perm_driver_t *permDriver,
			  int from,
			  int to) {
  int i;
  char tmp[256];
  for (i = from; i < to; ++i) {
    gcspy_dUtilsRangeString(&(permDriver->area), i, tmp);
    gcspy_driverSetTileName(permDriver->driver, i, tmp);
  }
}

static perm_driver_tile_t *
permDriverGetTile (perm_driver_t *permDriver, int index) {
  return (perm_driver_tile_t *)
    gcspy_d_utils_get_stats_struct(&(permDriver->area), index, 0);
}

static int
permDriverGetTileIndex (perm_driver_t *permDriver, char *addr) {
  return gcspy_d_utils_get_index(&(permDriver->area), addr);
}

static char *
permDriverGetTileAddr (perm_driver_t *permDriver, int index) {
  return gcspy_d_utils_get_addr(&(permDriver->area), index);
}

void
hsPermDriverZero (perm_driver_t *permDriver,
		  char *end) {
  int i;
  perm_driver_tile_t *tile;
  int totalSpace = end - permDriver->area.start;

  if (end != permDriver->area.end) {
    int tileNum = gcspy_dUtilsTileNum(permDriver->area.start,
				      end,
				      permDriver->area.blockSize); 
    /* printf("resizing to %8x, tileNum = %d\n", end, tileNum); */
    permDriver->area.end = end;
    permDriver->area.blockNum = tileNum;
    free(permDriver->area.stats);
    permDriver->area.stats = (char *) permDriverAllocateStats(tileNum);

    gcspy_driverResize(permDriver->driver, tileNum);
    permDriverSetupTileNames(permDriver, 0, tileNum);
  }

  for (i = 0; i < permDriver->area.blockNum; ++i) {
    tile = permDriverGetTile(permDriver, i);
    tile->usedSpace = 0;
    tile->deadSpace = 0;
    tile->cards = PERM_CARD_STATE_CLEAN;
    tile->alloc = 0;
    tile->objects = 0;
    tile->marks = 0;
    tile->refs = 0;
    tile->refsToYoung = 0;
    tile->refsToOld = 0;
    tile->internalRefs = 0;
  }

  permDriver->totalUsedSpace[0] = 0;
  permDriver->totalUsedSpace[1] = totalSpace;
  permDriver->totalDeadSpace[0] = 0;
  permDriver->totalDeadSpace[1] = totalSpace;
  for (i = 0; i < PERM_CARD_STATE_NUM; ++i)
    permDriver->totalCards[i] = 0;
  permDriver->totalAlloc[0] = 0;
  permDriver->totalAlloc[1] = totalSpace;
  permDriver->totalObjects = 0;
  permDriver->totalMarks = 0;
  permDriver->totalRefs = 0;
  permDriver->totalRefsToYoung[0] = 0;
  permDriver->totalRefsToYoung[1] = 0;
  permDriver->totalRefsToOld[0] = 0;
  permDriver->totalRefsToOld[1] = 0;
  permDriver->totalInternalRefs = 0;
}

void
hsPermDriverSetLimit (perm_driver_t *permDriver,
		     char *limit) {
  permDriver->totalUsedSpace[0] += (limit - permDriver->area.start);
  gcspy_dUtilsSetPerc(&(permDriver->area),
		      permDriver->area.start,
		      limit,
		      offsetof(perm_driver_tile_t, usedSpace));
}


void
hsPermDriverDeadSpace (perm_driver_t *permDriver,
		       char *start, char *end) {
  permDriver->totalDeadSpace[0] += (end - start);
  gcspy_dUtilsSetPerc(&(permDriver->area), start, end,
		      offsetof(perm_driver_tile_t, deadSpace));
}

void
hsPermDriverCard (perm_driver_t *permDriver,
		  char *start,
		  int state) {
  char *end = start + permDriver->cardSize;
  ++permDriver->totalCards[state];
  gcspy_dUtilsUpdateEnumDesc(&(permDriver->area),
			     start, end,
			     offsetof(perm_driver_tile_t, cards),
			     state);
}

void
hsPermDriverAlloc (perm_driver_t *permDriver,
		   char *start, char *end) {
  if (end > start) {
    permDriver->totalAlloc[0] += (end - start);
    gcspy_dUtilsSetPerc(&(permDriver->area), start, end,
			offsetof(perm_driver_tile_t, alloc));
  }
}

void
hsPermDriverObject (perm_driver_t *permDriver,
		    char *start, int size) {
  ++permDriver->totalObjects;
  gcspy_dUtilsAddOne(&(permDriver->area), start, start + size,
		     offsetof(perm_driver_tile_t, objects));
}

void
hsPermDriverMark (perm_driver_t *permDriver,
		  char *start) {
  ++permDriver->totalMarks;
  gcspy_dUtilsAddSingle(&(permDriver->area), start, 
			offsetof(perm_driver_tile_t, marks));
}

void
hsPermDriverRef (perm_driver_t *permDriver,
		 char *addr) {
  ++permDriver->totalRefs;
  ++permDriver->totalRefsToYoung[1];
  ++permDriver->totalRefsToOld[1];
  gcspy_dUtilsAddSingle(&(permDriver->area), addr, 
			offsetof(perm_driver_tile_t, refs));
}

void
hsPermDriverRefToYoung (perm_driver_t *permDriver,
			char *addr) {
  ++permDriver->totalRefsToYoung[0];
  gcspy_dUtilsAddSingle(&(permDriver->area), addr, 
			offsetof(perm_driver_tile_t, refsToYoung));
}

void
hsPermDriverRefToOld (perm_driver_t *permDriver,
			char *addr) {
  ++permDriver->totalRefsToOld[0];
  gcspy_dUtilsAddSingle(&(permDriver->area), addr, 
			offsetof(perm_driver_tile_t, refsToOld));
}

void
hsPermDriverInternalRef (perm_driver_t *permDriver,
			 char *addr) {
  ++permDriver->totalInternalRefs;
  gcspy_dUtilsAddSingle(&(permDriver->area), addr, 
			offsetof(perm_driver_tile_t, internalRefs));
}

void
hsPermDriverSend (perm_driver_t *permDriver, unsigned event) {
  int i;
  perm_driver_tile_t *tile;
  gcspy_gc_driver_t *driver = permDriver->driver;
  int tileNum = permDriver->area.blockNum;
  char tmp[128];
  int size;

  gcspy_driverStartComm(driver);

  gcspy_driverStream(driver, PERM_USED_SPACE_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = permDriverGetTile(permDriver, i);
    gcspy_driverStreamIntValue(driver, tile->usedSpace);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, PERM_USED_SPACE_STREAM, 2);
  gcspy_driverSummaryValue(driver, permDriver->totalUsedSpace[0]);
  gcspy_driverSummaryValue(driver, permDriver->totalUsedSpace[1]);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, PERM_DEAD_SPACE_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = permDriverGetTile(permDriver, i);
    gcspy_driverStreamIntValue(driver, tile->deadSpace);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, PERM_DEAD_SPACE_STREAM, 2);
  gcspy_driverSummaryValue(driver, permDriver->totalDeadSpace[0]);
  gcspy_driverSummaryValue(driver, permDriver->totalDeadSpace[1]);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, PERM_CARD_TABLE_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = permDriverGetTile(permDriver, i);
    gcspy_driverStreamByteValue(driver, tile->cards);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, PERM_CARD_TABLE_STREAM, PERM_CARD_STATE_NUM);
  for (i = 0; i < PERM_CARD_STATE_NUM; ++i)
    gcspy_driverSummaryValue(driver, permDriver->totalCards[i]);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, PERM_ALLOC_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = permDriverGetTile(permDriver, i);
    gcspy_driverStreamIntValue(driver, tile->alloc);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, PERM_ALLOC_STREAM, 2);
  gcspy_driverSummaryValue(driver, permDriver->totalAlloc[0]);
  gcspy_driverSummaryValue(driver, permDriver->totalAlloc[1]);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, PERM_OBJECTS_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = permDriverGetTile(permDriver, i);
    gcspy_driverStreamIntValue(driver, tile->objects);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, PERM_OBJECTS_STREAM, 1);
  gcspy_driverSummaryValue(driver, permDriver->totalObjects);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, PERM_MARKING_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = permDriverGetTile(permDriver, i);
    gcspy_driverStreamIntValue(driver, tile->marks);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, PERM_MARKING_STREAM, 1);
  gcspy_driverSummaryValue(driver, permDriver->totalMarks);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, PERM_REFS_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = permDriverGetTile(permDriver, i);
    gcspy_driverStreamIntValue(driver, tile->refs);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, PERM_REFS_STREAM, 1);
  gcspy_driverSummaryValue(driver, permDriver->totalRefs);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, PERM_REFS_TO_YOUNG_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = permDriverGetTile(permDriver, i);
    gcspy_driverStreamIntValue(driver, tile->refsToYoung);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, PERM_REFS_TO_YOUNG_STREAM, 2);
  gcspy_driverSummaryValue(driver, permDriver->totalRefsToYoung[0]);
  gcspy_driverSummaryValue(driver, permDriver->totalRefsToYoung[1]);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, PERM_REFS_TO_OLD_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = permDriverGetTile(permDriver, i);
    gcspy_driverStreamIntValue(driver, tile->refsToOld);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, PERM_REFS_TO_OLD_STREAM, 2);
  gcspy_driverSummaryValue(driver, permDriver->totalRefsToOld[0]);
  gcspy_driverSummaryValue(driver, permDriver->totalRefsToOld[1]);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, PERM_INTERNAL_REFS_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = permDriverGetTile(permDriver, i);
    gcspy_driverStreamIntValue(driver, tile->internalRefs);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, PERM_INTERNAL_REFS_STREAM, 1);
  gcspy_driverSummaryValue(driver, permDriver->totalInternalRefs);
  gcspy_driverSummaryEnd(driver);



  size = gcspy_d_utils_get_area_size(&permDriver->area);
  sprintf(tmp, "Current Size: %s\n", gcspy_formatSize(size));
  gcspy_driverSpaceInfo(driver, tmp);

  gcspy_driverEndComm(driver);
}

void
hsPermDriverInit (perm_driver_t *permDriver,
		  gcspy_gc_driver_t *gcDriver,
		  const char *name,
		  unsigned blockSize,
		  unsigned cardSize,
		  char *start,
		  char *end) {
  char tmp[256];
  gcspy_gc_stream_t *stream;
  int tileNum = gcspy_dUtilsTileNum(start, end, blockSize);
  perm_driver_tile_t *tiles = permDriverAllocateStats(tileNum);
  
  permDriver->driver = gcDriver;
  permDriver->cardSize = cardSize;

  gcspy_dUtilsInit(&(permDriver->area),
		   start, end,
		   0, blockSize, tileNum,
		   (char *) tiles, sizeof(perm_driver_tile_t));

  if (blockSize < 1024)
    sprintf(tmp, "Block Size: %d bytes\n", blockSize);
  else
    sprintf(tmp, "Block Size: %dK\n", (blockSize / 1024));
  gcspy_driverInit(gcDriver, -1, name, "M&C GC",
		   "Block ", tmp, tileNum, NULL, 0);
  permDriverSetupTileNames(permDriver, 0, tileNum);

  stream = gcspy_driverAddStream(gcDriver, PERM_USED_SPACE_STREAM);
  gcspy_streamInit(stream, PERM_USED_SPACE_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Used Space",
		   0, blockSize,
		   0, 0,
		   "Used Space: ", " bytes",
		   GCSPY_GC_STREAM_PRESENTATION_PERCENT,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Red"));

  stream = gcspy_driverAddStream(gcDriver, PERM_DEAD_SPACE_STREAM);
  gcspy_streamInit(stream, PERM_DEAD_SPACE_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Dead Space",
		   0, blockSize,
		   0, 0,
		   "Dead Space: ", " bytes",
		   GCSPY_GC_STREAM_PRESENTATION_PERCENT,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Red"));

  stream = gcspy_driverAddStream(gcDriver, PERM_CARD_TABLE_STREAM);
  gcspy_streamInit(stream, PERM_CARD_TABLE_STREAM,
		   GCSPY_GC_STREAM_BYTE_TYPE,
		   "Card Table",
		   0, PERM_CARD_STATE_NUM-1,
		   PERM_CARD_STATE_NUM-1, PERM_CARD_STATE_NUM-1, 
		   "Card State: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_ENUM,
		   GCSPY_GC_STREAM_PAINT_STYLE_PLAIN, 0,
		   gcspy_colorDBGetColorWithName("Off White"));
  gcspy_streamAddEnumName(stream, PERM_CARD_STATE_DIRTY, "DIRTY");
  /* gcspy_streamAddEnumName(stream, PERM_CARD_STATE_PRECLEANED, "PRECLEANED"); */
  gcspy_streamAddEnumName(stream, PERM_CARD_STATE_YOUNGER, "YOUNGER");
  /* gcspy_streamAddEnumName(stream, PERM_CARD_STATE_LAST, "LAST"); */
  gcspy_streamAddEnumName(stream, PERM_CARD_STATE_CLEAN, "CLEAN");

  stream = gcspy_driverAddStream(gcDriver, PERM_ALLOC_STREAM);
  gcspy_streamInit(stream, PERM_ALLOC_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Allocation",
		   0, blockSize,
		   0, 0,
		   "Allocation: ", " bytes",
		   GCSPY_GC_STREAM_PRESENTATION_PERCENT,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Magenta"));

  stream = gcspy_driverAddStream(gcDriver, PERM_OBJECTS_STREAM);
  gcspy_streamInit(stream, PERM_OBJECTS_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Objects",
		   0, gcspy_d_utils_objects_per_block(blockSize),
		   0, 0,
		   "Objects: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Yellow"));

  stream = gcspy_driverAddStream(gcDriver, PERM_MARKING_STREAM);
  gcspy_streamInit(stream, PERM_MARKING_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Marking",
		   0, gcspy_d_utils_objects_per_block(blockSize),
		   0, 0,
		   "Marked: ", " objects",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Orange"));

  stream = gcspy_driverAddStream(gcDriver, PERM_REFS_STREAM);
  gcspy_streamInit(stream, PERM_REFS_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Reference Fields",
		   0, gcspy_d_utils_refs_per_block(blockSize),
		   0, 0,
		   "Reference Fields: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Green"));

  stream = gcspy_driverAddStream(gcDriver, PERM_REFS_TO_YOUNG_STREAM);
  gcspy_streamInit(stream, PERM_REFS_TO_YOUNG_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Refs To Young",
		   0, gcspy_d_utils_refs_per_block(blockSize),
		   0, 0,
		   "Refs To Young: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Green"));

  stream = gcspy_driverAddStream(gcDriver, PERM_REFS_TO_OLD_STREAM);
  gcspy_streamInit(stream, PERM_REFS_TO_OLD_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Refs To Old",
		   0, gcspy_d_utils_refs_per_block(blockSize),
		   0, 0,
		   "Refs To Old: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Green"));

  stream = gcspy_driverAddStream(gcDriver, PERM_INTERNAL_REFS_STREAM);
  gcspy_streamInit(stream, PERM_INTERNAL_REFS_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Internal Refs",
		   0, gcspy_d_utils_refs_per_block(blockSize),
		   0, 0,
		   "Internal Refs: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Green"));
}
