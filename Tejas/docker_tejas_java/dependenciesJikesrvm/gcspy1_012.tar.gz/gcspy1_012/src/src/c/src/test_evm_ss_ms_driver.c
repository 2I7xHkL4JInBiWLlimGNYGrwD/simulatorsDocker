/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  gcspy_test_ms_driver.c
 **
 **  Tests the MS Driver
 **/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "evm_ss_driver.h"
#include "evm_ms_driver.h"
#include "gcspy_main_server.h"
#include "gcspy_timer.h"

#ifdef _SPARC_
#include <thread.h>
#endif //_SPARC_

#ifdef _LINUX_
#include <pthread.h>
#endif //_LINUX_

#define MAX_LEN      ( 64 * 1024 )
#define TILE_SIZE    ( 32 * 1024 )

static gcspy_main_server_t server;
static ss_driver_t ssDriver;
static ms_driver_t msDriver;

#define FULL ( 512 * 1024 )
#define HALF ( 256 * 1024 )
#define ONE  0
#define TWO ( 512 * 1024 )
#define THREE ( 1024 * 1024 )
#define FOUR ( (1024 + 512) * 1024 )
#define FIVE ( 2 * 1024 * 1024 )
#define CARD_SIZE  1024

#define SS_ONE  0
#define SS_TWO ( 2 * 1024 * 1024 )
#define SS_THREE ( 4 * 1024 * 1024 )

#define SS_START_EVENT      0
#define SS_END_EVENT        1
#define MS_START_EVENT      2
#define MS_MARKING_EVENT    3
#define MS_SWEEPING_EVENT   4

static void
setupMS (ms_driver_t *msDriver) {
  gcspy_mainServerStartCompensationTimer(&server);

  msDriverZero(msDriver, (char *) (FIVE + FULL));

  msDriverFreeChunk(msDriver, (char *) ONE, 100);
  msDriverFreeChunk(msDriver, (char *) TWO - 100, 100);
  msDriverFreeChunk(msDriver, (char *) TWO + 1000, FULL);
  msDriverFreeChunk(msDriver, (char *) FOUR - 1000, 2 * FULL + 1000);

  msDriverObject(msDriver, (char *) ONE + 200, 100);
  msDriverObject(msDriver, (char *) TWO + HALF, FULL);
  msDriverObject(msDriver, (char *) FOUR - 1000, 2 * FULL);

  msDriverCard(msDriver, (char *) ONE, CARD_SIZE,
	       MS_CARD_STATE_DIRTY);
  msDriverCard(msDriver, (char *) ONE + CARD_SIZE, CARD_SIZE,
	       MS_CARD_STATE_CLEAN);

  msDriverCard(msDriver, (char *) TWO, CARD_SIZE,
	       MS_CARD_STATE_SUMMARISED);
  msDriverCard(msDriver, (char *) TWO + CARD_SIZE, CARD_SIZE,
	       MS_CARD_STATE_CLEAN);

  msDriverCard(msDriver, (char *) THREE, CARD_SIZE,
	       MS_CARD_STATE_SUMMARISED);
  msDriverCard(msDriver, (char *) THREE + CARD_SIZE, CARD_SIZE,
	       MS_CARD_STATE_CLEAN);
  msDriverCard(msDriver, (char *) THREE + 2*CARD_SIZE, CARD_SIZE,
	       MS_CARD_STATE_DIRTY);

  msDriverCard(msDriver, (char *) FOUR, CARD_SIZE,
	       MS_CARD_STATE_SUMMARISED);
  msDriverCard(msDriver, (char *) FOUR + CARD_SIZE, CARD_SIZE,
	       MS_CARD_STATE_DIRTY);

  msDriverPromoted(msDriver, (char *) ONE + 100, 20);
  msDriverPromoted(msDriver, (char *) ONE + 200, 30);
  msDriverPromoted(msDriver, (char *) ONE + 300, 50);
  msDriverPromoted(msDriver, (char *) TWO - 5000, HALF);

  gcspy_mainServerStopCompensationTimer(&server);
}

static void
setupSS (ss_driver_t *ssDriver, int semi) {
  char *limit;

  gcspy_mainServerStartCompensationTimer(&server);

  ssDriverZero(ssDriver);

  if (semi == 0) {
    limit = (char *) (SS_ONE + (512*1024 + 45*1000));
  } else {
    limit = (char *) (SS_TWO + (1024*1024));
  }
  ssDriverSetSemispace(ssDriver, semi, limit);

  gcspy_wait(11);
  gcspy_mainServerStopCompensationTimer(&server);
}

static void
possiblySend (int event) {
  if (gcspy_mainServerIsConnected(&server, event)) {
      printf("CONNECTED\n");
      ssDriverSend(&ssDriver, event);
      msDriverSend(&msDriver, event);
  }
}

#ifdef  __cplusplus
extern "C" {
#endif //__cplusplus
static void *
mainLoop (void *arg) {
  int event = SS_START_EVENT;
  int semi = 0;

  gcspy_mainServerWaitForClient(&server);

  while ( 1 ) {
    gcspy_wait(500);

    if (gcspy_mainServerIsConnected(&server, event)) {
      setupMS(&msDriver);
      setupSS(&ssDriver, semi);
      semi = 1 - semi;

      possiblySend(event);
    }
    gcspy_mainServerSafepoint(&server, event);

    if (event == MS_SWEEPING_EVENT)
      event = SS_START_EVENT;
    else
      ++event;
  }
}
#ifdef  __cplusplus
}
#endif //__cplusplus

int
main (int argc, char *argv[]) {
  char generalInfo[256];
  gcspy_date_time_t time;

#ifdef _SPARC_
  thread_t tid;
#endif //_SPARC_

#ifdef _LINUX_
  pthread_t tid;
#endif //_LINUX_

  gcspy_gc_driver_t *driver;
  int port;
  int res;

  if (argc != 2) {
    gcspy_raise_error("Wrong number of arguments");
  }
  port = atoi(argv[1]);

  printf("-- Initialising main server on port %d\n", port);
  gcspy_mainServerInit(&server, port, MAX_LEN, "S-S / M&S Driver Test", 1);

  time = gcspy_getDateTime();
  strcpy(generalInfo, "GCspy Test\n\n");
  strcat(generalInfo, "Start Time:\n  ");
  strcat(generalInfo, gcspy_formatDateTime(time));
  strcat(generalInfo, "\nApplication:\n  S-S / M&S Driver Test\n\n");
  strcat(generalInfo, "2 Spaces");
   gcspy_mainServerSetGeneralInfo(&server, generalInfo);

  printf("--   Setting event 0\n");
  gcspy_mainServerAddEvent(&server, SS_START_EVENT, "Start Young GC");
  printf("--   Setting event 1\n");
  gcspy_mainServerAddEvent(&server, SS_END_EVENT, "End Young GC");
  printf("--   Setting event 2\n");
  gcspy_mainServerAddEvent(&server, MS_START_EVENT, "Old Start GC");
  printf("--   Setting event 3\n");
  gcspy_mainServerAddEvent(&server, MS_MARKING_EVENT, "Old Marking Phase");
  printf("--   Setting event 4\n");
  gcspy_mainServerAddEvent(&server, MS_SWEEPING_EVENT, "Old Sweeping Phase");

  printf("--   Setting up driver 0\n");
  driver = gcspy_mainServerAddDriver(&server);
  ssDriverInit(&ssDriver, driver, 
	       "Young Generation",
	       TILE_SIZE,
	       (char *) SS_ONE,
	       (char *) SS_TWO,
	       (char *) SS_TWO,
	       (char *) SS_THREE);

  printf("--   Setting up driver 1\n");
  driver = gcspy_mainServerAddDriver(&server);
  msDriverInit(&msDriver, driver,
	       "Old Generation",
	       TILE_SIZE,
	       (char *) 0, (char *) (FIVE + FULL));

#ifdef _SPARC_
  res = thr_create(NULL, 0, mainLoop, NULL, THR_BOUND, &tid);
#endif //_SPARC_

#ifdef _LINUX_
  res = pthread_create(&tid, NULL, mainLoop, NULL);
#endif //_LINUX_

  if (res != 0) {
    printf("Couldn't create thread.\n");
    exit(-1);
  }

  gcspy_mainServerMainLoop(&server);
}
