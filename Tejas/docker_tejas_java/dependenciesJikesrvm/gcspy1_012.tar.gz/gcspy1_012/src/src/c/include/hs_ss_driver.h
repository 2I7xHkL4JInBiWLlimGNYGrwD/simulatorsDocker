/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  hs_ss_driver.h
 **
 **  Driver instance for the H-S S-S collector
 **/

#ifndef _HS_SS_DRIVER_H_

#define _HS_SS_DRIVER_H_

#include "gcspy_gc_driver.h"
#include "gcspy_d_utils.h"

#define SS_USED_SPACE_STREAM         0
#define SS_OBJECTS_STREAM            1
#define SS_REFS_STREAM               2
#define SS_REFS_TO_OLD_STREAM        3
#define SS_REFS_TO_PERM_STREAM       4
#define SS_INTERNAL_REFS_STREAM      5

#define SS_AREA_NUM                  3

#define SS_EDEN                      0
#define SS_LEFT_SEMI                 1
#define SS_RIGHT_SEMI                2

typedef struct {
  int usedSpace;
  int objects;
  int refs;
  int refsToOld;
  int refsToPerm;
  int internalRefs;
} ss_driver_tile_t;

typedef struct {
  gcspy_gc_driver_t     *driver;
  gcspy_d_utils_area_t   areas[SS_AREA_NUM];
  ss_driver_tile_t      *tiles;

  /* the active semi-space, either SS_LEFT_SEMI or SS_RIGHT_SEMI */
  int                    semi;
  int                    other;

  int                    tileNum;
  int                    blockSize;

  int                    totalUsedSpace[2];
  int                    totalObjects;
  int                    totalRefs;
  int                    totalRefsToOld;
  int                    totalRefsToPerm;
  int                    totalInternalRefs;
} ss_driver_t;

void
hsSSDriverInit (ss_driver_t *ssDriver,
		gcspy_gc_driver_t *gcDriver,
		const char *name,
		unsigned blockSize);

void
hsSSDriverZero (ss_driver_t *ssDriver,
		char *edenStart,
		char *edenEnd,
		char *fromStart,
		char *fromEnd,
		char *toStart,
		char *toEnd);

void
hsSSDriverSetLimits (ss_driver_t *ssDriver,
		     char *edenLimit,
		     char *fromLimit,
		     char *toLimit);

void
hsSSDriverObject (ss_driver_t *ssDriver,
		  char * start, int size);

void
hsSSDriverRef (ss_driver_t *ssDriver,
	       char *addr);

void
hsSSDriverRefToOld (ss_driver_t *ssDriver,
		    char *addr);

void
hsSSDriverRefToPerm (ss_driver_t *ssDriver,
		     char *addr);

void
hsSSDriverInternalRef (ss_driver_t *ssDriver,
		       char *addr);

void
hsSSDriverSend (ss_driver_t *ssDriver,
		unsigned event);

#endif //_HS_SS_DRIVER_H_
