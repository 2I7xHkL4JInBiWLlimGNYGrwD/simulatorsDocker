/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  test_hs_ss_driver.c
 **
 **  Tests the H-S S-S Driver
 **/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "hs_ss_driver.h"
#include "gcspy_main_server.h"
#include "gcspy_timer.h"

#ifdef _SPARC_
#include <thread.h>
#endif //_SPARC_

#ifdef _LINUX_
#include <pthread.h>
#endif //_LINUX_

#define MAX_LEN       ( 64 * 1024 )
#define BLOCK_SIZE    ( 32 * 1024 )

static gcspy_main_server_t server;
static ss_driver_t ssDriver;

#define ZERO     0
#define ONE    ( 1 * 1024 * 1024 )
#define TWO    ( 3 * 1024 * 1024 )
#define THREE  ( 5 * 1024 * 1024 )

#define START_GC_EVENT      0
#define END_GC_EVENT        1

#ifdef  __cplusplus
extern "C" {
#endif //__cplusplus
static void *
mainLoop (void *arg) {
  int count = 0;
  char *eden = (char *) ZERO;
  char *edenLimit;
  char *edenEnd = (char *) ONE;

  char *from;
  char *fromLimit;
  char *fromEnd;

  char *to;
  char *toLimit;
  char *toEnd;

  int event;

  while ( 1 ) {
    gcspy_wait(200);

    if ((count % 2) == 0)
      event = START_GC_EVENT;
    else
      event = END_GC_EVENT;

    if (gcspy_mainServerIsConnected(&server, event)) {
      gcspy_mainServerStartCompensationTimer(&server);

      switch (count % 4) {
      case 0:
	edenLimit = (char *) (ONE - 20000);

	from = (char *) ONE;
	fromLimit = (char *) ONE;
	fromEnd = (char *) TWO;

	to = (char *) TWO;
	toLimit = (char *) TWO;
	toEnd = (char *) THREE;
	break;
      case 1:
	edenLimit = (char *) ZERO;

	from = (char *) TWO;
	fromLimit = (char *) (TWO + 120 * 1024);
	fromEnd = (char *) THREE;

	to = (char *) ONE;
	toLimit = (char *) ONE;
	toEnd = (char *) TWO;
	break;
      case 2:
	edenLimit = (char *) (ONE - 3000);

	from = (char *) TWO;
	fromLimit = (char *) (TWO + 360 * 1024);
	fromEnd = (char *) THREE;

	to = (char *) ONE;
	toLimit = (char *) ONE;
	toEnd = (char *) TWO;
	break;
      case 3:
	edenLimit = (char *) ZERO;

	from = (char *) ONE;
	fromLimit = (char *) (TWO - 30 * 1024);
	fromEnd = (char *) TWO;

	to = (char *) TWO;
	toLimit = (char *) TWO;
	toEnd = (char *) THREE;
	break;
      }

      hsSSDriverZero(&ssDriver,
		     eden, edenEnd,
		     from, fromEnd,
		     to, toEnd);

      hsSSDriverSetLimits(&ssDriver, edenLimit, fromLimit, toLimit);

      gcspy_mainServerStopCompensationTimer(&server);

      if (gcspy_mainServerIsConnected(&server, event)) {
	printf("CONNECTED\n");
	hsSSDriverSend(&ssDriver, event);
      }

    }
    gcspy_mainServerSafepoint(&server, event);
    ++count;
  }
}
#ifdef  __cplusplus
}
#endif //__cplusplus

int
main (int argc, char *argv[]) {
  char generalInfo[256];
  gcspy_date_time_t time;

#ifdef _SPARC_
  thread_t tid;
#endif //_SPARC_

#ifdef _LINUX_
  pthread_t tid;
#endif //_LINUX_

  gcspy_gc_driver_t *driver;
  int port;
  int res;

  if (argc != 2) {
    gcspy_raise_error("Wrong number of arguments");
  }
  port = atoi(argv[1]);

  printf("-- Initialising main server on port %d\n", port);
  gcspy_mainServerInit(&server, port, MAX_LEN, "S-S Driver Test", 1);

  time = gcspy_getDateTime();
  strcpy(generalInfo, "GCspy Test\n\n");
  strcat(generalInfo, "Start Time:\n  ");
  strcat(generalInfo, gcspy_formatDateTime(time));
  strcat(generalInfo, "\nApplication:\n  S-S Driver Test\n\n");
  strcat(generalInfo, "1 Space");
  gcspy_mainServerSetGeneralInfo(&server, generalInfo);

  printf("--   Setting event 0\n");
  gcspy_mainServerAddEvent(&server, START_GC_EVENT, "Start S-S GC");
  printf("--   Setting event 1\n");
  gcspy_mainServerAddEvent(&server, END_GC_EVENT, "End S-S GC");

  printf("--   Setting up driver 0\n");
  driver = gcspy_mainServerAddDriver(&server);

  hsSSDriverInit(&ssDriver, driver, 
		 "Single Generation",
		 BLOCK_SIZE);

#ifdef _SPARC_
  res = thr_create(NULL, 0, mainLoop, NULL, THR_BOUND, &tid);
#endif //_SPARC_

#ifdef _LINUX_
  res = pthread_create(&tid, NULL, mainLoop, NULL);
#endif //_LINUX_

  if (res != 0) {
    printf("Couldn't create thread.\n");
    exit(-1);
  }

  gcspy_mainServerMainLoop(&server);
}
