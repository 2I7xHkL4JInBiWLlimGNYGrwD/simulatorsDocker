/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  hs_ss_driver.c
 **
 **  Driver instance for the H-S S-S collector
 **/

#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "gcspy_gc_stream.h"
#include "hs_ss_driver.h"

static int
ssDriverGetTileIndex (ss_driver_t *ssDriver, char *addr) {
  int i;
  for (i = 0; i < SS_AREA_NUM; ++i) {
    if (gcspy_d_utils_addr_in_range(&(ssDriver->areas[i]), addr))
      return gcspy_d_utils_get_index(&(ssDriver->areas[i]), addr);
  }
  printf("BARF 1!\n");
  return -1;
}

static char *
ssDriverGetTileAddr (ss_driver_t *ssDriver, int index) {
  int i;
  for (i = 0; i < SS_AREA_NUM; ++i) {
    if (gcspy_d_utils_index_in_range(&(ssDriver->areas[i]), index))
      return gcspy_d_utils_get_addr(&(ssDriver->areas[i]), index);
  }
  printf("BARF 2!\n");
  return NULL;
}

static ss_driver_tile_t *
ssDriverGetTile (ss_driver_t *ssDriver, int index) {
  return &ssDriver->tiles[index];
}

static void
ssDriverSetupAreas (ss_driver_t *ssDriver,
		    char *edenStart, char *edenEnd,
		    char *fromStart, char *fromEnd,
		    char *toStart, char *toEnd) {
  gcspy_gc_driver_t *gcDriver = ssDriver->driver;
  int blockSize = ssDriver->blockSize;
  int edenTileNum = gcspy_dUtilsTileNum(edenStart, edenEnd, blockSize);
  int fromTileNum = gcspy_dUtilsTileNum(fromStart, fromEnd, blockSize);
  int toTileNum = gcspy_dUtilsTileNum(toStart, toEnd, blockSize);
  int fromFirstIndex;
  int toFirstIndex;
  int semi;
  int other;

  int tileNum = edenTileNum + fromTileNum + toTileNum;
  int len = tileNum * sizeof(ss_driver_tile_t);
  ss_driver_tile_t *tiles = (ss_driver_tile_t *) malloc(len);
  if (tiles == NULL) {
    char buffer[256];
    sprintf(buffer, "S-S Driver: could not allocate %d bytes for tile data",
	    len);
    gcspy_raise_error(buffer);
  }    

  if (ssDriver->tiles != NULL)
    free(ssDriver->tiles);
  ssDriver->tiles = tiles;
  ssDriver->tileNum = tileNum;

  if (fromStart < toStart) {
    semi = SS_LEFT_SEMI;
    other = SS_RIGHT_SEMI;
    fromFirstIndex = edenTileNum;
    toFirstIndex = fromFirstIndex + fromTileNum;
  } else {
    semi = SS_RIGHT_SEMI;
    other = SS_LEFT_SEMI;
    toFirstIndex = edenTileNum;
    fromFirstIndex = toFirstIndex + toTileNum;
  }

  gcspy_dUtilsInit(&(ssDriver->areas[SS_EDEN]),
		   edenStart, edenEnd,
		   0, blockSize, edenTileNum,
		   (char *) tiles, 
		   sizeof(ss_driver_tile_t));

  gcspy_dUtilsInit(&(ssDriver->areas[semi]),
		   fromStart, fromEnd,
		   fromFirstIndex, blockSize, fromTileNum,
		   (char *) tiles +
		   fromFirstIndex * sizeof(ss_driver_tile_t), 
		   sizeof(ss_driver_tile_t));

  gcspy_dUtilsInit(&(ssDriver->areas[other]),
		   toStart, toEnd,
		   toFirstIndex, blockSize, toTileNum,
		   (char *) tiles +
		   toFirstIndex * sizeof(ss_driver_tile_t), 
		   sizeof(ss_driver_tile_t));
}

void
ssDriverSetupTileNames (ss_driver_t *ssDriver) {
  char tmp[256];
  int i, j;
  int tileNum = ssDriver->tileNum;
  gcspy_gc_driver_t *gcDriver = ssDriver->driver;

  for (i = 0; i < tileNum; ++i) {
    for (j = 0; j < SS_AREA_NUM; ++j) {
      gcspy_d_utils_area_t *area = &ssDriver->areas[j];
      if (gcspy_d_utils_index_in_range(area, i))
	gcspy_dUtilsRangeString(area, i, tmp);
    }
    gcspy_driverSetTileName(gcDriver, i, tmp);
  }
}

void
hsSSDriverZero (ss_driver_t *ssDriver,
		char *edenStart,
		char *edenEnd,
		char *fromStart,
		char *fromEnd,
		char *toStart,
		char *toEnd) {
  int i;
  ss_driver_tile_t *tile;
  int semi;
  int other;

  if (fromStart < toStart) {
    semi = SS_LEFT_SEMI;
    other = SS_RIGHT_SEMI;
  } else {
    semi = SS_RIGHT_SEMI;
    other = SS_LEFT_SEMI;
  }
  ssDriver->semi = semi;
  ssDriver->other = other;

  if ((ssDriver->tileNum == 0) ||
      (edenStart != ssDriver->areas[SS_EDEN].start) ||
      (edenEnd != ssDriver->areas[SS_EDEN].end) ||
      (fromStart != ssDriver->areas[semi].start) ||
      (fromEnd != ssDriver->areas[semi].end) ||
      (toStart != ssDriver->areas[other].start) ||
      (toEnd != ssDriver->areas[other].end)) {
    ssDriverSetupAreas(ssDriver,
		       edenStart, edenEnd,
		       fromStart, fromEnd,
		       toStart, toEnd);
    gcspy_driverResize(ssDriver->driver, ssDriver->tileNum);
    ssDriverSetupTileNames(ssDriver);
  }

  for (i = 0; i < ssDriver->tileNum; ++i) {
    tile = ssDriverGetTile(ssDriver, i);
    tile->usedSpace = 0;
    tile->objects = 0;
    tile->refs = 0;
    tile->refsToOld = 0;
    tile->refsToPerm = 0;
    tile->internalRefs = 0;
  }

  ssDriver->totalUsedSpace[0] = 0;
  ssDriver->totalUsedSpace[1] = 0;
  ssDriver->totalObjects = 0;
  ssDriver->totalRefs = 0;
  ssDriver->totalRefsToOld = 0;
  ssDriver->totalRefsToPerm = 0;
  ssDriver->totalInternalRefs = 0;
}

void
hsSSDriverSetLimits (ss_driver_t *ssDriver,
		     char *edenLimit,
		     char *fromLimit,
		     char *toLimit) {
  int i;
  char *limits[SS_AREA_NUM];

  limits[SS_EDEN] = edenLimit;
  limits[ssDriver->semi] = fromLimit;
  limits[ssDriver->other] = toLimit;

  for (i = 0; i < SS_AREA_NUM; ++i) {
    gcspy_d_utils_area_t *area = &ssDriver->areas[i];
    gcspy_dUtilsSetPerc(area,
			area->start,
			limits[i],
			offsetof(ss_driver_tile_t, usedSpace));
    ssDriver->totalUsedSpace[0] += (limits[i] - area->start);
    ssDriver->totalUsedSpace[1] += gcspy_d_utils_get_area_size(area);
  }
}

void
hsSSDriverObject (ss_driver_t *ssDriver,
		  char *start, int size) {
  int i;
  ++ssDriver->totalObjects;
  for (i = 0; i < SS_AREA_NUM; ++i) {
    if (gcspy_d_utils_addr_in_range(&(ssDriver->areas[i]), start))
      gcspy_dUtilsAddOne(&(ssDriver->areas[i]), start, start + size,
			 offsetof(ss_driver_tile_t, objects));
  }
}

void
hsSSDriverRef (ss_driver_t *ssDriver,
	       char *addr) {
  int i;
  ++ssDriver->totalRefs;
  for (i = 0; i < SS_AREA_NUM; ++i) {
    if (gcspy_d_utils_addr_in_range(&(ssDriver->areas[i]), addr))
      gcspy_dUtilsAddSingle(&(ssDriver->areas[i]), addr,
			    offsetof(ss_driver_tile_t, refs));
  }
}

void
hsSSDriverRefToOld (ss_driver_t *ssDriver,
		    char *addr) {
  int i;
  ++ssDriver->totalRefsToOld;
  for (i = 0; i < SS_AREA_NUM; ++i) {
    if (gcspy_d_utils_addr_in_range(&(ssDriver->areas[i]), addr))
      gcspy_dUtilsAddSingle(&(ssDriver->areas[i]), addr,
			    offsetof(ss_driver_tile_t, refsToOld));
  }
}

void
hsSSDriverRefToPerm (ss_driver_t *ssDriver,
		     char *addr) {
  int i;
  ++ssDriver->totalRefsToPerm;
  for (i = 0; i < SS_AREA_NUM; ++i) {
    if (gcspy_d_utils_addr_in_range(&(ssDriver->areas[i]), addr))
      gcspy_dUtilsAddSingle(&(ssDriver->areas[i]), addr,
			    offsetof(ss_driver_tile_t, refsToPerm));
  }
}

void
hsSSDriverInternalRef (ss_driver_t *ssDriver,
		       char *addr) {
  int i;
  ++ssDriver->totalInternalRefs;
  for (i = 0; i < SS_AREA_NUM; ++i) {
    if (gcspy_d_utils_addr_in_range(&(ssDriver->areas[i]), addr))
      gcspy_dUtilsAddSingle(&(ssDriver->areas[i]), addr,
			    offsetof(ss_driver_tile_t, internalRefs));
  }
}

void
hsSSDriverSend (ss_driver_t *ssDriver,
		unsigned event) {
  int i;
  ss_driver_tile_t *tile;
  gcspy_gc_driver_t *driver = ssDriver->driver;
  int semi = ssDriver->semi;
  int other = ssDriver->other;
  double perc;
  char tmp[128];
  int size;
  int edenSize;
  int semiSize;
  int tileNum = ssDriver->tileNum;

  gcspy_driverStartComm(driver);

  gcspy_driverStream(driver, SS_USED_SPACE_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = ssDriverGetTile(ssDriver, i);
    gcspy_driverStreamIntValue(driver, tile->usedSpace);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, SS_USED_SPACE_STREAM, 2);
  gcspy_driverSummaryValue(driver, ssDriver->totalUsedSpace[0]);
  gcspy_driverSummaryValue(driver, ssDriver->totalUsedSpace[1]);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, SS_OBJECTS_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = ssDriverGetTile(ssDriver, i);
    gcspy_driverStreamIntValue(driver, tile->objects);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, SS_OBJECTS_STREAM, 1);
  gcspy_driverSummaryValue(driver, ssDriver->totalObjects);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, SS_REFS_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = ssDriverGetTile(ssDriver, i);
    gcspy_driverStreamIntValue(driver, tile->refs);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, SS_REFS_STREAM, 1);
  gcspy_driverSummaryValue(driver, ssDriver->totalRefs);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, SS_REFS_TO_OLD_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = ssDriverGetTile(ssDriver, i);
    gcspy_driverStreamIntValue(driver, tile->refsToOld);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, SS_REFS_TO_OLD_STREAM, 1);
  gcspy_driverSummaryValue(driver, ssDriver->totalRefsToOld);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, SS_REFS_TO_PERM_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = ssDriverGetTile(ssDriver, i);
    gcspy_driverStreamIntValue(driver, tile->refsToPerm);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, SS_REFS_TO_PERM_STREAM, 1);
  gcspy_driverSummaryValue(driver, ssDriver->totalRefsToPerm);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, SS_INTERNAL_REFS_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = ssDriverGetTile(ssDriver, i);
    gcspy_driverStreamIntValue(driver, tile->internalRefs);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, SS_INTERNAL_REFS_STREAM, 1);
  gcspy_driverSummaryValue(driver, ssDriver->totalInternalRefs);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverControl(driver);
  gcspy_driverControlValues(driver,
			    GCSPY_GC_DRIVER_CONTROL_UNUSED,
			    ssDriver->areas[other].firstIndex,
			    ssDriver->areas[other].blockNum);
  gcspy_driverControlValues(driver,
			    GCSPY_GC_DRIVER_CONTROL_SEPARATOR,
			    ssDriver->areas[SS_LEFT_SEMI].firstIndex, 1);
  gcspy_driverControlValues(driver,
			    GCSPY_GC_DRIVER_CONTROL_SEPARATOR,
			    ssDriver->areas[SS_RIGHT_SEMI].firstIndex, 1);
  gcspy_driverControlEnd(driver);

  size = ssDriver->totalUsedSpace[1];
  edenSize = gcspy_d_utils_get_area_size(&ssDriver->areas[SS_EDEN]);
  semiSize = gcspy_d_utils_get_area_size(&ssDriver->areas[SS_LEFT_SEMI]);

  strcpy(tmp, "");
  strcat(tmp, "Current Size: ");
  strcat(tmp, gcspy_formatSize(size));
  strcat(tmp, "\nEden Size: ");
  strcat(tmp, gcspy_formatSize(edenSize));
  strcat(tmp, "\nEach Semispace Size: ");
  strcat(tmp, gcspy_formatSize(semiSize));
  strcat(tmp, "\n");
  gcspy_driverSpaceInfo(driver, tmp);

  gcspy_driverEndComm(driver);
}

void
hsSSDriverInit (ss_driver_t *ssDriver,
		gcspy_gc_driver_t *gcDriver,
		const char *name,
		unsigned blockSize) {
  gcspy_gc_stream_t *stream;
  char tmp[256];

  ssDriver->driver = gcDriver;
  ssDriver->blockSize = blockSize;
  ssDriver->tiles = NULL;

  if (blockSize < 1024)
    sprintf(tmp, "Block Size: %d bytes\n", blockSize);
  else
    sprintf(tmp, "Block Size: %dK\n", (blockSize / 1024));
  gcspy_driverInit(gcDriver, -1, name, "S-S GC",
		   "Block ", tmp, 1, NULL, 0);

  stream = gcspy_driverAddStream(gcDriver, SS_USED_SPACE_STREAM);
  gcspy_streamInit(stream, SS_USED_SPACE_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Used Space",
		   0, blockSize,
		   0, 0,
		   "Used Space: ", " bytes",
		   GCSPY_GC_STREAM_PRESENTATION_PERCENT,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Red"));

  stream = gcspy_driverAddStream(gcDriver, SS_OBJECTS_STREAM);
  gcspy_streamInit(stream, SS_OBJECTS_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Objects",
		   0, gcspy_d_utils_objects_per_block(blockSize),
		   0, 0,
		   "Objects: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Yellow"));

  stream = gcspy_driverAddStream(gcDriver, SS_REFS_STREAM);
  gcspy_streamInit(stream, SS_REFS_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Reference Fields",
		   0, gcspy_d_utils_refs_per_block(blockSize),
		   0, 0,
		   "Reference Fields: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Green"));

  stream = gcspy_driverAddStream(gcDriver, SS_REFS_TO_OLD_STREAM);
  gcspy_streamInit(stream, SS_REFS_TO_OLD_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Refs To Old",
		   0, gcspy_d_utils_refs_per_block(blockSize),
		   0, 0,
		   "Refs To Old: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Green"));

  stream = gcspy_driverAddStream(gcDriver, SS_REFS_TO_PERM_STREAM);
  gcspy_streamInit(stream, SS_REFS_TO_PERM_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Refs To Permanent",
		   0, gcspy_d_utils_refs_per_block(blockSize),
		   0, 0,
		   "Refs To Permanent: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Green"));

  stream = gcspy_driverAddStream(gcDriver, SS_INTERNAL_REFS_STREAM);
  gcspy_streamInit(stream, SS_INTERNAL_REFS_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Internal Refs",
		   0, gcspy_d_utils_refs_per_block(blockSize),
		   0, 0,
		   "Internal Refs: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Green"));
}
