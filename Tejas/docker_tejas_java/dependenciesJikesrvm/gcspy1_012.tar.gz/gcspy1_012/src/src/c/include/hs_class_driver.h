/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  class_driver.h
 **
 **  Driver instance for the class space
 **/

#ifndef _CLASS_DRIVER_H_

#define _CLASS_DRIVER_H_

#include "gcspy_gc_driver.h"

#define CLASS_INSTANCE_NUM_STREAM             0
#define CLASS_INSTANCE_SIZE_STREAM            1
#define CLASS_INSTANCE_REF_NUM_STREAM         2

#define CLASS_MAX_INSTANCE_NUM      ( 10 * 1024 )
#define CLASS_MAX_INSTANCE_SIZE             128
#define CLASS_MAX_REF_NUM                     8

#define CLASS_DEFAULT_HASH_LEN             1000
#define CLASS_HASH_EXTENSION_PERCENT         40
#define CLASS_HASH_MAX_OCCUPANCY             60

typedef unsigned *class_key_t;
typedef unsigned *class_loader_t;
typedef unsigned *class_id_t;

typedef struct class_s {
  class_key_t      key;

  char            *name;
  class_id_t       classId;
  class_loader_t   loader;

  unsigned         instanceNum;
  unsigned         instanceSize;
  unsigned         refNum;
  unsigned         loaded;
} class_t;

typedef struct {
  gcspy_gc_driver_t     *driver;
  unsigned               classNum;
  unsigned               loadedClasses;

  class_t              **classHT;
  class_t              **keyHT;
  unsigned               htLength;
  unsigned               htMaxOccupancy;

  class_t              **array;
  unsigned               arrayLength;

  unsigned               totalInstances;
} class_driver_t;

void
hsClassDriverInit (class_driver_t *classDriver,
		   gcspy_gc_driver_t *gcDriver,
		   const char *name);

void
hsClassDriverStartClasses (class_driver_t *classDriver);

void
hsClassDriverClass (class_driver_t *classDriver,
		    char *name,
		    class_id_t classId,
		    class_loader_t loader,
		    class_key_t key,
		    unsigned instanceSize,
		    unsigned refNum);

void
hsClassDriverStartInstances (class_driver_t *classDriver);

void
hsClassDriverInstance (class_driver_t *classDriver,
		       class_key_t key);

void
hsClassDriverSend (class_driver_t *classDriver,
		   unsigned event);

#endif //_CLASS_DRIVER_H_
