/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  hs_perm_driver.h
 **
 **  Driver instance for the H-S permanent space
 **/

#ifndef _HS_PERM_DRIVER_H_

#define _HS_PERM_DRIVER_H_

#include "gcspy_gc_driver.h"
#include "gcspy_d_utils.h"

#define PERM_USED_SPACE_STREAM       0
#define PERM_DEAD_SPACE_STREAM       1
#define PERM_CARD_TABLE_STREAM       2
#define PERM_ALLOC_STREAM            3
#define PERM_OBJECTS_STREAM          4
#define PERM_MARKING_STREAM          5
#define PERM_REFS_STREAM             6
#define PERM_REFS_TO_YOUNG_STREAM    7
#define PERM_REFS_TO_OLD_STREAM      8
#define PERM_INTERNAL_REFS_STREAM    9

#define PERM_CARD_STATE_CLEAN       2
#define PERM_CARD_STATE_YOUNGER     1
#define PERM_CARD_STATE_DIRTY       0

#define PERM_CARD_STATE_NUM         3

typedef struct {
  int usedSpace;
  int deadSpace;
  int cards;
  int alloc;
  int objects;
  int marks;
  int refs;
  int refsToYoung;
  int refsToOld;
  int internalRefs;
} perm_driver_tile_t;

typedef struct {
  gcspy_gc_driver_t     *driver;
  gcspy_d_utils_area_t   area;
  unsigned cardSize;

  int totalUsedSpace[2];
  int totalDeadSpace[2];
  int totalCards[PERM_CARD_STATE_NUM];
  int totalAlloc[2];
  int totalObjects;
  int totalMarks;
  int totalRefs;
  int totalRefsToYoung[2];
  int totalRefsToOld[2];
  int totalInternalRefs;
} perm_driver_t;

void
hsPermDriverInit (perm_driver_t *permDriver,
		  gcspy_gc_driver_t *gcDriver,
		  const char *name,
		  unsigned blockSize,
		  unsigned cardSize,
		  char *start,
		  char *end);

void
hsPermDriverZero (perm_driver_t *permDriver,
		  char *end);

void
hsPermDriverSetLimit (perm_driver_t *permDriver,
		      char *limit);

void
hsPermDriverDeadSpace (perm_driver_t *permDriver,
		       char *start, char *end);

void
hsPermDriverAlloc (perm_driver_t *permDriver,
		   char *start, char *end);

void
hsPermDriverCard (perm_driver_t *permDriver,
		  char *start,
		  int state);

void
hsPermDriverObject (perm_driver_t *permDriver,
		    char *start, int size);

void
hsPermDriverMark (perm_driver_t *permDriver,
		  char *start);

void
hsPermDriverRef (perm_driver_t *permDriver,
		 char *addr);

void
hsPermDriverRefToYoung (perm_driver_t *permDriver,
			char *addr);

void
hsPermDriverRefToOld (perm_driver_t *permDriver,
		      char *addr);

void
hsPermDriverInternalRef (perm_driver_t *permDriver,
			 char *addr);

void
hsPermDriverSend (perm_driver_t *permDriver,
		  unsigned event);

#endif //_HS_PERM_DRIVER_H_
