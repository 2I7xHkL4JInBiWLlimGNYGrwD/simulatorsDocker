/**
 **  evm_train_driver.h
 **
 **  Driver instance for the EVM Train collector
 **  Corresponds to three spaces: regions, cars, and trains
 **/

#ifndef _EVM_TRAIN_DRIVER_H_

#define _EVM_TRAIN_DRIVER_H_

#include "gcspy_gc_driver.h"
#include "gcspy_d_utils.h"

/***** REGIONS *****/

#define REGION_USED_SPACE_STREAM         0
#define REGION_CARDS_STREAM              1
#define REGION_TYPE_STREAM               2
#define REGION_TRAIN_ID_STREAM           3
#define REGION_CAR_ID_STREAM             4
#define REGION_DIRECT_ALLOC_STREAM       5
#define REGION_PROM_STREAM               6
#define REGION_EVAC_STREAM               7
#define REGION_WEAK_EVAC_STREAM          8

#define REGION_TYPE_STANDARD             2
#define REGION_TYPE_OVERSIZED            1
#define REGION_TYPE_POPULAR              0

#define REGION_CARD_STATE_CLEAN          3
#define REGION_CARD_STATE_SUMMARISED     2
#define REGION_CARD_STATE_OVERFLOWN      1
#define REGION_CARD_STATE_DIRTY          0

/***** CARS *****/

#define CAR_USED_SPACE_STREAM         0
#define CAR_RS_LEN_STREAM             1
#define CAR_RS_SIZE_STREAM            2
#define CAR_RS_COARSENESS_STREAM      3
#define CAR_RS_CAPACITY_STREAM        4
#define CAR_HIGHER_REFS_STREAM        5
#define CAR_TYPE_STREAM               6
#define CAR_TRAIN_ID_STREAM           7
#define CAR_CAR_ID_STREAM             8
#define CAR_SIZE_STREAM               9
#define CAR_OBJECTS_STREAM           10
#define CAR_IN_CS_STREAM             11
#define CAR_CS_SIZE_STREAM           12
#define CAR_DIRECT_ALLOC_STREAM      13
#define CAR_PROM_STREAM              14
#define CAR_EVAC_STREAM              15
#define CAR_WEAK_EVAC_STREAM         16

#define CAR_RS_LEN_MAX                  256
#define CAR_RS_SIZE_MAX          ( 4 * 1024 )
#define CAR_RS_CAPACITY_MAX      ( 4 * 1024 )
#define CAR_RS_COARSENESS_MAX            19
#define CAR_RS_COARSENESS_MIN             0

#define CAR_HIGHER_REFS_YES           1
#define CAR_HIGHER_REFS_NO            0

#define CAR_IN_CS_YES                 1
#define CAR_IN_CS_NO                  0

#define CAR_TYPE_STANDARD             2
#define CAR_TYPE_OVERSIZED            1
#define CAR_TYPE_POPULAR              0

/***** TRAINS *****/

#define TRAIN_USED_SPACE_STREAM          0
#define TRAIN_RS_LEN_STREAM              1
#define TRAIN_HIGHER_REFS_STREAM         2
#define TRAIN_TRAIN_ID_STREAM            3
#define TRAIN_LENGTH_STREAM              4
#define TRAIN_SIZE_STREAM                5
#define TRAIN_OBJECTS_STREAM             6
#define TRAIN_POPULAR_OBJECTS_STREAM     7
#define TRAIN_CARS_IN_CS_STREAM          8
#define TRAIN_CS_SIZE_STREAM             9
#define TRAIN_DIRECT_ALLOC_STREAM       10
#define TRAIN_PROM_STREAM               11
#define TRAIN_EVAC_STREAM               12
#define TRAIN_WEAK_EVAC_STREAM          13

#define TRAIN_RS_LEN_MAX         ( 20 * CAR_RS_LEN_MAX )
#define TRAIN_LENGTH_MAX                128
#define TRAIN_HIGHER_REFS_YES             1
#define TRAIN_HIGHER_REFS_NO              0
#define TRAIN_MAX_POPULAR_OBJECTS       128
#define TRAIN_CARS_IN_CS_MAX            128

/***** SHARED *****/

typedef struct {
  unsigned   allocated:1;
  unsigned   type:2;
  unsigned   padding:29;
  int        cards;
  int        trainID;
  int        carID;
  int        usedSpace;
  int        directAlloc;
  int        prom;
  int        evac;
  int        weakEvac;
} train_region_t;

typedef struct {
  unsigned   rsCoarseness:5;
  unsigned   higherRefs:1;
  unsigned   type:2;
  unsigned   inCS:1;
  unsigned   padding:23;
  int        trainID;
  int        carID;
  int        usedSpace;
  int        rsLen;
  int        rsSize;
  int        rsCapacity;
  int        size;
  int        objects;
  int        csSize;
  int        directAlloc;
  int        prom;
  int        evac;
  int        weakEvac;
} train_car_t;

typedef struct {
  int        usedSpace;
  int        rsLen;
  int        length;
  int        size;
  int        trainID;
  int        higherRefs;
  int        objects;
  int        popularObjects;
  int        carsInCS;
  int        csSize;
  int        directAlloc;
  int        prom;
  int        evac;
  int        weakEvac;
} train_train_t;

typedef struct {
  gcspy_gc_driver_t     *regionDriver;
  gcspy_d_utils_area_t   regionArea;

  gcspy_gc_driver_t     *carDriver;
  train_car_t           *cars;
  unsigned               carNum;
  unsigned               lastTrain;

  gcspy_gc_driver_t     *trainDriver;
  train_train_t         *trains;
  unsigned               trainNum;

  int totalRegionUsedSpace[2];
  int totalRegionCards[4];
  int totalRegionType[3];
  int totalRegionAllocated;
  int totalRegionDirectAlloc[2];
  int totalRegionProm[2];
  int totalRegionEvac[2];
  int totalRegionWeakEvac[2];

  int totalCarUsedSpace[2];
  int totalCarType[3];
  int totalCarRSLen;
  int totalCarRSSize;
  int totalCarRSCapacity;
  int totalCarSize;
  int totalCarObjects;
  int totalCarHigherRefs[2];
  int totalCarDirectAlloc[2];
  int totalCarInCS[2];
  int totalCarCSSize[2];
  int totalCarProm[2];
  int totalCarEvac[2];
  int totalCarWeakEvac[2];

  int totalTrainUsedSpace[2];
  int totalTrainRSLen;
  int totalTrainLength;
  int totalTrainSize;
  int totalTrainObjects;
  int totalTrainPopularObjects;
  int totalTrainHigherRefs[2];
  int totalTrainCarsInCS;
  int totalTrainCSSize[2];
  int totalTrainDirectAlloc[2];
  int totalTrainProm[2];
  int totalTrainEvac[2];
  int totalTrainWeakEvac[2];
} train_driver_t;

void
trainInit (train_driver_t *driver,
	   gcspy_gc_driver_t *regionDriver,
	   gcspy_gc_driver_t *carDriver,
	   gcspy_gc_driver_t *trainDriver,
	   const char *name,
	   unsigned regionSize,
	   char *start,
	   char *end,
	   unsigned carNum,
	   unsigned trainNum);

void
trainZero (train_driver_t *trainDriver,
	   char *limit, unsigned carNum, unsigned trainNum);

void
trainCard (train_driver_t *trainDriver,
	   char *start,
	   int size,
	   int state);

void
trainStandardRegion (train_driver_t *trainDriver,
		     int id,
		     int trainID,
		     int carID,
		     int usedSpace,
		     int directAlloc,
		     int prom,
		     int evac,
		     int weakEvac);

void
trainOversizedRegion (train_driver_t *trainDriver,
		      int startID,
		      int length,
		      int trainID,
		      int carID,
		      int usedSpace,
		      int directAlloc,
		      int prom,
		      int evac,
		      int weakEvac);

void
trainPopularRegion (train_driver_t *trainDriver,
		    int id,
		    int usedSpace,
		    int directAlloc,
		    int prom,
		    int evac,
		    int weakEvac);

void
trainCar (train_driver_t *trainDriver,
	  int id,
	  int trainID,
	  int carID,
	  int type,
	  int usedSpace,
	  int size,
	  int objects,
	  int rsLen,
	  int rsSize,
	  int rsCoarseness,
	  int rsCapacity,
	  int higherRefs,
	  int inCS,
	  int csSize,
	  int directAlloc,
	  int prom,
	  int evac,
	  int weakEvac);

void
trainTrain (train_driver_t *trainDriver,
	    int id,
	    int trainID,
	    int usedSpace,
	    int objects,
	    int popularObjects,
	    int length,
	    int size,
	    int rsLen,
	    int higherRefs,
	    int carsInCS,
	    int csSize,
	    int directAlloc,
	    int prom,
	    int evac,
	    int weakEvac);

void
trainSend (train_driver_t *trainDriver,
	   unsigned event);

#endif //_EVM_TRAIN_DRIVER_H_
