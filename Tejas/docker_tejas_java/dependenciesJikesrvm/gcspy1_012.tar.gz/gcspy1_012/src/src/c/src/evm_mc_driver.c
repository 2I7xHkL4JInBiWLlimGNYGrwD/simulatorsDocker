/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  evm_mc_driver.c
 **
 **  Driver instance for the EVM M&C collector
 **/

#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include "gcspy_gc_stream.h"
#include "evm_mc_driver.h"

static mc_driver_tile_t *
mcDriverAllocateStats (int tileNum) {
  int len = tileNum * sizeof(mc_driver_tile_t);
  mc_driver_tile_t *tiles = (mc_driver_tile_t *) malloc(len);
  if (tiles == NULL) {
    char buffer[256];
    sprintf(buffer, "M&C Driver: could not allocate %d bytes for tile data",
	    len);
    gcspy_raise_error(buffer);
  }
  return tiles;
}

static void
mcDriverSetupTileNames (mc_driver_t *mcDriver,
			int from,
			int to) {
  int i;
  char tmp[256];
  for (i = from; i < to; ++i) {
    gcspy_dUtilsRangeString(&(mcDriver->area), i, tmp);
    gcspy_driverSetTileName(mcDriver->driver, i, tmp);
  }
}

static mc_driver_tile_t *
mcDriverGetTile (mc_driver_t *mcDriver, int index) {
  return (mc_driver_tile_t *)
    gcspy_d_utils_get_stats_struct(&(mcDriver->area), index, 0);
}

static int
mcDriverGetTileIndex (mc_driver_t *mcDriver, char *addr) {
  return gcspy_d_utils_get_index(&(mcDriver->area), addr);
}

static char *
mcDriverGetTileAddr (mc_driver_t *mcDriver, int index) {
  return gcspy_d_utils_get_addr(&(mcDriver->area), index);
}

void
mcDriverZero (mc_driver_t *mcDriver,
	      char *limit) {
  int i;
  mc_driver_tile_t *tile;
  int totalSpace = limit - mcDriver->area.start;

  if (limit != mcDriver->area.end) {
    int tileNum = gcspy_dUtilsTileNum(mcDriver->area.start,
				      limit,
				      mcDriver->area.blockSize); 
    /* printf("resizing to %8x, tileNum = %d\n", limit, tileNum); */
    mcDriver->area.end = limit;
    mcDriver->area.blockNum = tileNum;
    free(mcDriver->area.stats);
    mcDriver->area.stats = (char *) mcDriverAllocateStats(tileNum);

    gcspy_driverResize(mcDriver->driver, tileNum);
    mcDriverSetupTileNames(mcDriver, 0, tileNum);
  }

  for (i = 0; i < mcDriver->area.blockNum; ++i) {
    tile = mcDriverGetTile(mcDriver, i);
    tile->usedSpace = 0;
    tile->cards = MC_CARD_STATE_CLEAN;
    tile->promotion = 0;
    tile->roots = 0;
    tile->marking = 0;
  }

  mcDriver->totalUsedSpace[0] = 0;
  mcDriver->totalUsedSpace[1] = totalSpace;
  for (i = 0; i < 3; ++i) {
    mcDriver->totalCardTable[i] = 0;
  }
  mcDriver->totalPromotion[0] = 0;
  mcDriver->totalPromotion[1] = totalSpace;
  mcDriver->totalRoots = 0;
  mcDriver->totalMarking = 0;
}

void
mcDriverSetEnd (mc_driver_t *mcDriver,
		char *end) {
  mcDriver->totalUsedSpace[0] += (end - mcDriver->area.start);
  gcspy_dUtilsSetPerc(&(mcDriver->area),
		      mcDriver->area.start,
		      end,
		      offsetof(mc_driver_tile_t, usedSpace));
}

void
mcDriverCard (mc_driver_t *mcDriver,
	      char *start,
	      int size,
	      int state) {
  ++mcDriver->totalCardTable[state];
  gcspy_dUtilsUpdateEnumDesc(&(mcDriver->area),
			     start, start + size,
			     offsetof(mc_driver_tile_t, cards),
			     state);
}

void
mcDriverPromotion (mc_driver_t *mcDriver,
		   char *start,
		   char *end) {
  mcDriver->totalPromotion[0] += (end - start);
  gcspy_dUtilsSetPerc(&(mcDriver->area), start, end,
		      offsetof(mc_driver_tile_t, promotion));
}

void
mcDriverRoot (mc_driver_t *mcDriver,
	      char *start) {
  ++mcDriver->totalRoots;
  gcspy_dUtilsAddSingle(&(mcDriver->area), start, 
			offsetof(mc_driver_tile_t, roots));
}

void
mcDriverMarked (mc_driver_t *mcDriver,
		char *start) {
  ++mcDriver->totalMarking;
  gcspy_dUtilsAddSingle(&(mcDriver->area), start, 
			offsetof(mc_driver_tile_t, marking));
}

void
mcDriverSend (mc_driver_t *mcDriver, unsigned event) {
  int i;
  mc_driver_tile_t *tile;
  gcspy_gc_driver_t *driver = mcDriver->driver;
  int tileNum = mcDriver->area.blockNum;
  double perc;
  char tmp[128];
  int size;

  gcspy_driverStartComm(driver);

  gcspy_driverStream(driver, MC_USED_SPACE_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = mcDriverGetTile(mcDriver, i);
    gcspy_driverStreamIntValue(driver, tile->usedSpace);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, MC_USED_SPACE_STREAM, 2);
  gcspy_driverSummaryValue(driver, mcDriver->totalUsedSpace[0]);
  gcspy_driverSummaryValue(driver, mcDriver->totalUsedSpace[1]);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, MC_CARD_TABLE_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = mcDriverGetTile(mcDriver, i);
    gcspy_driverStreamByteValue(driver, tile->cards);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, MC_CARD_TABLE_STREAM, 3);
  gcspy_driverSummaryValue(driver, mcDriver->totalCardTable[0]);
  gcspy_driverSummaryValue(driver, mcDriver->totalCardTable[1]);
  gcspy_driverSummaryValue(driver, mcDriver->totalCardTable[2]);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, MC_PROMOTION_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = mcDriverGetTile(mcDriver, i);
    gcspy_driverStreamIntValue(driver, tile->promotion);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, MC_PROMOTION_STREAM, 2);
  gcspy_driverSummaryValue(driver, mcDriver->totalPromotion[0]);
  gcspy_driverSummaryValue(driver, mcDriver->totalPromotion[1]);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, MC_ROOTS_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = mcDriverGetTile(mcDriver, i);
    gcspy_driverStreamShortValue(driver, tile->roots);
  }
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, MC_ROOTS_STREAM, 1);
  gcspy_driverSummaryValue(driver, mcDriver->totalRoots);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, MC_MARKING_STREAM, tileNum);
  for (i = 0; i < tileNum; ++i) {
    tile = mcDriverGetTile(mcDriver, i);
    gcspy_driverStreamIntValue(driver, tile->marking);
  }
  gcspy_driverStreamEnd(driver);

#if 0
  gcspy_driverSummary(driver, MC_MARKING_STREAM, 0);
  /*  gcspy_driverSummaryValue(driver, mcDriver->totalMarking); */
  gcspy_driverSummaryEnd(driver);
#endif //0



  size = mcDriver->area.end - mcDriver->area.start;
  sprintf(tmp, "Current Size: %s\n", gcspy_formatSize(size));
  gcspy_driverSpaceInfo(driver, tmp);

  gcspy_driverEndComm(driver);
}

void
mcDriverInit (mc_driver_t *mcDriver,
	      gcspy_gc_driver_t *gcDriver,
	      const char *name,
	      unsigned blockSize,
	      char *start,
	      char *end) {
  /* int i; */
  char tmp[256];
  gcspy_gc_stream_t *stream;
  int tileNum = gcspy_dUtilsTileNum(start, end, blockSize);
  mc_driver_tile_t *tiles = mcDriverAllocateStats(tileNum);
  
  mcDriver->driver = gcDriver;
  gcspy_dUtilsInit(&(mcDriver->area),
		   start, end,
		   0, blockSize, tileNum,
		   (char *) tiles, sizeof(mc_driver_tile_t));

  if (blockSize < 1024)
    sprintf(tmp, "Block Size: %d bytes\n", blockSize);
  else
    sprintf(tmp, "Block Size: %dK\n", (blockSize / 1024));
  gcspy_driverInit(gcDriver, -1, name, "M&C GC",
		   "Block ", tmp, tileNum, NULL, 1);
  mcDriverSetupTileNames(mcDriver, 0, tileNum);

  stream = gcspy_driverAddStream(gcDriver, MC_USED_SPACE_STREAM);
  gcspy_streamInit(stream, MC_USED_SPACE_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Used Space",
		   0, blockSize,
		   0, 0,
		   "Used Space: ", " bytes",
		   GCSPY_GC_STREAM_PRESENTATION_PERCENT,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Red"));

  stream = gcspy_driverAddStream(gcDriver, MC_CARD_TABLE_STREAM);
  gcspy_streamInit(stream, MC_CARD_TABLE_STREAM,
		   GCSPY_GC_STREAM_BYTE_TYPE,
		   "Card Table",
		   0, 2,
		   2, 2, 
		   "Card State: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_ENUM,
		   GCSPY_GC_STREAM_PAINT_STYLE_PLAIN, 0,
		   gcspy_colorDBGetColorWithName("Off White"));
  gcspy_streamAddEnumName(stream, MC_CARD_STATE_DIRTY, "DIRTY");
  gcspy_streamAddEnumName(stream, MC_CARD_STATE_SUMMARISED, "SUMMARISED");
  gcspy_streamAddEnumName(stream, MC_CARD_STATE_CLEAN, "CLEAN");

  stream = gcspy_driverAddStream(gcDriver, MC_PROMOTION_STREAM);
  gcspy_streamInit(stream, MC_PROMOTION_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Promotion",
		   0, blockSize,
		   0, 0,
		   "Promoted: ", " bytes",
		   GCSPY_GC_STREAM_PRESENTATION_PERCENT,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Magenta"));

  stream = gcspy_driverAddStream(gcDriver, MC_ROOTS_STREAM);
  gcspy_streamInit(stream, MC_ROOTS_STREAM,
		   GCSPY_GC_STREAM_SHORT_TYPE,
		   "Roots",
		   0, gcspy_d_utils_roots_per_block(blockSize),
		   0, 0, 
		   "Roots: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Green"));

  stream = gcspy_driverAddStream(gcDriver, MC_MARKING_STREAM);
  gcspy_streamInit(stream, MC_MARKING_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Marking",
		   0, gcspy_d_utils_objects_per_block(blockSize),
		   0, 0,
		   "Marked: ", " objects",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Yellow"));
}
