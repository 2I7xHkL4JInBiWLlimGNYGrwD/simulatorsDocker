/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  gcspy_test_class_driver.c
 **
 **  Tests the H-S Class Driver
 **/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "hs_class_driver.h"
#include "gcspy_main_server.h"
#include "gcspy_timer.h"

#ifdef _SPARC_
#include <thread.h>
#endif //_SPARC_

#ifdef _LINUX_
#include <pthread.h>
#endif //_LINUX_

#define MAX_LEN      ( 128 * 1024 )

static gcspy_main_server_t server;
static class_driver_t classDriver;

#define START_GC_EVENT      0
#define END_GC_EVENT        1

#ifdef  __cplusplus
extern "C" {
#endif //__cplusplus
static void *
mainLoop (void *arg) {
  int count = 0;
  unsigned diff = 0;
  int event;

  while ( 1 ) {
    gcspy_wait(1000);

    if ((count % 2) == 0) {
      event = START_GC_EVENT;
    } else {
      event = END_GC_EVENT;
    }

    if (gcspy_mainServerIsConnected(&server, event)) {
      gcspy_mainServerStartCompensationTimer(&server);

      diff = (count % 2) * 13;

      hsClassDriverStartClasses(&classDriver);
      hsClassDriverClass(&classDriver, "java.lang.String",    (void *) 1,
			 (void *) 666, (unsigned *) 66 + diff, 12, 1);
      hsClassDriverClass(&classDriver, "java.lang.Class",     (void *) 2,
			 (void *) 0,   (unsigned *) 55 + diff, 8, 4);
      hsClassDriverClass(&classDriver, "java.util.HashTable", (void *) 3,
			 (void *) 333, (unsigned *) 33 + diff, 32, 0);
      if ((count % 2) == 0) {
	hsClassDriverClass(&classDriver, "java.lang.Integer", (void *) 4,
			   (void *) 777, (unsigned *) 77 + diff, 24, 0);
      }
      hsClassDriverClass(&classDriver, "java.lang.String",    (void *) 5,
			 (void *) 0, (unsigned *) 44 + diff, 12, 1);
      if ((count % 2) == 0) {
	hsClassDriverClass(&classDriver, "[B",                (void *) 6,
			   (void *) 0, (unsigned *) 88 + diff, 0, 0);
      }

      hsClassDriverStartInstances(&classDriver);

      hsClassDriverInstance(&classDriver, (unsigned *) 66 + diff);
      hsClassDriverInstance(&classDriver, (unsigned *) 55 + diff);
      hsClassDriverInstance(&classDriver, (unsigned *) 44 + diff);
      hsClassDriverInstance(&classDriver, (unsigned *) 44 + diff);
      hsClassDriverInstance(&classDriver, (unsigned *) 66 + diff);
      if ((count % 2) == 0) {
	hsClassDriverInstance(&classDriver, (unsigned *) 77 + diff);
	hsClassDriverInstance(&classDriver, (unsigned *) 77 + diff);
      }
      hsClassDriverInstance(&classDriver, (unsigned *) 44 + diff);
      hsClassDriverInstance(&classDriver, (unsigned *) 55 + diff);
      hsClassDriverInstance(&classDriver, (unsigned *) 66 + diff);
      hsClassDriverInstance(&classDriver, (unsigned *) 66 + diff);
      hsClassDriverInstance(&classDriver, (unsigned *) 66 + diff);

      gcspy_mainServerStopCompensationTimer(&server);

      if (gcspy_mainServerIsConnected(&server, event)) {
	printf("CONNECTED\n");
	hsClassDriverSend(&classDriver, event);
      }
    }
    gcspy_mainServerSafepoint(&server, event);
    ++count;
  }
}
#ifdef  __cplusplus
}
#endif //__cplusplus

int
main (int argc, char *argv[]) {
  char generalInfo[256];
  gcspy_date_time_t time;

#ifdef _SPARC_
  thread_t tid;
#endif //_SPARC_

#ifdef _LINUX_
  pthread_t tid;
#endif //_LINUX_

  gcspy_gc_driver_t *driver;
  int port;
  int res;

  if (argc != 2) {
    gcspy_raise_error("Wrong number of arguments");
  }
  port = atoi(argv[1]);

  printf("-- Initialising main server on port %d\n", port);
  gcspy_mainServerInit(&server, port, MAX_LEN, "Class Driver Test", 1);

  time = gcspy_getDateTime();
  strcpy(generalInfo, "GCspy Test\n\n");
  strcat(generalInfo, "Start Time:\n  ");
  strcpy(generalInfo, gcspy_formatDateTime(time));
  strcat(generalInfo, "\nApplication:\n  Class Driver Test\n\n");
  strcat(generalInfo, "1 Space");
  gcspy_mainServerSetGeneralInfo(&server, generalInfo);

  printf("--   Setting event 0\n");
  gcspy_mainServerAddEvent(&server, START_GC_EVENT, "Start M&C GC");
  printf("--   Setting event 1\n");
  gcspy_mainServerAddEvent(&server, END_GC_EVENT, "End M&C GC");

  printf("--   Setting up driver 0\n");
  driver = gcspy_mainServerAddDriver(&server);
  hsClassDriverInit(&classDriver, driver, "Heap");

#ifdef _SPARC_
  res = thr_create(NULL, 0, mainLoop, NULL, THR_BOUND, &tid);
#endif //_SPARC_

#ifdef _LINUX_
  res = pthread_create(&tid, NULL, mainLoop, NULL);
#endif //_LINUX_

  if (res != 0) {
    printf("Couldn't create thread.\n");
    exit(-1);
  }

  gcspy_mainServerMainLoop(&server);
}
