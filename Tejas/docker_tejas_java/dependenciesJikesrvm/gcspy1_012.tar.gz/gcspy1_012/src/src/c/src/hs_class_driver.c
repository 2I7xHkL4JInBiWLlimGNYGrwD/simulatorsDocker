/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  hs_class_driver.c
 **
 **  Driver instance for the class space
 **/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "hs_class_driver.h"
#include "gcspy_utils.h"

#define DEBUG_TRACE                   0

#if DEBUG_TRACE
#define ifDebugTrace(x)       x
#else
#define ifDebugTrace(x)
#endif

#define iterate_over_hash_table(_ht, _length, _action)                        \
do {                                                                          \
  unsigned _i_;                                                               \
  class_t *theClass;                                                          \
  for (_i_ = 0; _i_ < (_length); ++_i_) {                                     \
    theClass = (_ht)[_i_];                                                    \
    if (theClass != NULL) {                                                   \
      { _action }                                                             \
    }                                                                         \
  }                                                                           \
} while (0)

#define iterate_over_array(_classDriver, _action)                             \
do {                                                                          \
  unsigned theIndex;                                                          \
  class_t *theClass;                                                          \
  for (theIndex = 0; theIndex < _classDriver->arrayLength; ++theIndex) {      \
    theClass = _classDriver->array[theIndex];                                 \
    { _action }                                                               \
  }                                                                           \
} while (0)

static void
zeroHT (class_t **ht, unsigned length) {
  unsigned i;
  for (i = 0; i < length; ++i) {
    ht[i] = NULL;
  }
}

static void
reallocateArray (class_driver_t *classDriver,
		 unsigned newLength) {
  class_t **array;
  unsigned size = newLength * sizeof(class_t *);

  ifDebugTrace( printf("reallocating array, new length = %d\n", newLength); )

  if (classDriver->array != NULL) {
    free(classDriver->array);
  }

  array = (class_t **) malloc(size);
  if (array == NULL) {
    char buffer[256];
    sprintf(buffer,
	    "Class Driver: could not allocate %d bytes for array data",
	    size);
    gcspy_raise_error(buffer);
  }

  classDriver->array = array;
  classDriver->arrayLength = newLength;
}

#ifdef  __cplusplus
extern "C" {
#endif //__cplusplus
static int
classComp (const void *l, const void *r) {
  class_t *cl = *((class_t **) l);
  class_t *cr = *((class_t **) r);
  int comp = strcmp(cl->name, cr->name);
  if ((cl->name[0] == '[') || (cr->name[0] == '[')) {
    if (cl->name[0] != '[')
      return -1;
    else if (cr->name[0] != '[')
      return 1;
    else
      return comp;
  } else if (!comp) {
    if (cl->loader < cr->loader)
      return -1;
    else if (cl->loader > cr->loader)
      return 1;
    else
      return 0;
  } else
    return comp;
}
#ifdef  __cplusplus
}
#endif //__cplusplus

static void
populateArray (class_driver_t *classDriver) {
  class_t **curr = classDriver->array;
  gcspy_assert(classDriver->arrayLength == classDriver->classNum);
  gcspy_assert(classDriver->arrayLength <= classDriver->htLength);
  ifDebugTrace( printf("populating array, array length = %d, ht length = %d\n",
		       classDriver->arrayLength, classDriver->htLength); )
  iterate_over_hash_table(classDriver->classHT, classDriver->htLength, {
    ifDebugTrace( printf("  index %d = %s %8x\n", curr - classDriver->array,
			 theClass->name, theClass->loader); )
    *curr = theClass;
    ++curr;
  });
  gcspy_assert(classDriver->arrayLength == (curr - classDriver->array));
  qsort(classDriver->array, classDriver->arrayLength,
	sizeof(class_t **), classComp);
}

static unsigned
hashValueWithString (char *string) {
  char *c = string;
  unsigned ret = 0;
  while (*c != '\0') {
    ret += (int) *c;
    ++c;
  }
  return ret;
}

static unsigned
hashValueGeneric (class_driver_t *classDriver,
		  unsigned value) {
  return (unsigned) ((value >> 3) % (unsigned) classDriver->htLength);
}

static unsigned
hashValueWithClass (class_driver_t *classDriver,
		    char *name,
		    class_id_t classId) {
  unsigned ret = hashValueGeneric(classDriver,
			     hashValueWithString(name) ^ (unsigned) classId);
  return ret;
}

static unsigned
hashValueWithKey (class_driver_t *classDriver,
		  class_key_t key) {
  unsigned ret = hashValueGeneric(classDriver, (unsigned) key);
  return ret;
}

static unsigned
getNextIndex (class_driver_t *classDriver,
	      unsigned index) {
  unsigned ret = (index+1) % classDriver->htLength;
  return ret;
}

static void
addToClassHT (class_driver_t *classDriver,
	      class_t *cl) {
  unsigned index = hashValueWithClass(classDriver, cl->name, cl->classId);
  class_t **ht = classDriver->classHT;
  ifDebugTrace( printf("add to class ht, %s %08x, index = %d\n",
		       cl->name, cl->loader, index); )
  while (ht[index] != NULL) {
    index = getNextIndex(classDriver, index);
  }
  ht[index] = cl;
}

static void
addToKeyHT (class_driver_t *classDriver,
	    class_t *cl) {
  unsigned index = hashValueWithKey(classDriver, cl->key);
  class_t **ht = classDriver->keyHT;
  ifDebugTrace( printf("add to key ht (%d), %d, index = %d\n",
		       classDriver->classNum, cl->key, index); )
  while (ht[index] != NULL) {
    index = getNextIndex(classDriver, index);
  }
  ht[index] = cl;
}

static class_t *
lookupWithClass (class_driver_t *classDriver,
		 char *name,
		 class_id_t classId) {
  unsigned index = hashValueWithClass(classDriver, name, classId);
  class_t **ht = classDriver->classHT;
  class_t *cl = ht[index];

  while (cl != NULL) {
    if (!strcmp(name, cl->name) && (classId == cl->classId)) {
      ifDebugTrace( printf("class lookup, %s %08x, found at index %d\n",
			   name, classId, index); )
      return cl;
    }

    index = getNextIndex(classDriver, index);
    cl = ht[index];
  }

 ifDebugTrace( printf("class lookup, %s %08x, not found\n", name, classId); )
  return NULL;
}

static class_t *
lookupWithKey (class_driver_t *classDriver,
	       class_key_t key) {
  unsigned index = hashValueWithKey(classDriver, key);
  class_t **ht = classDriver->keyHT;
  class_t *cl = ht[index];

  while (cl != NULL) {
    if (key == cl->key) {
      ifDebugTrace( printf("key lookup, %d, found at index %d\n",
			   key, index); )
      return cl;
    }

    index = getNextIndex(classDriver, index);
    cl = ht[index];
  }

  ifDebugTrace( printf("key lookup, %d, not found\n", key); )
  return NULL;
}

static void
setupTileNames (class_driver_t *classDriver) {
  char tmp[1024];
  iterate_over_array(classDriver, {
    if (theClass->loader == NULL)
      sprintf(tmp, "\n%s\nLoader: Default", theClass->name);
    else
      sprintf(tmp, "\n%s\nLoader: 0x%08x", theClass->name, theClass->loader);
    gcspy_driverSetTileName(classDriver->driver, theIndex, tmp);
  });
}

static class_t *
allocateNewClass (char *name) {
  class_t *ret;
  unsigned size = sizeof(class_t) + strlen(name) + 1;
  ret = (class_t *) malloc(size);
  if (ret == NULL) {
    char buffer[256];
    sprintf(buffer,
	    "Class Driver: could not allocate %d bytes for class data",
	    size);
    gcspy_raise_error(buffer);
  }
  return ret;
}

static void
reallocateHTs (class_driver_t *classDriver,
	       unsigned newLength) {
  class_t **classHT;
  class_t **oldClassHT = classDriver->classHT;
  class_t **keyHT;
  class_t **oldKeyHT = classDriver->keyHT;
  unsigned size = newLength * sizeof(class_t *);
  unsigned oldLength = classDriver->htLength;

  gcspy_assert( ((oldClassHT == NULL) && (oldKeyHT == NULL)) ||
		(classDriver->htMaxOccupancy == classDriver->classNum) );

  classDriver->htLength = newLength;
  classDriver->htMaxOccupancy = (newLength * CLASS_HASH_MAX_OCCUPANCY) / 100;

  ifDebugTrace( printf("allocating HTs, old length = %d, new length = %d\n",
		       oldLength, newLength); )

  classHT = (class_t **) malloc(size);
  if (classHT == NULL) {
    char buffer[256];
    sprintf(buffer,
	 "Class Driver: could not allocate %d bytes for class hash table data",
	    size);
    gcspy_raise_error(buffer);
  }
  zeroHT(classHT, newLength);
  classDriver->classHT = classHT;

  if (oldClassHT != NULL) {
    ifDebugTrace( printf("rehashing class HT, %d entries\n",
			 oldLength); )

    iterate_over_hash_table(oldClassHT, oldLength, {
      addToClassHT(classDriver, theClass);
    });

    free(oldClassHT);
  }

  keyHT = (class_t **) malloc(size);
  if (keyHT == NULL) {
    char buffer[256];
    sprintf(buffer,
	   "Class Driver: could not allocate %d bytes for key hash table data",
	    size);
    gcspy_raise_error(buffer);
  }
  zeroHT(keyHT, newLength);
  classDriver->keyHT = keyHT;

  if (oldKeyHT != NULL) {
    ifDebugTrace( printf("rehashing key HT, %d entries\n",
			 oldLength); )

    iterate_over_hash_table(oldKeyHT, oldLength, {
      addToKeyHT(classDriver, theClass);
    });

    free(oldKeyHT);
  }
}

static void
resizeHTs (class_driver_t *classDriver) {
  unsigned newLength =
    ((100 + CLASS_HASH_EXTENSION_PERCENT) * classDriver->htLength) / 100;
  reallocateHTs(classDriver, newLength);
}

void
hsClassDriverStartClasses (class_driver_t *classDriver) {
  zeroHT(classDriver->keyHT, classDriver->htLength);
  iterate_over_array(classDriver, {
    theClass->loaded = 0;
  });

  ifDebugTrace( printf("StartClasses, ht length = %d, class num = %d\n",
		       classDriver->htLength, classDriver->classNum); )
  classDriver->totalInstances = 0;
  classDriver->loadedClasses = 0;
}

void
hsClassDriverClass (class_driver_t *classDriver,
		    char *name,
		    class_id_t classId,
		    class_loader_t loader,
		    class_key_t key,
		    unsigned instanceSize,
		    unsigned refNum) {
  class_t *cl = lookupWithClass(classDriver, name, classId);

  if (cl == NULL) {
    if (classDriver->classNum == classDriver->htMaxOccupancy) {
      resizeHTs(classDriver);
    }

    cl = allocateNewClass(name);
    cl->name = ((char *) cl + sizeof(class_t));
    cl->classId = classId;
    strcpy(cl->name, name);
    cl->instanceSize = instanceSize;
    cl->refNum = refNum;

    addToClassHT(classDriver, cl);
    ++classDriver->classNum;

    ifDebugTrace( printf("Added %s %08x\n", cl->name, cl->classId); )
  }

  cl->loader = loader;
  cl->key = key;
  cl->instanceNum = 0;
  cl->loaded = 1;
  ++classDriver->loadedClasses;
  addToKeyHT(classDriver, cl);
}

void
hsClassDriverStartInstances (class_driver_t *classDriver) {
}

void
hsClassDriverInstance (class_driver_t *classDriver,
		       class_key_t key) {
  class_t *cl = lookupWithKey(classDriver, key);
  /* gcspy_assert(cl != NULL); */
  if (cl != NULL) {
    gcspy_assert(cl->loaded);
    ++cl->instanceNum;
    ++classDriver->totalInstances;
  }
}

void
hsClassDriverSend (class_driver_t *classDriver,
		   unsigned event) {
  char tmp[256];
  gcspy_gc_driver_t *driver = classDriver->driver;
  int i;
  unsigned classNum = classDriver->classNum;

  if (classNum != classDriver->arrayLength) {
    reallocateArray(classDriver, classNum);
    populateArray(classDriver);

    gcspy_driverResize(classDriver->driver, classNum);
    setupTileNames(classDriver);
  }

  gcspy_assert(classDriver->arrayLength == classNum);
  gcspy_assert(classDriver->arrayLength <= classDriver->htLength);



  gcspy_driverStartComm(driver);

  gcspy_driverStream(driver, CLASS_INSTANCE_NUM_STREAM, classNum);
  iterate_over_array(classDriver, {
    gcspy_driverStreamIntValue(driver, theClass->instanceNum);
  });
  gcspy_driverStreamEnd(driver);

  gcspy_driverSummary(driver, CLASS_INSTANCE_NUM_STREAM, 1);
  gcspy_driverSummaryValue(driver, classDriver->totalInstances);
  gcspy_driverSummaryEnd(driver);



  gcspy_driverStream(driver, CLASS_INSTANCE_SIZE_STREAM, classNum);
  iterate_over_array(classDriver, {
    gcspy_driverStreamIntValue(driver, theClass->instanceSize);
  });
  gcspy_driverStreamEnd(driver);



  gcspy_driverStream(driver, CLASS_INSTANCE_REF_NUM_STREAM, classNum);
  iterate_over_array(classDriver, {
    gcspy_driverStreamIntValue(driver, theClass->refNum);
  });
  gcspy_driverStreamEnd(driver);



  gcspy_driverControl(driver);
  iterate_over_array(classDriver, {
    if (!theClass->loaded) {
      gcspy_driverControlValues(driver,
				GCSPY_GC_DRIVER_CONTROL_UNUSED,
				theIndex,
				1);
    }
  });
  if ((classNum > 0) && (classDriver->array[classNum-1]->name[0] == '[')) {
    for (i = classNum-1; i >= 0; --i) {
      if (classDriver->array[i]->name[0] != '[') {
	gcspy_driverControlValues(driver,
				  GCSPY_GC_DRIVER_CONTROL_SEPARATOR,
				  i+1, 1);
	break;
      }
    }
  }
  gcspy_driverControlEnd(driver);



  sprintf(tmp, "Classes: %d\nLoaded Classes: %d\n",
	  classDriver->classNum, classDriver->loadedClasses);
  gcspy_driverSpaceInfo(driver, tmp);

  gcspy_driverEndComm(driver);
}

void
hsClassDriverInit (class_driver_t *classDriver,
		   gcspy_gc_driver_t *gcDriver,
		   const char *name) {
  gcspy_gc_stream_t *stream;
  classDriver->driver = gcDriver;

  gcspy_driverInit(gcDriver, -1, name, "Classes",
		   "Class ", "", 1, "UNLOADED", 0);
  
  classDriver->classNum = 0;

  classDriver->classHT = NULL;
  classDriver->keyHT = NULL;
  classDriver->htLength = 0;
  classDriver->array = NULL;
  classDriver->arrayLength = 0;

  reallocateHTs(classDriver, CLASS_DEFAULT_HASH_LEN);

  stream = gcspy_driverAddStream(gcDriver, CLASS_INSTANCE_NUM_STREAM);
  gcspy_streamInit(stream, CLASS_INSTANCE_NUM_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Instance Num",
		   0, CLASS_MAX_INSTANCE_NUM,
		   0, 0,
		   "Instance Num: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Yellow"));

  stream = gcspy_driverAddStream(gcDriver, CLASS_INSTANCE_SIZE_STREAM);
  gcspy_streamInit(stream, CLASS_INSTANCE_SIZE_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Instance Size",
		   0, CLASS_MAX_INSTANCE_SIZE,
		   0, 0,
		   "Instance Size: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Pink"));

  stream = gcspy_driverAddStream(gcDriver, CLASS_INSTANCE_REF_NUM_STREAM);
  gcspy_streamInit(stream, CLASS_INSTANCE_REF_NUM_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Reference Num",
		   0, CLASS_MAX_REF_NUM,
		   0, 0,
		   "Reference Num: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Green"));
}
