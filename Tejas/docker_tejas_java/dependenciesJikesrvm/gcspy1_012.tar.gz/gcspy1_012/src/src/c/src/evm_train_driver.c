/**
 **  evm_train_driver.c
 **
 **  Driver instance for the EVM Train collector
 **/

#include <stdio.h>
#include <stdlib.h>
#include "gcspy_gc_stream.h"
#include "evm_train_driver.h"

/***** REGIONS *****/

static train_region_t *
trainAllocateRegions (int regionNum) {
  int len = regionNum * sizeof(train_region_t);
  train_region_t *regions = (train_region_t *) malloc(len);
  if (regions == NULL) {
    char buffer[256];
    sprintf(buffer,
	    "Train Driver: could not allocate %d bytes for region data",
	    len);
    gcspy_raise_error(buffer);
  }
  return regions;
}

static void
trainSetupRegionNames (train_driver_t *trainDriver,
		       int from,
		       int to) {
  int i;
  char tmp[256];
  for (i = from; i < to; ++i) {
    gcspy_dUtilsRangeString(&(trainDriver->regionArea), i, tmp);
    gcspy_driverSetTileName(trainDriver->regionDriver, i, tmp);
  }
}

static train_region_t *
trainGetRegion (train_driver_t *trainDriver, int index) {
  return (train_region_t *)
    gcspy_d_utils_get_stats_struct(&(trainDriver->regionArea), index, 0);
}

static int
trainGetRegionIndex (train_driver_t *trainDriver, char *addr) {
  return gcspy_d_utils_get_index(&(trainDriver->regionArea), addr);
}

static char *
trainGetRegionAddr (train_driver_t *trainDriver, int index) {
  return gcspy_d_utils_get_addr(&(trainDriver->regionArea), index);
}

/***** CARS *****/

static train_car_t *
trainGetCar (train_driver_t *trainDriver, int index) {
  return &(trainDriver->cars[index]);
}

static train_car_t *
trainAllocateCars (int carNum) {
  int len = carNum * sizeof(train_car_t);
  train_car_t *cars = (train_car_t *) malloc(len);
  if (cars == NULL) {
    char buffer[256];
    sprintf(buffer,
	    "Train Driver: could not allocate %d bytes for car data",
	    len);
    gcspy_raise_error(buffer);
  }
  return cars;
}

static void
trainSetupCarNames (train_driver_t *trainDriver,
		    int from,
		    int to) {
  int i;
  for (i = from; i < to; ++i) {
    gcspy_driverSetTileName(trainDriver->carDriver, i, "");
  }
}

/***** TRAINS *****/

static train_train_t *
trainGetTrain (train_driver_t *trainDriver, int index) {
  return &(trainDriver->trains[index]);
}

static train_train_t *
trainAllocateTrains (int trainNum) {
  int len = trainNum * sizeof(train_train_t);
  train_train_t *trains = (train_train_t *) malloc(len);
  if (trains == NULL) {
    char buffer[256];
    sprintf(buffer,
	    "Train Driver: could not allocate %d bytes for train data",
	    len);
    gcspy_raise_error(buffer);
  }
  return trains;
}

static void
trainSetupTrainNames (train_driver_t *trainDriver,
		      int from,
		      int to) {
  int i;
  for (i = from; i < to; ++i) {
    gcspy_driverSetTileName(trainDriver->trainDriver, i, "");
  }
}

/***** API *****/

void
trainZero (train_driver_t *trainDriver,
	   char *regionEnd,
	   unsigned carNum,
	   unsigned trainNum) {
  int i;
  train_region_t *region;
  train_car_t *car;
  int totalRegionSpace = regionEnd - trainDriver->regionArea.start;

  /***** REGIONS *****/

  if (regionEnd != trainDriver->regionArea.end) {
    int regionNum = gcspy_dUtilsTileNum(trainDriver->regionArea.start,
					regionEnd,
					trainDriver->regionArea.blockSize); 
    /* printf("resizing to %8x, tileNum = %d\n", regionEnd, tileNum); */
    trainDriver->regionArea.end = regionEnd;
    trainDriver->regionArea.blockNum = regionNum;
    free(trainDriver->regionArea.stats);
    trainDriver->regionArea.stats =
      (char *) trainAllocateRegions(regionNum);

    gcspy_driverResize(trainDriver->regionDriver, regionNum);
    trainSetupRegionNames(trainDriver, 0, regionNum);
  }

  for (i = 0; i < trainDriver->regionArea.blockNum; ++i) {
    region = trainGetRegion(trainDriver, i);
    region->allocated = 0;
    region->cards = REGION_CARD_STATE_CLEAN;
  }

  trainDriver->totalRegionUsedSpace[0] = 0;
  trainDriver->totalRegionUsedSpace[1] = totalRegionSpace;
  for (i = 0; i < 4; ++i)
    trainDriver->totalRegionCards[i] = 0;
  for (i = 0; i < 3; ++i)
    trainDriver->totalRegionType[i] = 0;
  trainDriver->totalRegionAllocated = 0;
  trainDriver->totalRegionDirectAlloc[0] = 0;
  trainDriver->totalRegionDirectAlloc[1] = totalRegionSpace;
  trainDriver->totalRegionProm[0] = 0;
  trainDriver->totalRegionProm[1] = totalRegionSpace;
  trainDriver->totalRegionEvac[0] = 0;
  trainDriver->totalRegionEvac[1] = totalRegionSpace;
  trainDriver->totalRegionWeakEvac[0] = 0;
  trainDriver->totalRegionWeakEvac[1] = totalRegionSpace;

  gcspy_driverControl(trainDriver->regionDriver);

  /***** CARS *****/

  trainDriver->lastTrain = -1;

  if (carNum != trainDriver->carNum) {
    trainDriver->carNum = carNum;
    free(trainDriver->cars);
    trainDriver->cars = trainAllocateCars(carNum);

    gcspy_driverResize(trainDriver->carDriver, carNum);
    trainSetupCarNames(trainDriver, 0, carNum);
  }

  trainDriver->totalCarUsedSpace[0] = 0;
  trainDriver->totalCarUsedSpace[1] = 0;
  for (i = 0; i < 3; ++i)
    trainDriver->totalCarType[i] = 0;
  trainDriver->totalCarRSLen = 0;
  trainDriver->totalCarRSCapacity = 0;
  trainDriver->totalCarRSSize = 0;
  trainDriver->totalCarSize = 0;
  trainDriver->totalCarObjects = 0;
  trainDriver->totalCarInCS[0] = 0;
  trainDriver->totalCarInCS[1] = 0;
  trainDriver->totalCarCSSize[0] = 0;
  trainDriver->totalCarCSSize[1] = 0;
  trainDriver->totalCarHigherRefs[0] = 0;
  trainDriver->totalCarHigherRefs[1] = 0;
  trainDriver->totalCarDirectAlloc[0] = 0;
  trainDriver->totalCarDirectAlloc[1] = 0;
  trainDriver->totalCarProm[0] = 0;
  trainDriver->totalCarProm[1] = 0;
  trainDriver->totalCarEvac[0] = 0;
  trainDriver->totalCarEvac[1] = 0;
  trainDriver->totalCarWeakEvac[0] = 0;
  trainDriver->totalCarWeakEvac[1] = 0;

  gcspy_driverControl(trainDriver->carDriver);

  /***** TRAIN *****/

  if (trainNum != trainDriver->trainNum) {
    trainDriver->trainNum = trainNum;
    free(trainDriver->trains);
    trainDriver->trains = trainAllocateTrains(trainNum);

    gcspy_driverResize(trainDriver->trainDriver, trainNum);
    trainSetupTrainNames(trainDriver, 0, trainNum);
  }

  trainDriver->totalTrainUsedSpace[0] = 0;
  trainDriver->totalTrainUsedSpace[1] = 0;
  trainDriver->totalTrainRSLen = 0;
  trainDriver->totalTrainLength = 0;
  trainDriver->totalTrainSize = 0;
  trainDriver->totalTrainObjects = 0;
  trainDriver->totalTrainPopularObjects = 0;
  trainDriver->totalTrainHigherRefs[0] = 0;
  trainDriver->totalTrainHigherRefs[1] = 0;
  trainDriver->totalTrainCarsInCS = 0;
  trainDriver->totalTrainCSSize[0] = 0;
  trainDriver->totalTrainCSSize[1] = 0;
  trainDriver->totalTrainDirectAlloc[0] = 0;
  trainDriver->totalTrainDirectAlloc[1] = 0;
  trainDriver->totalTrainProm[0] = 0;
  trainDriver->totalTrainProm[1] = 0;
  trainDriver->totalTrainEvac[0] = 0;
  trainDriver->totalTrainEvac[1] = 0;
  trainDriver->totalTrainWeakEvac[0] = 0;
  trainDriver->totalTrainWeakEvac[1] = 0;
}

void
trainCard (train_driver_t *trainDriver,
	   char *start,
	   int size,
	   int state) {
  ++trainDriver->totalRegionCards[state];
  gcspy_dUtilsUpdateEnumDesc(&(trainDriver->regionArea),
			     start, start + size,
			     offsetof(train_region_t, cards),
			     state);
}

void
trainStandardRegion (train_driver_t *trainDriver,
		     int id,
		     int trainID,
		     int carID,
		     int usedSpace,
		     int directAlloc,
		     int prom,
		     int evac,
		     int weakEvac) {
  train_region_t *region;
  region = trainGetRegion(trainDriver, id);

  region->trainID = trainID;
  region->carID = carID;
  region->usedSpace = usedSpace;
  region->type = REGION_TYPE_STANDARD;
  region->directAlloc = directAlloc;
  region->prom = prom;
  region->evac = evac;
  region->weakEvac = weakEvac;
  region->allocated = 1;

  trainDriver->totalRegionUsedSpace[0] += usedSpace;
  ++trainDriver->totalRegionType[REGION_TYPE_STANDARD];
  ++trainDriver->totalRegionAllocated;
  trainDriver->totalRegionDirectAlloc[0] += directAlloc;
  trainDriver->totalRegionProm[0] += prom;
  trainDriver->totalRegionEvac[0] += evac;
  trainDriver->totalRegionWeakEvac[0] += weakEvac;
}

void
trainOversizedRegion (train_driver_t *trainDriver,
		      int startID,
		      int length,
		      int trainID,
		      int carID,
		      int usedSpace,
		      int directAlloc,
		      int prom,
		      int evac,
		      int weakEvac) {
  train_region_t *region;
  int regionSize = trainDriver->regionArea.blockSize;
  int i;

  trainDriver->totalRegionUsedSpace[0] += usedSpace;
  ++trainDriver->totalRegionType[REGION_TYPE_OVERSIZED];
  ++trainDriver->totalRegionAllocated;
  trainDriver->totalRegionDirectAlloc[0] += directAlloc;
  trainDriver->totalRegionProm[0] += prom;
  trainDriver->totalRegionEvac[0] += evac;
  trainDriver->totalRegionWeakEvac[0] += weakEvac;

  for (i = startID; i < (startID+length); ++i) {
    region = trainGetRegion(trainDriver, i);

    region->trainID = trainID;
    region->carID = carID;

    if (usedSpace > regionSize) {
      region->usedSpace = regionSize;
      usedSpace -= regionSize;
    } else {
      region->usedSpace = usedSpace;
      usedSpace = 0;
    }

    if (directAlloc > regionSize) {
      region->directAlloc = regionSize;
      directAlloc -= regionSize;
    } else {
      region->directAlloc = directAlloc;
      directAlloc = 0;
    }

    if (prom > regionSize) {
      region->prom = regionSize;
      prom -= regionSize;
    } else {
      region->prom = prom;
      prom = 0;
    }

    if (evac > regionSize) {
      region->evac = regionSize;
      evac -= regionSize;
    } else {
      region->evac = evac;
      evac = 0;
    }

    if (weakEvac > regionSize) {
      region->weakEvac = regionSize;
      weakEvac -= regionSize;
    } else {
      region->weakEvac = weakEvac;
      weakEvac = 0;
    }

    region->type = REGION_TYPE_OVERSIZED;
    region->allocated = 1;
  }

  gcspy_driverControlValues(trainDriver->regionDriver,
			    GCSPY_GC_DRIVER_CONTROL_LINK,
			    startID,
			    length-1);
}

void
trainPopularRegion (train_driver_t *trainDriver,
		    int id,
		    int usedSpace,
		    int directAlloc,
		    int prom,
		    int evac,
		    int weakEvac) {
  train_region_t *region;
  region = trainGetRegion(trainDriver, id);

  region->trainID = -1;
  region->carID = -1;
  region->usedSpace = usedSpace;
  region->type = REGION_TYPE_POPULAR;
  region->directAlloc = directAlloc;
  region->prom = prom;
  region->evac = evac;
  region->weakEvac = weakEvac;
  region->allocated = 1;

  trainDriver->totalRegionUsedSpace[0] += usedSpace;
  ++trainDriver->totalRegionType[REGION_TYPE_POPULAR];
  ++trainDriver->totalRegionAllocated;
  trainDriver->totalRegionDirectAlloc[0] += directAlloc;
  trainDriver->totalRegionProm[0] += prom;
  trainDriver->totalRegionEvac[0] += evac;
  trainDriver->totalRegionWeakEvac[0] += weakEvac;
}

void
trainCar (train_driver_t *trainDriver,
	  int id,
	  int trainID,
	  int carID,
	  int type,
	  int usedSpace,
	  int size,
	  int objects,
	  int rsLen,
	  int rsSize,
	  int rsCoarseness,
	  int rsCapacity,
	  int higherRefs,
	  int inCS,
	  int csSize,
	  int directAlloc,
	  int prom,
	  int evac,
	  int weakEvac) {
  train_car_t *car = trainGetCar(trainDriver, id);
  car->trainID = trainID;
  car->carID = carID;
  car->usedSpace = usedSpace;
  car->rsLen = rsLen;
  car->rsCapacity = rsCapacity;
  car->rsCoarseness = rsCoarseness;
  car->rsSize = rsSize;
  car->type = type;
  car->size = size;
  car->objects = objects;
  car->higherRefs = higherRefs;
  car->inCS = inCS;
  car->csSize = csSize;
  car->directAlloc = directAlloc;
  car->prom = prom;
  car->evac = evac;
  car->weakEvac = weakEvac;

  trainDriver->totalCarUsedSpace[0] += usedSpace;
  trainDriver->totalCarUsedSpace[1] += size;
  ++trainDriver->totalCarType[type];
  trainDriver->totalCarRSLen += rsLen;
  trainDriver->totalCarRSCapacity += rsCapacity;
  trainDriver->totalCarRSSize += rsSize;
  trainDriver->totalCarSize += size;
  trainDriver->totalCarObjects += objects;
  ++trainDriver->totalCarHigherRefs[higherRefs];
  ++trainDriver->totalCarInCS[inCS];
  trainDriver->totalCarCSSize[0] += csSize;
  trainDriver->totalCarCSSize[1] += size;
  trainDriver->totalCarDirectAlloc[0] += directAlloc;
  trainDriver->totalCarDirectAlloc[1] += size;
  trainDriver->totalCarProm[0] += prom;
  trainDriver->totalCarProm[1] += size;
  trainDriver->totalCarEvac[0] += evac;
  trainDriver->totalCarEvac[1] += size;
  trainDriver->totalCarWeakEvac[0] += weakEvac;
  trainDriver->totalCarWeakEvac[1] += size;

  if (trainDriver->lastTrain != trainID) {
    if (id != 0) {
      gcspy_driverControlValues(trainDriver->carDriver,
				GCSPY_GC_DRIVER_CONTROL_SEPARATOR,
				id,
				1);
    }
    trainDriver->lastTrain = trainID;
  }
}

void
trainTrain (train_driver_t *trainDriver,
	    int id,
	    int trainID,
	    int usedSpace,
	    int objects,
	    int popularObjects,
	    int length,
	    int size,
	    int rsLen,
	    int higherRefs,
	    int carsInCS,
	    int csSize,
	    int directAlloc,
	    int prom,
	    int evac,
	    int weakEvac) {
  train_train_t *train = trainGetTrain(trainDriver, id);
  train->trainID = trainID;
  train->usedSpace = usedSpace;
  train->popularObjects = popularObjects;
  train->objects = objects;
  train->length = length;
  train->size = size;
  train->rsLen = rsLen;
  train->higherRefs = higherRefs;
  train->carsInCS = carsInCS;
  train->csSize = csSize;
  train->directAlloc = directAlloc;
  train->prom = prom;
  train->evac = evac;
  train->weakEvac = weakEvac;

  trainDriver->totalTrainUsedSpace[0] += usedSpace;
  trainDriver->totalTrainUsedSpace[1] += size;
  trainDriver->totalTrainRSLen += rsLen;
  trainDriver->totalTrainLength += length;
  trainDriver->totalTrainSize += size;
  ++trainDriver->totalTrainHigherRefs[higherRefs];
  trainDriver->totalTrainObjects += objects;
  trainDriver->totalTrainPopularObjects += popularObjects;
  trainDriver->totalTrainCarsInCS += carsInCS;
  trainDriver->totalTrainCSSize[0] += csSize;
  trainDriver->totalTrainCSSize[1] += size;
  trainDriver->totalTrainDirectAlloc[0] += directAlloc;
  trainDriver->totalTrainDirectAlloc[1] += size;
  trainDriver->totalTrainProm[0] += prom;
  trainDriver->totalTrainProm[1] += size;
  trainDriver->totalTrainEvac[0] += evac;
  trainDriver->totalTrainEvac[1] += size;
  trainDriver->totalTrainWeakEvac[0] += weakEvac;
  trainDriver->totalTrainWeakEvac[1] += size;
}

void
trainSend (train_driver_t *driver, unsigned event) {
  int i;
  train_region_t *region;
  train_car_t *car;
  train_train_t *train;
  gcspy_gc_driver_t *regionDriver = driver->regionDriver;
  gcspy_gc_driver_t *carDriver = driver->carDriver;
  gcspy_gc_driver_t *trainDriver = driver->trainDriver;
  int regionNum = driver->regionArea.blockNum;
  int carNum = driver->carNum;
  int trainNum = driver->trainNum;
  char tmp[128];
  double perc;
  int size;

  /***** REGIONS *****/

  gcspy_driverStartComm(regionDriver);


  gcspy_driverStream(regionDriver, REGION_USED_SPACE_STREAM, regionNum);
  for (i = 0; i < regionNum; ++i) {
    region = trainGetRegion(driver, i);
    gcspy_driverStreamIntValue(regionDriver, region->usedSpace);
  }
  gcspy_driverStreamEnd(regionDriver);

  gcspy_driverSummary(regionDriver, REGION_USED_SPACE_STREAM, 2);
  gcspy_driverSummaryValue(regionDriver, driver->totalRegionUsedSpace[0]);
  gcspy_driverSummaryValue(regionDriver, driver->totalRegionUsedSpace[1]);
  gcspy_driverSummaryEnd(regionDriver);


  gcspy_driverStream(regionDriver, REGION_CARDS_STREAM, regionNum);
  for (i = 0; i < regionNum; ++i) {
    region = trainGetRegion(driver, i);
    gcspy_driverStreamByteValue(regionDriver, (char) region->cards);
  }
  gcspy_driverStreamEnd(regionDriver);

  gcspy_driverSummary(regionDriver, REGION_CARDS_STREAM, 4);
  for (i = 0; i < 4; ++i)
    gcspy_driverSummaryValue(regionDriver, driver->totalRegionCards[i]);
  gcspy_driverSummaryEnd(regionDriver);


  gcspy_driverStream(regionDriver, REGION_TYPE_STREAM, regionNum);
  for (i = 0; i < regionNum; ++i) {
    region = trainGetRegion(driver, i);
    gcspy_driverStreamByteValue(regionDriver, (char) region->type);
  }
  gcspy_driverStreamEnd(regionDriver);

  gcspy_driverSummary(regionDriver, REGION_TYPE_STREAM, 3);
  for (i = 0; i < 3; ++i)
    gcspy_driverSummaryValue(regionDriver, driver->totalRegionType[i]);
  gcspy_driverSummaryEnd(regionDriver);


  gcspy_driverStream(regionDriver, REGION_TRAIN_ID_STREAM, regionNum);
  for (i = 0; i < regionNum; ++i) {
    region = trainGetRegion(driver, i);
    gcspy_driverStreamIntValue(regionDriver, region->trainID);
  }
  gcspy_driverStreamEnd(regionDriver);


  gcspy_driverStream(regionDriver, REGION_CAR_ID_STREAM, regionNum);
  for (i = 0; i < regionNum; ++i) {
    region = trainGetRegion(driver, i);
    gcspy_driverStreamIntValue(regionDriver, region->carID);
  }
  gcspy_driverStreamEnd(regionDriver);


  gcspy_driverStream(regionDriver, REGION_DIRECT_ALLOC_STREAM, regionNum);
  for (i = 0; i < regionNum; ++i) {
    region = trainGetRegion(driver, i);
    gcspy_driverStreamIntValue(regionDriver, region->directAlloc);
  }
  gcspy_driverStreamEnd(regionDriver);

  gcspy_driverSummary(regionDriver, REGION_DIRECT_ALLOC_STREAM, 2);
  gcspy_driverSummaryValue(regionDriver, driver->totalRegionDirectAlloc[0]);
  gcspy_driverSummaryValue(regionDriver, driver->totalRegionDirectAlloc[1]);
  gcspy_driverSummaryEnd(regionDriver);


  gcspy_driverStream(regionDriver, REGION_PROM_STREAM, regionNum);
  for (i = 0; i < regionNum; ++i) {
    region = trainGetRegion(driver, i);
    gcspy_driverStreamIntValue(regionDriver, region->prom);
  }
  gcspy_driverStreamEnd(regionDriver);

  gcspy_driverSummary(regionDriver, REGION_PROM_STREAM, 2);
  gcspy_driverSummaryValue(regionDriver, driver->totalRegionProm[0]);
  gcspy_driverSummaryValue(regionDriver, driver->totalRegionProm[1]);
  gcspy_driverSummaryEnd(regionDriver);


  gcspy_driverStream(regionDriver, REGION_EVAC_STREAM, regionNum);
  for (i = 0; i < regionNum; ++i) {
    region = trainGetRegion(driver, i);
    gcspy_driverStreamIntValue(regionDriver, region->evac);
  }
  gcspy_driverStreamEnd(regionDriver);

  gcspy_driverSummary(regionDriver, REGION_EVAC_STREAM, 2);
  gcspy_driverSummaryValue(regionDriver, driver->totalRegionEvac[0]);
  gcspy_driverSummaryValue(regionDriver, driver->totalRegionEvac[1]);
  gcspy_driverSummaryEnd(regionDriver);


  gcspy_driverStream(regionDriver, REGION_WEAK_EVAC_STREAM, regionNum);
  for (i = 0; i < regionNum; ++i) {
    region = trainGetRegion(driver, i);
    gcspy_driverStreamIntValue(regionDriver, region->weakEvac);
  }
  gcspy_driverStreamEnd(regionDriver);

  gcspy_driverSummary(regionDriver, REGION_WEAK_EVAC_STREAM, 2);
  gcspy_driverSummaryValue(regionDriver, driver->totalRegionWeakEvac[0]);
  gcspy_driverSummaryValue(regionDriver, driver->totalRegionWeakEvac[1]);
  gcspy_driverSummaryEnd(regionDriver);


  /* I setup the control stream in the Zero call */
  /* gcspy_driverControl(regionDriver); */
  for (i = 0; i < regionNum; ++i) {
    region = trainGetRegion(driver, i);
    if (!region->allocated)
      gcspy_driverControlValues(regionDriver,
				GCSPY_GC_DRIVER_CONTROL_UNUSED,
				i,
				1);
  }
  gcspy_driverControlEnd(regionDriver);


  perc = 100.0 *
    ((double) driver->totalRegionAllocated /
    (double) driver->regionArea.blockNum);
  size = driver->regionArea.end - driver->regionArea.start;
  sprintf(tmp, "Current Size: %s\nAllocated Regions: %1.1lf%%  (%s)\n",
	  gcspy_formatSize(size),
	  perc,
	  gcspy_formatLargeNumber(driver->totalRegionAllocated));
  gcspy_driverSpaceInfo(regionDriver, tmp);


  gcspy_driverEndComm(regionDriver);


  /***** CARS *****/

  gcspy_driverStartComm(carDriver);


  gcspy_driverStream(carDriver, CAR_USED_SPACE_STREAM, carNum);
  for (i = 0; i < carNum; ++i) {
    car = trainGetCar(driver, i);
    gcspy_driverStreamIntValue(carDriver, car->usedSpace);
  }
  gcspy_driverStreamEnd(carDriver);

  gcspy_driverSummary(carDriver, CAR_USED_SPACE_STREAM, 2);
  gcspy_driverSummaryValue(carDriver, driver->totalCarUsedSpace[0]);
  gcspy_driverSummaryValue(carDriver, driver->totalCarUsedSpace[1]);
  gcspy_driverSummaryEnd(carDriver);


  gcspy_driverStream(carDriver, CAR_RS_LEN_STREAM, carNum);
  for (i = 0; i < carNum; ++i) {
    car = trainGetCar(driver, i);
    gcspy_driverStreamIntValue(carDriver, car->rsLen);
  }
  gcspy_driverStreamEnd(carDriver);

  gcspy_driverSummary(carDriver, CAR_RS_LEN_STREAM, 1);
  gcspy_driverSummaryValue(carDriver, driver->totalCarRSLen);
  gcspy_driverSummaryEnd(carDriver);


  gcspy_driverStream(carDriver, CAR_RS_SIZE_STREAM, carNum);
  for (i = 0; i < carNum; ++i) {
    car = trainGetCar(driver, i);
    gcspy_driverStreamIntValue(carDriver, car->rsSize);
  }
  gcspy_driverStreamEnd(carDriver);

  gcspy_driverSummary(carDriver, CAR_RS_SIZE_STREAM, 1);
  gcspy_driverSummaryValue(carDriver, driver->totalCarRSSize);
  gcspy_driverSummaryEnd(carDriver);


  gcspy_driverStream(carDriver, CAR_RS_COARSENESS_STREAM, carNum);
  for (i = 0; i < carNum; ++i) {
    car = trainGetCar(driver, i);
    gcspy_driverStreamByteValue(carDriver, (char) car->rsCoarseness);
  }
  gcspy_driverStreamEnd(carDriver);


  gcspy_driverStream(carDriver, CAR_RS_CAPACITY_STREAM, carNum);
  for (i = 0; i < carNum; ++i) {
    car = trainGetCar(driver, i);
    gcspy_driverStreamIntValue(carDriver, car->rsCapacity);
  }
  gcspy_driverStreamEnd(carDriver);

  gcspy_driverSummary(carDriver, CAR_RS_CAPACITY_STREAM, 1);
  gcspy_driverSummaryValue(carDriver, driver->totalCarRSCapacity);
  gcspy_driverSummaryEnd(carDriver);


  gcspy_driverStream(carDriver, CAR_HIGHER_REFS_STREAM, carNum);
  for (i = 0; i < carNum; ++i) {
    car = trainGetCar(driver, i);
    gcspy_driverStreamByteValue(carDriver, (char) car->higherRefs);
  }
  gcspy_driverStreamEnd(carDriver);

  gcspy_driverSummary(carDriver, CAR_HIGHER_REFS_STREAM, 2);
  gcspy_driverSummaryValue(carDriver, driver->totalCarHigherRefs[0]);
  gcspy_driverSummaryValue(carDriver, driver->totalCarHigherRefs[1]);
  gcspy_driverSummaryEnd(carDriver);


  gcspy_driverStream(carDriver, CAR_TYPE_STREAM, carNum);
  for (i = 0; i < carNum; ++i) {
    car = trainGetCar(driver, i);
    gcspy_driverStreamByteValue(carDriver, (char) car->type);
  }
  gcspy_driverStreamEnd(carDriver);

  gcspy_driverSummary(carDriver, CAR_TYPE_STREAM, 3);
  for (i = 0; i < 3; ++i)
    gcspy_driverSummaryValue(carDriver, driver->totalCarType[i]);
  gcspy_driverSummaryEnd(carDriver);


  gcspy_driverStream(carDriver, CAR_TRAIN_ID_STREAM, carNum);
  for (i = 0; i < carNum; ++i) {
    car = trainGetCar(driver, i);
    gcspy_driverStreamIntValue(carDriver, car->trainID);
  }
  gcspy_driverStreamEnd(carDriver);


  gcspy_driverStream(carDriver, CAR_CAR_ID_STREAM, carNum);
  for (i = 0; i < carNum; ++i) {
    car = trainGetCar(driver, i);
    gcspy_driverStreamIntValue(carDriver, car->carID);
  }
  gcspy_driverStreamEnd(carDriver);


  gcspy_driverStream(carDriver, CAR_SIZE_STREAM, carNum);
  for (i = 0; i < carNum; ++i) {
    car = trainGetCar(driver, i);
    gcspy_driverStreamIntValue(carDriver, car->size);
  }
  gcspy_driverStreamEnd(carDriver);

  gcspy_driverSummary(carDriver, CAR_SIZE_STREAM, 1);
  gcspy_driverSummaryValue(carDriver, driver->totalCarSize);
  gcspy_driverSummaryEnd(carDriver);


  gcspy_driverStream(carDriver, CAR_OBJECTS_STREAM, carNum);
  for (i = 0; i < carNum; ++i) {
    car = trainGetCar(driver, i);
    gcspy_driverStreamIntValue(carDriver, car->objects);
  }
  gcspy_driverStreamEnd(carDriver);

  gcspy_driverSummary(carDriver, CAR_OBJECTS_STREAM, 1);
  gcspy_driverSummaryValue(carDriver, driver->totalCarObjects);
  gcspy_driverSummaryEnd(carDriver);


  gcspy_driverStream(carDriver, CAR_IN_CS_STREAM, carNum);
  for (i = 0; i < carNum; ++i) {
    car = trainGetCar(driver, i);
    gcspy_driverStreamByteValue(carDriver, (char) car->inCS);
  }
  gcspy_driverStreamEnd(carDriver);

  gcspy_driverSummary(carDriver, CAR_IN_CS_STREAM, 2);
  gcspy_driverSummaryValue(carDriver, driver->totalCarInCS[0]);
  gcspy_driverSummaryValue(carDriver, driver->totalCarInCS[1]);
  gcspy_driverSummaryEnd(carDriver);


  gcspy_driverStream(carDriver, CAR_CS_SIZE_STREAM, carNum);
  for (i = 0; i < carNum; ++i) {
    car = trainGetCar(driver, i);
    gcspy_driverStreamIntValue(carDriver, car->csSize);
  }
  gcspy_driverStreamEnd(carDriver);

  gcspy_driverSummary(carDriver, CAR_CS_SIZE_STREAM, 2);
  gcspy_driverSummaryValue(carDriver, driver->totalCarCSSize[0]);
  gcspy_driverSummaryValue(carDriver, driver->totalCarCSSize[1]);
  gcspy_driverSummaryEnd(carDriver);


  gcspy_driverStream(carDriver, CAR_DIRECT_ALLOC_STREAM, carNum);
  for (i = 0; i < carNum; ++i) {
    car = trainGetCar(driver, i);
    gcspy_driverStreamIntValue(carDriver, car->directAlloc);
  }
  gcspy_driverStreamEnd(carDriver);

  gcspy_driverSummary(carDriver, CAR_DIRECT_ALLOC_STREAM, 2);
  gcspy_driverSummaryValue(carDriver, driver->totalCarDirectAlloc[0]);
  gcspy_driverSummaryValue(carDriver, driver->totalCarDirectAlloc[1]);
  gcspy_driverSummaryEnd(carDriver);


  gcspy_driverStream(carDriver, CAR_PROM_STREAM, carNum);
  for (i = 0; i < carNum; ++i) {
    car = trainGetCar(driver, i);
    gcspy_driverStreamIntValue(carDriver, car->prom);
  }
  gcspy_driverStreamEnd(carDriver);

  gcspy_driverSummary(carDriver, CAR_PROM_STREAM, 2);
  gcspy_driverSummaryValue(carDriver, driver->totalCarProm[0]);
  gcspy_driverSummaryValue(carDriver, driver->totalCarProm[1]);
  gcspy_driverSummaryEnd(carDriver);


  gcspy_driverStream(carDriver, CAR_EVAC_STREAM, carNum);
  for (i = 0; i < carNum; ++i) {
    car = trainGetCar(driver, i);
    gcspy_driverStreamIntValue(carDriver, car->evac);
  }
  gcspy_driverStreamEnd(carDriver);

  gcspy_driverSummary(carDriver, CAR_EVAC_STREAM, 2);
  gcspy_driverSummaryValue(carDriver, driver->totalCarEvac[0]);
  gcspy_driverSummaryValue(carDriver, driver->totalCarEvac[1]);
  gcspy_driverSummaryEnd(carDriver);


  gcspy_driverStream(carDriver, CAR_WEAK_EVAC_STREAM, carNum);
  for (i = 0; i < carNum; ++i) {
    car = trainGetCar(driver, i);
    gcspy_driverStreamIntValue(carDriver, car->weakEvac);
  }
  gcspy_driverStreamEnd(carDriver);

  gcspy_driverSummary(carDriver, CAR_WEAK_EVAC_STREAM, 2);
  gcspy_driverSummaryValue(carDriver, driver->totalCarWeakEvac[0]);
  gcspy_driverSummaryValue(carDriver, driver->totalCarWeakEvac[1]);
  gcspy_driverSummaryEnd(carDriver);


  /* I setup the control stream in the Zero call */
  /* gcspy_driverControl(carDriver); */
  gcspy_driverControlEnd(carDriver);


  sprintf(tmp, "Cars: %d\n", carNum);
  gcspy_driverSpaceInfo(carDriver, tmp);


  gcspy_driverEndComm(carDriver);


  /***** TRAINS *****/

  gcspy_driverStartComm(trainDriver);


  gcspy_driverStream(trainDriver, TRAIN_USED_SPACE_STREAM, trainNum);
  for (i = 0; i < trainNum; ++i) {
    train = trainGetTrain(driver, i);
    gcspy_driverStreamIntValue(trainDriver, train->usedSpace);
  }
  gcspy_driverStreamEnd(trainDriver);

  gcspy_driverSummary(trainDriver, TRAIN_USED_SPACE_STREAM, 2);
  gcspy_driverSummaryValue(trainDriver, driver->totalTrainUsedSpace[0]);
  gcspy_driverSummaryValue(trainDriver, driver->totalTrainUsedSpace[1]);
  gcspy_driverSummaryEnd(trainDriver);


  gcspy_driverStream(trainDriver, TRAIN_RS_LEN_STREAM, trainNum);
  for (i = 0; i < trainNum; ++i) {
    train = trainGetTrain(driver, i);
    gcspy_driverStreamIntValue(trainDriver, train->rsLen);
  }
  gcspy_driverStreamEnd(trainDriver);

  gcspy_driverSummary(trainDriver, TRAIN_RS_LEN_STREAM, 1);
  gcspy_driverSummaryValue(trainDriver, driver->totalTrainRSLen);
  gcspy_driverSummaryEnd(trainDriver);


  gcspy_driverStream(trainDriver, TRAIN_HIGHER_REFS_STREAM, trainNum);
  for (i = 0; i < trainNum; ++i) {
    train = trainGetTrain(driver, i);
    gcspy_driverStreamByteValue(trainDriver, (char) train->higherRefs);
  }
  gcspy_driverStreamEnd(trainDriver);

  gcspy_driverSummary(trainDriver, TRAIN_HIGHER_REFS_STREAM, 2);
  gcspy_driverSummaryValue(trainDriver, driver->totalTrainHigherRefs[0]);
  gcspy_driverSummaryValue(trainDriver, driver->totalTrainHigherRefs[1]);
  gcspy_driverSummaryEnd(trainDriver);


  gcspy_driverStream(trainDriver, TRAIN_TRAIN_ID_STREAM, trainNum);
  for (i = 0; i < trainNum; ++i) {
    train = trainGetTrain(driver, i);
    gcspy_driverStreamIntValue(trainDriver, train->trainID);
  }
  gcspy_driverStreamEnd(trainDriver);


  gcspy_driverStream(trainDriver, TRAIN_SIZE_STREAM, trainNum);
  for (i = 0; i < trainNum; ++i) {
    train = trainGetTrain(driver, i);
    gcspy_driverStreamIntValue(trainDriver, train->size);
  }
  gcspy_driverStreamEnd(trainDriver);

  gcspy_driverSummary(trainDriver, TRAIN_SIZE_STREAM, 1);
  gcspy_driverSummaryValue(trainDriver, driver->totalTrainSize);
  gcspy_driverSummaryEnd(trainDriver);


  gcspy_driverStream(trainDriver, TRAIN_LENGTH_STREAM, trainNum);
  for (i = 0; i < trainNum; ++i) {
    train = trainGetTrain(driver, i);
    gcspy_driverStreamIntValue(trainDriver, train->length);
  }
  gcspy_driverStreamEnd(trainDriver);

  gcspy_driverSummary(trainDriver, TRAIN_LENGTH_STREAM, 1);
  gcspy_driverSummaryValue(trainDriver, driver->totalTrainLength);
  gcspy_driverSummaryEnd(trainDriver);


  gcspy_driverStream(trainDriver, TRAIN_OBJECTS_STREAM, trainNum);
  for (i = 0; i < trainNum; ++i) {
    train = trainGetTrain(driver, i);
    gcspy_driverStreamIntValue(trainDriver, train->objects);
  }
  gcspy_driverStreamEnd(trainDriver);

  gcspy_driverSummary(trainDriver, TRAIN_OBJECTS_STREAM, 1);
  gcspy_driverSummaryValue(trainDriver, driver->totalTrainObjects);
  gcspy_driverSummaryEnd(trainDriver);


  gcspy_driverStream(trainDriver, TRAIN_POPULAR_OBJECTS_STREAM, trainNum);
  for (i = 0; i < trainNum; ++i) {
    train = trainGetTrain(driver, i);
    gcspy_driverStreamIntValue(trainDriver, train->popularObjects);
  }
  gcspy_driverStreamEnd(trainDriver);

  gcspy_driverSummary(trainDriver, TRAIN_POPULAR_OBJECTS_STREAM, 1);
  gcspy_driverSummaryValue(trainDriver, driver->totalTrainPopularObjects);
  gcspy_driverSummaryEnd(trainDriver);


  gcspy_driverStream(trainDriver, TRAIN_CARS_IN_CS_STREAM, trainNum);
  for (i = 0; i < trainNum; ++i) {
    train = trainGetTrain(driver, i);
    gcspy_driverStreamIntValue(trainDriver, train->carsInCS);
  }
  gcspy_driverStreamEnd(trainDriver);

  gcspy_driverSummary(trainDriver, TRAIN_CARS_IN_CS_STREAM, 1);
  gcspy_driverSummaryValue(trainDriver, driver->totalTrainCarsInCS);
  gcspy_driverSummaryEnd(trainDriver);


  gcspy_driverStream(trainDriver, TRAIN_CS_SIZE_STREAM, trainNum);
  for (i = 0; i < trainNum; ++i) {
    train = trainGetTrain(driver, i);
    gcspy_driverStreamIntValue(trainDriver, train->csSize);
  }
  gcspy_driverStreamEnd(trainDriver);

  gcspy_driverSummary(trainDriver, TRAIN_CS_SIZE_STREAM, 2);
  gcspy_driverSummaryValue(trainDriver, driver->totalTrainCSSize[0]);
  gcspy_driverSummaryValue(trainDriver, driver->totalTrainCSSize[1]);
  gcspy_driverSummaryEnd(trainDriver);


  gcspy_driverStream(trainDriver, TRAIN_DIRECT_ALLOC_STREAM, trainNum);
  for (i = 0; i < trainNum; ++i) {
    train = trainGetTrain(driver, i);
    gcspy_driverStreamIntValue(trainDriver, train->directAlloc);
  }
  gcspy_driverStreamEnd(trainDriver);

  gcspy_driverSummary(trainDriver, TRAIN_DIRECT_ALLOC_STREAM, 2);
  gcspy_driverSummaryValue(trainDriver, driver->totalTrainDirectAlloc[0]);
  gcspy_driverSummaryValue(trainDriver, driver->totalTrainDirectAlloc[1]);
  gcspy_driverSummaryEnd(trainDriver);


  gcspy_driverStream(trainDriver, TRAIN_PROM_STREAM, trainNum);
  for (i = 0; i < trainNum; ++i) {
    train = trainGetTrain(driver, i);
    gcspy_driverStreamIntValue(trainDriver, train->prom);
  }
  gcspy_driverStreamEnd(trainDriver);

  gcspy_driverSummary(trainDriver, TRAIN_PROM_STREAM, 2);
  gcspy_driverSummaryValue(trainDriver, driver->totalTrainProm[0]);
  gcspy_driverSummaryValue(trainDriver, driver->totalTrainProm[1]);
  gcspy_driverSummaryEnd(trainDriver);


  gcspy_driverStream(trainDriver, TRAIN_EVAC_STREAM, trainNum);
  for (i = 0; i < trainNum; ++i) {
    train = trainGetTrain(driver, i);
    gcspy_driverStreamIntValue(trainDriver, train->evac);
  }
  gcspy_driverStreamEnd(trainDriver);

  gcspy_driverSummary(trainDriver, TRAIN_EVAC_STREAM, 2);
  gcspy_driverSummaryValue(trainDriver, driver->totalTrainEvac[0]);
  gcspy_driverSummaryValue(trainDriver, driver->totalTrainEvac[1]);
  gcspy_driverSummaryEnd(trainDriver);


  gcspy_driverStream(trainDriver, TRAIN_WEAK_EVAC_STREAM, trainNum);
  for (i = 0; i < trainNum; ++i) {
    train = trainGetTrain(driver, i);
    gcspy_driverStreamIntValue(trainDriver, train->weakEvac);
  }
  gcspy_driverStreamEnd(trainDriver);

  gcspy_driverSummary(trainDriver, TRAIN_WEAK_EVAC_STREAM, 2);
  gcspy_driverSummaryValue(trainDriver, driver->totalTrainWeakEvac[0]);
  gcspy_driverSummaryValue(trainDriver, driver->totalTrainWeakEvac[1]);
  gcspy_driverSummaryEnd(trainDriver);


  sprintf(tmp, "Trains: %d\n", trainNum);
  gcspy_driverSpaceInfo(trainDriver, tmp);


  gcspy_driverEndComm(trainDriver);
}

void
trainInit (train_driver_t *driver,
	   gcspy_gc_driver_t *regionDriver,
	   gcspy_gc_driver_t *carDriver,
	   gcspy_gc_driver_t *trainDriver,
	   const char *name,
	   unsigned regionSize,
	   char *start,
	   char *end,
	   unsigned carNum,
	   unsigned trainNum) {
  int i;
  char tmp[256];
  gcspy_gc_stream_t *stream;
  int regionNum = gcspy_dUtilsTileNum(start, end, regionSize);
  train_region_t *regions = trainAllocateRegions(regionNum);
  train_car_t    *cars    = trainAllocateCars(carNum);
  train_train_t  *trains  = trainAllocateTrains(trainNum);

  /***** REGIONS *****/

  driver->regionDriver = regionDriver;
  gcspy_dUtilsInit(&(driver->regionArea),
		   start, end,
		   0, regionSize, regionNum,
		   (char *) regions, sizeof(train_region_t));

  sprintf(tmp, "Region Size: %dK\n", (regionSize / 1024));
  gcspy_driverInit(regionDriver, -1, name, "Regions",
		   "Region ", tmp, regionNum, "NOT ALLOCATED", 1);
  trainSetupRegionNames(driver, 0, regionNum);

  stream = gcspy_driverAddStream(regionDriver, REGION_USED_SPACE_STREAM);
  gcspy_streamInit(stream, REGION_USED_SPACE_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Used Space",
		   0, regionSize,
		   0, 0,
		   "Used Space: ", " bytes",
		   GCSPY_GC_STREAM_PRESENTATION_PERCENT,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Red"));

  stream = gcspy_driverAddStream(regionDriver, REGION_CARDS_STREAM);
  gcspy_streamInit(stream, REGION_CARDS_STREAM,
		   GCSPY_GC_STREAM_BYTE_TYPE,
		   "Card Table",
		   0, 3,
		   3, 3, 
		   "Card State: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_ENUM,
		   GCSPY_GC_STREAM_PAINT_STYLE_PLAIN, 0,
		   gcspy_colorDBGetColorWithName("Off White"));
  gcspy_streamAddEnumName(stream, REGION_CARD_STATE_DIRTY, "DIRTY");
  gcspy_streamAddEnumName(stream, REGION_CARD_STATE_OVERFLOWN, "OVERFLOWN");
  gcspy_streamAddEnumName(stream, REGION_CARD_STATE_SUMMARISED, "SUMMARISED");
  gcspy_streamAddEnumName(stream, REGION_CARD_STATE_CLEAN, "CLEAN");

  stream = gcspy_driverAddStream(regionDriver, REGION_TYPE_STREAM);
  gcspy_streamInit(stream, REGION_TYPE_STREAM,
		   GCSPY_GC_STREAM_BYTE_TYPE,
		   "Region Type",
		   0, 2,
		   2, 2, 
		   "Region Type: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_ENUM,
		   GCSPY_GC_STREAM_PAINT_STYLE_PLAIN, 0,
		   gcspy_colorDBGetColorWithName("Orange"));
  gcspy_streamAddEnumName(stream, REGION_TYPE_POPULAR, "POPULAR");
  gcspy_streamAddEnumName(stream, REGION_TYPE_OVERSIZED, "OVERSIZED");
  gcspy_streamAddEnumName(stream, REGION_TYPE_STANDARD, "STANDARD");

  stream = gcspy_driverAddStream(regionDriver, REGION_TRAIN_ID_STREAM);
  gcspy_streamInit(stream, REGION_TRAIN_ID_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Train ID",
		   -1, 0,
		   -1, -1, 
		   "Train ID: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_MAX_VAR,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Blue"));

  stream = gcspy_driverAddStream(regionDriver, REGION_CAR_ID_STREAM);
  gcspy_streamInit(stream, REGION_CAR_ID_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Car ID",
		   -1, 0,
		   -1, -1, 
		   "Car ID: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_MAX_VAR,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Blue"));

  stream = gcspy_driverAddStream(regionDriver, REGION_DIRECT_ALLOC_STREAM);
  gcspy_streamInit(stream, REGION_DIRECT_ALLOC_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Direct Allocation",
		   0, regionSize,
		   0, 0,
		   "Direct Allocation: ", " bytes",
		   GCSPY_GC_STREAM_PRESENTATION_PERCENT,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Magenta"));

  stream = gcspy_driverAddStream(regionDriver, REGION_PROM_STREAM);
  gcspy_streamInit(stream, REGION_PROM_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Promotion",
		   0, regionSize,
		   0, 0,
		   "Promotion: ", " bytes",
		   GCSPY_GC_STREAM_PRESENTATION_PERCENT,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Magenta"));

  stream = gcspy_driverAddStream(regionDriver, REGION_EVAC_STREAM);
  gcspy_streamInit(stream, REGION_EVAC_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Evacuation",
		   0, regionSize,
		   0, 0,
		   "Evacuation: ", " bytes",
		   GCSPY_GC_STREAM_PRESENTATION_PERCENT,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Magenta"));

  stream = gcspy_driverAddStream(regionDriver, REGION_WEAK_EVAC_STREAM);
  gcspy_streamInit(stream, REGION_WEAK_EVAC_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Weak Evacuation",
		   0, regionSize,
		   0, 0,
		   "Weak Evacuation: ", " bytes",
		   GCSPY_GC_STREAM_PRESENTATION_PERCENT,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Magenta"));

  /***** CARS *****/

  driver->carDriver = carDriver;
  driver->cars = cars;
  driver->carNum = carNum;

  gcspy_driverInit(carDriver, -1, name, "Cars",
		   "Car ", "", carNum, NULL, 0);
  trainSetupCarNames(driver, 0, carNum);

  stream = gcspy_driverAddStream(carDriver, CAR_USED_SPACE_STREAM);
  gcspy_streamInit(stream, CAR_USED_SPACE_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Used Space",
		   0, 0,
		   0, 0,
		   "Used Space: ", " bytes",
		   GCSPY_GC_STREAM_PRESENTATION_PERCENT_VAR,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO,
		   CAR_SIZE_STREAM,
		   gcspy_colorDBGetColorWithName("Red"));

  stream = gcspy_driverAddStream(carDriver, CAR_RS_LEN_STREAM);
  gcspy_streamInit(stream, CAR_RS_LEN_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "RSet Length",
		   0, CAR_RS_LEN_MAX,
		   0, 0,
		   "RSet Length: ", " entries",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Off White"));

  stream = gcspy_driverAddStream(carDriver, CAR_RS_SIZE_STREAM);
  gcspy_streamInit(stream, CAR_RS_SIZE_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "RSet Size",
		   0, CAR_RS_SIZE_MAX,
		   0, 0,
		   "RSet Size: ", " entries",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Off White"));

  stream = gcspy_driverAddStream(carDriver, CAR_RS_COARSENESS_STREAM);
  gcspy_streamInit(stream, CAR_RS_COARSENESS_STREAM,
		   GCSPY_GC_STREAM_BYTE_TYPE,
		   "RSet Coarseness",
		   CAR_RS_COARSENESS_MIN, CAR_RS_COARSENESS_MAX,
		   CAR_RS_COARSENESS_MIN, CAR_RS_COARSENESS_MIN,
		   "RSet Coarseness: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Off White"));

  stream = gcspy_driverAddStream(carDriver, CAR_RS_CAPACITY_STREAM);
  gcspy_streamInit(stream, CAR_RS_CAPACITY_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "RSet Capacity",
		   0, CAR_RS_CAPACITY_MAX,
		   0, 0,
		   "RSet Capacity: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Off White"));

  stream = gcspy_driverAddStream(carDriver, CAR_HIGHER_REFS_STREAM);
  gcspy_streamInit(stream, CAR_HIGHER_REFS_STREAM,
		   GCSPY_GC_STREAM_BYTE_TYPE,
		   "Higher Refs",
		   0, 1,
		   0, 0,
		   "Higher Refs: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_ENUM,
		   GCSPY_GC_STREAM_PAINT_STYLE_PLAIN, 0,
		   gcspy_colorDBGetColorWithName("White"));
  gcspy_streamAddEnumName(stream, CAR_HIGHER_REFS_NO, "NO");
  gcspy_streamAddEnumName(stream, CAR_HIGHER_REFS_YES, "YES");

  stream = gcspy_driverAddStream(carDriver, CAR_TYPE_STREAM);
  gcspy_streamInit(stream, CAR_TYPE_STREAM,
		   GCSPY_GC_STREAM_BYTE_TYPE,
		   "Car Type",
		   0, 2,
		   2, 2, 
		   "Car Type: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_ENUM,
		   GCSPY_GC_STREAM_PAINT_STYLE_PLAIN, 0,
		   gcspy_colorDBGetColorWithName("Orange"));
  gcspy_streamAddEnumName(stream, CAR_TYPE_POPULAR, "POPULAR");
  gcspy_streamAddEnumName(stream, CAR_TYPE_OVERSIZED, "OVERSIZED");
  gcspy_streamAddEnumName(stream, CAR_TYPE_STANDARD, "STANDARD");

  stream = gcspy_driverAddStream(carDriver, CAR_TRAIN_ID_STREAM);
  gcspy_streamInit(stream, CAR_TRAIN_ID_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Train ID",
		   -1, 0,
		   -1, -1, 
		   "Train ID: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_MAX_VAR,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Blue"));

  stream = gcspy_driverAddStream(carDriver, CAR_CAR_ID_STREAM);
  gcspy_streamInit(stream, CAR_CAR_ID_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Car ID",
		   -1, 0,
		   -1, -1, 
		   "Car ID: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_MAX_VAR,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Blue"));

  stream = gcspy_driverAddStream(carDriver, CAR_SIZE_STREAM);
  gcspy_streamInit(stream, CAR_SIZE_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Size",
		   0, 0,
		   0, 0,
		   "Size: ", " bytes",
		   GCSPY_GC_STREAM_PRESENTATION_MAX_VAR,
		   GCSPY_GC_STREAM_PAINT_STYLE_PLAIN, 0,
		   gcspy_colorDBGetColorWithName("Pink"));

  stream = gcspy_driverAddStream(carDriver, CAR_OBJECTS_STREAM);
  gcspy_streamInit(stream, CAR_OBJECTS_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Objects",
		   0, gcspy_d_utils_objects_per_block(regionSize), 
		   0, 0,
		   "Objects: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Yellow"));

  stream = gcspy_driverAddStream(carDriver, CAR_IN_CS_STREAM);
  gcspy_streamInit(stream, CAR_IN_CS_STREAM,
		   GCSPY_GC_STREAM_BYTE_TYPE,
		   "In CSet",
		   0, 1,
		   0, 0,
		   "In CSet: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_ENUM,
		   GCSPY_GC_STREAM_PAINT_STYLE_PLAIN, 0,
		   gcspy_colorDBGetColorWithName("White"));
  gcspy_streamAddEnumName(stream, CAR_IN_CS_NO, "NO");
  gcspy_streamAddEnumName(stream, CAR_IN_CS_YES, "YES");

  stream = gcspy_driverAddStream(carDriver, CAR_CS_SIZE_STREAM);
  gcspy_streamInit(stream, CAR_CS_SIZE_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "CSet Size",
		   0, 0,
		   0, 0,
		   "CSet Size: ", " bytes",
		   GCSPY_GC_STREAM_PRESENTATION_PERCENT_VAR,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO,
		   CAR_SIZE_STREAM,
		   gcspy_colorDBGetColorWithName("Red"));

  stream = gcspy_driverAddStream(carDriver, CAR_DIRECT_ALLOC_STREAM);
  gcspy_streamInit(stream, CAR_DIRECT_ALLOC_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Direct Allocation",
		   0, 0,
		   0, 0,
		   "Direct Allocation: ", " bytes",
		   GCSPY_GC_STREAM_PRESENTATION_PERCENT_VAR,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 
		   CAR_SIZE_STREAM,
		   gcspy_colorDBGetColorWithName("Magenta"));

  stream = gcspy_driverAddStream(carDriver, CAR_PROM_STREAM);
  gcspy_streamInit(stream, CAR_PROM_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Promotion",
		   0, 0,
		   0, 0,
		   "Promotion: ", " bytes",
		   GCSPY_GC_STREAM_PRESENTATION_PERCENT_VAR,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO,
		   CAR_SIZE_STREAM,
		   gcspy_colorDBGetColorWithName("Magenta"));

  stream = gcspy_driverAddStream(carDriver, CAR_EVAC_STREAM);
  gcspy_streamInit(stream, CAR_EVAC_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Evacuation",
		   0, 0,
		   0, 0,
		   "Evacuation: ", " bytes",
		   GCSPY_GC_STREAM_PRESENTATION_PERCENT_VAR,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO,
		   CAR_SIZE_STREAM,
		   gcspy_colorDBGetColorWithName("Magenta"));

  stream = gcspy_driverAddStream(carDriver, CAR_WEAK_EVAC_STREAM);
  gcspy_streamInit(stream, CAR_WEAK_EVAC_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Weak Evacuation",
		   0, 0,
		   0, 0,
		   "Weak Evacuation: ", " bytes",
		   GCSPY_GC_STREAM_PRESENTATION_PERCENT_VAR,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO,
		   CAR_SIZE_STREAM,
		   gcspy_colorDBGetColorWithName("Magenta"));

  /***** TRAINS *****/

  driver->trainDriver = trainDriver;
  driver->trains = trains;
  driver->trainNum = trainNum;

  gcspy_driverInit(trainDriver, -1, name, "Trains",
		   "Train ", "", trainNum, NULL, 0);
  trainSetupTrainNames(driver, 0, trainNum);

  stream = gcspy_driverAddStream(trainDriver, TRAIN_USED_SPACE_STREAM);
  gcspy_streamInit(stream, TRAIN_USED_SPACE_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Used Space",
		   0, 0,
		   0, 0,
		   "Used Space: ", " bytes",
		   GCSPY_GC_STREAM_PRESENTATION_PERCENT_VAR,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO,
		   TRAIN_SIZE_STREAM,
		   gcspy_colorDBGetColorWithName("Red"));

  stream = gcspy_driverAddStream(trainDriver, TRAIN_RS_LEN_STREAM);
  gcspy_streamInit(stream, TRAIN_RS_LEN_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "RSet Length",
		   0, TRAIN_RS_LEN_MAX,
		   0, 0,
		   "RSet Length: ", " entries",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Off White"));

  stream = gcspy_driverAddStream(trainDriver, TRAIN_HIGHER_REFS_STREAM);
  gcspy_streamInit(stream, TRAIN_HIGHER_REFS_STREAM,
		   GCSPY_GC_STREAM_BYTE_TYPE,
		   "Higher Refs",
		   0, 1,
		   0, 0,
		   "Higher Refs: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_ENUM,
		   GCSPY_GC_STREAM_PAINT_STYLE_PLAIN, 0,
		   gcspy_colorDBGetColorWithName("White"));
  gcspy_streamAddEnumName(stream, TRAIN_HIGHER_REFS_NO, "NO");
  gcspy_streamAddEnumName(stream, TRAIN_HIGHER_REFS_YES, "YES");

  stream = gcspy_driverAddStream(trainDriver, TRAIN_TRAIN_ID_STREAM);
  gcspy_streamInit(stream, TRAIN_TRAIN_ID_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Train ID",
		   -1, 0,
		   -1, -1, 
		   "Train ID: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_MAX_VAR,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Blue"));

  stream = gcspy_driverAddStream(trainDriver, TRAIN_LENGTH_STREAM);
  gcspy_streamInit(stream, TRAIN_LENGTH_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Length",
		   0, TRAIN_LENGTH_MAX,
		   0, 0,
		   "Length: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Green"));

  stream = gcspy_driverAddStream(trainDriver, TRAIN_SIZE_STREAM);
  gcspy_streamInit(stream, TRAIN_SIZE_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Size",
		   0, 0,
		   0, 0,
		   "Size: ", " bytes",
		   GCSPY_GC_STREAM_PRESENTATION_MAX_VAR,
		   GCSPY_GC_STREAM_PAINT_STYLE_PLAIN, 0,
		   gcspy_colorDBGetColorWithName("Pink"));

  stream = gcspy_driverAddStream(trainDriver, TRAIN_OBJECTS_STREAM);
  gcspy_streamInit(stream, TRAIN_OBJECTS_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Objects",
		   0, 10 * gcspy_d_utils_objects_per_block(regionSize),
		   0, 0,
		   "Objects: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Yellow"));

  stream = gcspy_driverAddStream(trainDriver, TRAIN_POPULAR_OBJECTS_STREAM);
  gcspy_streamInit(stream, TRAIN_POPULAR_OBJECTS_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Popular Objects",
		   0, TRAIN_MAX_POPULAR_OBJECTS,
		   0, 0,
		   "Popular Objects: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 0,
		   gcspy_colorDBGetColorWithName("Yellow"));

  stream = gcspy_driverAddStream(trainDriver, TRAIN_CARS_IN_CS_STREAM);
  gcspy_streamInit(stream, TRAIN_CARS_IN_CS_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Cars In CSet",
		   0, TRAIN_CARS_IN_CS_MAX,
		   0, 0,
		   "Cars In CSet: ", "",
		   GCSPY_GC_STREAM_PRESENTATION_PLUS,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 
		   TRAIN_SIZE_STREAM,
		   gcspy_colorDBGetColorWithName("Green"));

  stream = gcspy_driverAddStream(trainDriver, TRAIN_CS_SIZE_STREAM);
  gcspy_streamInit(stream, TRAIN_CS_SIZE_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "CSet Size",
		   0, 0,
		   0, 0,
		   "CSet Size: ", " bytes",
		   GCSPY_GC_STREAM_PRESENTATION_PERCENT_VAR,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO,
		   TRAIN_SIZE_STREAM,
		   gcspy_colorDBGetColorWithName("Red"));

  stream = gcspy_driverAddStream(trainDriver, TRAIN_DIRECT_ALLOC_STREAM);
  gcspy_streamInit(stream, TRAIN_DIRECT_ALLOC_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Direct Allocation",
		   0, 0,
		   0, 0,
		   "Direct Allocation: ", " bytes",
		   GCSPY_GC_STREAM_PRESENTATION_PERCENT_VAR,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO, 
		   TRAIN_SIZE_STREAM,
		   gcspy_colorDBGetColorWithName("Magenta"));

  stream = gcspy_driverAddStream(trainDriver, TRAIN_PROM_STREAM);
  gcspy_streamInit(stream, TRAIN_PROM_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Promotion",
		   0, 0,
		   0, 0,
		   "Promotion: ", " bytes",
		   GCSPY_GC_STREAM_PRESENTATION_PERCENT_VAR,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO,
		   TRAIN_SIZE_STREAM,
		   gcspy_colorDBGetColorWithName("Magenta"));

  stream = gcspy_driverAddStream(trainDriver, TRAIN_EVAC_STREAM);
  gcspy_streamInit(stream, TRAIN_EVAC_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Evacuation",
		   0, 0,
		   0, 0,
		   "Evacuation: ", " bytes",
		   GCSPY_GC_STREAM_PRESENTATION_PERCENT_VAR,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO,
		   TRAIN_SIZE_STREAM,
		   gcspy_colorDBGetColorWithName("Magenta"));

  stream = gcspy_driverAddStream(trainDriver, TRAIN_WEAK_EVAC_STREAM);
  gcspy_streamInit(stream, TRAIN_WEAK_EVAC_STREAM,
		   GCSPY_GC_STREAM_INT_TYPE,
		   "Weak Evacuation",
		   0, 0,
		   0, 0,
		   "Weak Evacuation: ", " bytes",
		   GCSPY_GC_STREAM_PRESENTATION_PERCENT_VAR,
		   GCSPY_GC_STREAM_PAINT_STYLE_ZERO,
		   TRAIN_SIZE_STREAM,
		   gcspy_colorDBGetColorWithName("Magenta"));
}
