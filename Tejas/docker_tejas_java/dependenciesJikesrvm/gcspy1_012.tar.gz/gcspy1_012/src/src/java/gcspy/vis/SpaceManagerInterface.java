/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/


package gcspy.vis;

import gcspy.vis.plugins.PluginListener;

import java.util.List;

/**
 * Interface through which the space manager communicates with the main frame
 * @author Tony Printezis
 * @author <a href="http://www/cs/kent.ac.uk">Richard Jones</a>
 */
interface SpaceManagerInterface {

    /** Clear all the views */
    public void clearViews ();
    
    /**
     * Add a view 
     * @param obj The object to add to the views combo box
     */
    public void addView (Object obj);
    
    /**
     * Set the active stream
     * @param streamID the ID of the stream
     */
    public void setActiveView (int streamID);
    
    /**
     * Set the block information
     * @param text The text for the block information
     */
    public void setBlockInfo(String text);

    /**
     * Add a magnification manager
     * @param small The tile manager for the row of small tiles
     * @param large The tile manager for the row of large tiles
     */
    public void addMagManagers (TileManager small, TileManager large);

    /**
     * Activate a space
     * @param spaceManager The space's manager
     */
    public void setActive (SpaceManager spaceManager);

    /** Validate the space manager's GUI */
    public void validateContainer ();

    /** 
     * Get the plugin's listeners for this space
     * @return a list of plugin listeners known to the space manager 
     */
    public List<PluginListener> getPluginListeners();
}
