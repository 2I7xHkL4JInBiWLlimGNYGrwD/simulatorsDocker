/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  hs_mc_driver.hpp
 **
 **  Abstract driver for the HS old and permanent generation collectors
 **/

#ifndef _HS_MC_DRIVER_HPP_

#define _HS_MC_DRIVER_HPP_

#include "gcspy_space.hpp"
#include "gcspy_cont_area.hpp"

class hsMCDriver : public gcspySpace {
private:
  enum PrivateConstants {
    card_state_dirty = 0,
    card_state_younger,
    card_state_clean
  };

  gcspy_size_t   _card_size;

  gcspyStream *_used_space_stream;
  int    *_used_space_data;
  int    *_used_space_summary;

  gcspyStream *_dead_space_stream;
  int    *_dead_space_data;
  int    *_dead_space_summary;

  gcspyStream *_card_table_stream;
  char   *_card_table_data;
  int    *_card_table_summary;

  gcspyStream *_object_stream;
  int    *_object_data;
  int    *_object_summary;

  gcspyStream *_marking_stream;
  int    *_marking_data;
  int    *_marking_summary;

  gcspyStream *_refs_stream;
  int    *_refs_data;
  int    *_refs_summary;

  gcspyStream *_refs_to_young_stream;
  int    *_refs_to_young_data;
  int    *_refs_to_young_summary;

  gcspyStream *_internal_refs_stream;
  int    *_internal_refs_data;
  int    *_internal_refs_summary;

  static char *generate_block_info (gcspy_size_t block_size);

protected:
  gcspyContArea *_area;

  virtual void retrieve_data_arrays (void);
  virtual void init_summaries (gcspy_size_t area_size);

  void add_used_space_stream (void);
  void add_dead_space_stream (void);
  void add_card_table_stream (void);
  void add_object_stream (void);
  void add_marking_stream (void);
  void add_refs_stream (void);
  void add_refs_to_young_stream (void);
  void add_internal_refs_stream (void);

  hsMCDriver (char *name,
	      gcspy_size_t block_size,
	      gcspy_size_t card_size,
	      char *start,
	      char *end);

public:
  void reset (char *end);

  inline void set_alloc_limit (char *limit) {
    _area->set_perc(_area->get_start(), limit, _used_space_data);
    _used_space_summary[0] +=
      (gcspy_size_t) limit - (gcspy_size_t) _area->get_start();
  }

  inline void add_dead_space (char *start, char *end) {
    _area->set_perc(start, end, _dead_space_data);
    _dead_space_summary[0] += (gcspy_size_t) end - (gcspy_size_t) start;
  }

  inline void set_card_state (char *start, int state) {
    _area->update_enum_desc(start, state, _card_table_data);
  }

  inline void add_object (char *start, gcspy_size_t size) {
    _area->add_one(start, start + size, _object_data);
    _object_summary[0] += 1;
  }

  inline void add_marked_object (char *start) {
    _area->add_one(start, _marking_data);
    _marking_summary[0] += 1;
  }

  inline void add_ref (char *addr) {
    _area->add_one(addr, _refs_data);
    _refs_summary[0] += 1;
  }

  inline void add_ref_to_young (char *addr) {
    _area->add_one(addr, _refs_to_young_data);
    _refs_to_young_summary[0] += 1;
  }

  inline void add_internal_ref (char *addr) {
    _area->add_one(addr, _internal_refs_data);
    _internal_refs_summary[0] += 1;
  }
};

#endif //_HS_MC_DRIVER_HPP_
