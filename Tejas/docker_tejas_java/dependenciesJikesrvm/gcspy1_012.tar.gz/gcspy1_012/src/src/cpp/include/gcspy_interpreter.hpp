/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  gcspy_interpreter.hpp
 **
 **  The interpreter communicating with the client
 **/

#ifndef _GCSPY_INTERPRETER_HPP_

#define _GCSPY_INTERPRETER_HPP_

#include "gcspy_comm.hpp"
#include "gcspy_command_stream.hpp"
#include "gcspy_space.hpp"
#include "gcspy_server_state.hpp"

class gcspyInterpreter : public gcspyCommandStream {

  friend void pause_req_cmd (gcspyBufferedInput *input, void *aux);
  friend void pause_cmd (gcspyBufferedInput *input, void *aux);
  friend void restart_cmd (gcspyBufferedInput *input, void *aux);
  friend void play_one_cmd (gcspyBufferedInput *input, void *aux);
  friend void shutdown_req_cmd (gcspyBufferedInput *input, void *aux);
  friend void shutdown_cmd (gcspyBufferedInput *input, void *aux);
  friend void stream_cmd (gcspyBufferedInput *input, void *aux);
  friend void event_cmd (gcspyBufferedInput *input, void *aux);
  friend void control_cmd (gcspyBufferedInput *input, void *aux);
  friend void filter_cmd (gcspyBufferedInput *input, void *aux);
  friend void event_count_cmd (gcspyBufferedInput *input, void *aux);
  friend void summary_cmd (gcspyBufferedInput *input, void *aux);
  friend void space_info_cmd (gcspyBufferedInput *input, void *aux);
  friend void space_cmd (gcspyBufferedInput *input, void *aux);

private:
  enum PrivateConstants {
    pause_req_tag = first_available_tag,
    pause_tag,
    restart_tag,
    play_one_tag,
    shutdown_req_tag,
    shutdown_tag,
    stream_tag,
    event_tag,
    control_tag,
    filter_tag,
    event_count_tag,
    summary_tag,
    space_info_tag,
    space_tag,

    cmd_len = space_tag + 1
  };

  gcspyClient *_client;

  void send_single_cmd (unsigned tag);
  inline void finish (gcspyBufferedOutput *output) {
    gcspyCommandStream::finish(output);
    output->close();
    output->send();
  }

public:
  gcspyInterpreter (gcspyClient *client);

  void send_pause_cmd ();
  void send_shutdown_cmd ();
  void send_stream_cmd (unsigned space_id, unsigned stream_id,
			unsigned data_type, char *data, gcspy_length_t len);
  void send_event_cmd (unsigned event,
		       int elapsed_time, int compensation_time);
  void send_control_cmd (unsigned space_id, char *data, gcspy_length_t len);
  void send_event_count_cmd (int *event_counts,
			     gcspy_length_t len);
  void send_summary_cmd (unsigned space_id, unsigned stream_id,
			 int *summary, gcspy_length_t len);
  void send_space_info_cmd (unsigned space_id, char *space_info);
  void send_space_cmd (gcspySpace *space);
};

#endif //_GCSPY_INTERPRETER_HPP_
