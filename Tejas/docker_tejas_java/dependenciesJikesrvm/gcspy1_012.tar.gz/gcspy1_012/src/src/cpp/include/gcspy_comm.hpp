/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  gcspy_comm.hpp
 **
 **  Abstractions over sockets
 **/

#ifndef _GCSPY_COMM_HPP_

#define _GCSPY_COMM_HPP_

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>

#include "gcspy_types.hpp"
#include "gcspy_utils.hpp"

// SERVER STUFF

class gcspyServer {

private:
  enum PrivateConstants {
    default_backlog = 5
  };

  int                  _fd;
  struct sockaddr_in   _addr;

public:
  gcspyServer (int port, int max_backlog = default_backlog);
  int accept (struct sockaddr *client_addr, unsigned int *addr_len);
  void close (void);

};

// CLIENT STUFF

class gcspyClient {

private:
  enum PrivateConstants {
    prefix_size = 4,
    default_max_len = gcspyUtils::megabyte
  };

  int                  _fd;
  struct sockaddr_in   _addr;
  gcspy_length_t       _max_len;

  char                *_in_buffer;
  gcspy_length_t       _len;

  char                *_tmp_buffer;
  gcspy_length_t       _tmp_len;

  char                *_out_buffer;

  gcspy_length_t read_stream_len (void);
  void write_stream_len (gcspy_length_t len);

public:
  gcspyClient ();

  inline char           *get_in_buffer()  { return _in_buffer; }
  inline char           *get_out_buffer() { return _out_buffer; }
  inline gcspy_length_t  get_len()        { return _len; }
  inline gcspy_length_t  get_max_len()    { return _max_len; }
  inline gcspy_bool_t    has_finished()   { return (_len == 0); }

  void wait_for_connection (gcspyServer *server,
			    gcspy_length_t max_len = default_max_len);
  void receive (void);
  gcspy_bool_t definitely_receive (void);
  void send (gcspy_length_t len);
  void close (void);

};

#endif //_GCSPY_COMM_HPP_
