/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  hs_perm_driver.hpp
 **
 **  Driver for the HS permanent generation M&C collector
 **/

#ifndef _HS_PERM_DRIVER_HPP_

#define _HS_PERM_DRIVER_HPP_

#include "hs_mc_driver.hpp"

class hsPermDriver : public hsMCDriver {
private:
  gcspyStream *_alloc_stream;
  int    *_alloc_data;
  int    *_alloc_summary;

  gcspyStream *_refs_to_old_stream;
  int    *_refs_to_old_data;
  int    *_refs_to_old_summary;

protected:
  virtual void retrieve_data_arrays (void);
  virtual void init_summaries (gcspy_size_t area_size);

public:
  hsPermDriver (gcspy_size_t block_size,
	       gcspy_size_t card_size,
	       char *start,
	       char *end);

  inline void set_alloc (char *start, char *end) {
    _area->set_perc(start, end, _alloc_data);
    _alloc_summary[0] += (gcspy_size_t) end - (gcspy_size_t) start;
  }

  inline void add_ref_to_old (char *addr) {
    _area->add_one(addr, _refs_to_old_data);
    _refs_to_old_summary[0] += 1;
  }
};

#endif //_HS_PERM_DRIVER_HPP_
