/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  gcspy_command_stream.hpp
 **
 **  Facilities for buffered commands
 **/

#ifndef _GCSPY_COMMAND_STREAM_HPP_

#define _GCSPY_COMMAND_STREAM_HPP_

#include "gcspy_types.hpp"
#include "gcspy_buffered_input.hpp"
#include "gcspy_buffered_output.hpp"

typedef void gcspy_command_t (gcspyBufferedInput *input, void *aux);
typedef char gcspy_command_tag_t;

class gcspyCommandStream {

private:
  enum PrivateConstants {
    magic_start_tag = 666666,
    magic_end_tag = -666,
    end_tag = 0
  };

  gcspy_length_t          _len;

  inline gcspy_command_tag_t get_tag (gcspyBufferedInput *input) {
    return input->read_byte();
  }

protected:
  enum ProtectedConstants {
    first_available_tag = end_tag + 1
  };

  gcspy_command_t    **_cmds;

  inline void put_tag (gcspyBufferedOutput *output,
		       gcspy_command_tag_t tag) {
    output->write_byte((char) tag);
  }

public:
  gcspyCommandStream (gcspy_command_t **cmds, gcspy_length_t len);
  gcspyCommandStream (gcspy_length_t len);

  inline void start (gcspyBufferedOutput *output) {
    output->write_int(magic_start_tag);
  }

  inline void finish (gcspyBufferedOutput *output) {
    put_tag(output, end_tag);
    output->write_int(magic_end_tag);
  }

  void execute (gcspyBufferedInput *input, void *aux);
};


#endif //_GCSPY_COMMAND_STREAM_HPP_
