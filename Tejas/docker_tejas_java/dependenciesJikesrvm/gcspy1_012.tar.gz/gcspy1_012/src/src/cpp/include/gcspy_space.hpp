/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  gcspy_space.hpp
 **
 **  Represents a space
 **/

#ifndef _GCSPY_SPACE_HPP_

#define _GCSPY_SPACE_HPP_

#include <stdio.h>
#include "gcspy_stream.hpp"

#define default_unused_string "NOT USED"

class gcspySpace {
private:
  enum PrivateConstants {
    name_len = 48,
    unused_string_len = 48,
    block_info_len = 128,
    max_streams = 24,
    space_info_len = 1024
  };

  unsigned                   _id;
  char                       _name[name_len+1];
  char                       _driver_name[name_len+1];
  gcspy_length_t             _tile_num;
  char                     **_tile_names;
  int                        _stream_num;
  gcspyStream               *_streams[max_streams];
  char                       _unused_string[unused_string_len+1];
  char                       _title[name_len+1];
  char                       _block_info[block_info_len+1];
  gcspy_bool_t               _main_space;

  gcspy_bool_t               _changed;  //TODO: what is this used for?  is set when space is resized

  char                      *_control;
  char                       _space_info[space_info_len+1];

  void setup_arrays (gcspy_length_t old_tile_num);

public:
  enum PublicConstants {
    control_used         =  1,		//Tile is assigned and used.
    control_background   =  2,		//Tile colour is set to that of the background making it "invisable"
    control_unused       =  4,		//Tile is assigned but unused
    control_separator    =  8,		//Places an "I" separator to the Right (TODO: check this) of this tile
    control_link         = 16		//Links tiles with a coloured border. TODO: check.
  };

  gcspySpace (const char       *name,
	      const char       *driver_name,
	      const char       *title,
	      const char       *block_info,
	      gcspy_length_t    tile_num,
	      const char       *unused_string,
	      gcspy_bool_t      main_space);

  /**
   * Sets the id of this space
   * @param		the Id to set to this space
   */
  inline void set_id (unsigned id) {
    _id = id;
  }

  /**
   * @return	returns the id of this space
   */
  inline unsigned get_id () { return _id; }

  /**
   * @return	returns the number of tiles in this space
   */
  inline gcspy_length_t get_tile_num() { return _tile_num; }

  /**
   * TODO: does this return number of streams, or what number stream this is?
   */
  inline gcspy_length_t get_stream_num() { return _stream_num; }

  /**
   * sets a tiles name
   * @param 	index, this index of the tile you wish to rename
   * @name 		a string you want to set the name to
   */
  inline void set_tile_name (gcspy_index_t index, char *name) {
    gcspy_assert(index < _tile_num);
    gcspy_assert(_tile_names[index] == NULL);
    char *str = gcspyUtils::clone_string(name);
    if (str == NULL) {
      char buffer[128];
      sprintf(buffer, "Space[%d]: new failed for tile name %d\n",_id, index);
      gcspy_raise_error(buffer);
    }
    _tile_names[index] = str;
  }

  /**
   * Gets the tile name for a the tile specified
   * @param 	index index of the tile you wish to know the name for
   * @return 	string of tile name
   */
  inline char *get_tile_name (gcspy_index_t index) {
    gcspy_assert(index < _tile_num);
    gcspy_assert(_tile_names[index] != NULL);
    return _tile_names[index];
  }

  /**
   * Returns a pointer to a stream in this space
   * @param index The index of the stream you wish use
   * @return gcspyStream a pointer to the stream
   */
  inline gcspyStream *get_stream (gcspy_index_t index) {
    gcspy_assert(index < _stream_num);
    return _streams[index];
  }

  /**
   * Adds a stream to this space.  Adds a stream to the stream array with the
   * next available index.  This method insures stream_num is correct.
   */
  void add_stream (gcspyStream *stream);

  /**
   * sets the control for each tile in this stream to control_used
   */
  void reset_control (void);

  /**
   * Resets the data, summary and control flags for each stream in this space
   */
  void reset_data (void);

  /**
   *  Serialises this space to the output defined in client
   *  @param client The client to send send the serialised space to
   */
  void serialise (gcspyClient *client);

  /**
   * Serialises this space to the given output.
   * Including serialising each stream
   * @output the output to send the serialised data to.
   */
  void serialise (gcspyBufferedOutput *output);

  /**
   * Resized this space.
   * Nukes old streams and recreated them with new size. TODO: check this is the case.
   * @param tile_num the number of tiles in the new space.
   */
  void resize (gcspy_length_t tile_num);

  /**
   * @return true/1 if space has changed
   */
  inline gcspy_bool_t has_changed () {
    return _changed;
  }

  /**
   * @Depreciated
   * un-sets the changed flag
   */
  inline void unflag_changed () {
    _changed = 0;
  }

  /**
   * Setter for _space_info
   * @param str String value of space, max size is space_info_len
   */
  inline void set_space_info (char *str) {
    gcspyUtils::copy_string(_space_info, str, space_info_len);
  }

  inline char *get_control () {
    return _control;
  }

  /**
   * getter for _space_info
   * @return string of space info
   */
  inline char *get_space_info () {
    return _space_info;
  }

  inline static gcspy_bool_t control_is_used (char val) {
    return (val & control_used) != 0;
  }

  inline static gcspy_bool_t control_is_background (char val) {
    return (val & control_background) != 0;
  }

  inline static gcspy_bool_t control_is_unused (char val) {
    return (val & control_unused) != 0;
  }

  inline static gcspy_bool_t control_is_separator (char val) {
    return (val & control_separator) != 0;
  }

  inline static gcspy_bool_t control_is_link (char val) {
    return (val & control_link) != 0;
  }

  inline void set_control_range (gcspy_index_t start,
				 gcspy_length_t len,
				 char tag) {
    gcspy_index_t end = start + len;
    for (int i = start; i < end; ++i)
      set_control(i, tag);
  }

  inline void set_control (gcspy_index_t index,
			   char tag) {
    if (control_is_background(tag) || control_is_unused(tag))
      if (control_is_used(_control[index]))
	_control[index] &= ~control_used;

    _control[index] |= tag;
  }
};

#endif //_GCSPY_SPACE_HPP_
