/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  gcspy_stream.hpp
 **
 **  Represents a stream
 **/

#ifndef _GCSPY_STREAM_HPP_

#define _GCSPY_STREAM_HPP_

#include "gcspy_color_db.hpp"
#include "gcspy_buffered_output.hpp"

class gcspyStream {
private:
  enum PrivateConstants {
    string_len    = 48,
    enum_max_num  = 10
  };

  unsigned               _id;
  unsigned               _data_type;					//Data type of stream, one of byte_type, short_type, int_type
  char                   _name[string_len+1];			//Name of stream
  int                    _min_value;					//Min value a tile of this stream can hold
  int                    _max_value;					//Max value a tile of this stream can hold
  int                     _zero_value;					//
  int                     _default_value;				//Default value of this stream, used when resetting data
  char                   _string_pre[string_len+1];		//
  char                   _string_post[string_len+1];	//
  unsigned               _presentation;					// Presentation type of summery? TODO: check this.
  unsigned               _paint_style;
  unsigned               _max_stream_index;				//Equivelent to size of stream
  gcspyColor             _color;						//Colour tile is painted in GCSspy client
  unsigned               _enum_num;
  char                 **_enum_names;
  char                  *_data;							//Array where each item is value for a tile
  int                   *_summary;						//Summery of tile

  void setup_summary (void);

public:
  enum PublicConstants {
    /// Presentation enums  TODO: Discribe what each enum is used for.
    presentation_plain = 0,
    presentation_plus,
    presentation_max_var,
    presentation_percent,
    presentation_percent_var,
    presentation_enum,

    /// TODO: describe what paint styles are.
    paint_style_plain = 0,
    paint_style_zero,

    ///Data types for stream.
    byte_type = 0,
    short_type,
    int_type
  };

  /**
   * Constructor for gcspyStream.
   * Sets up class variables and summary.
   */
  gcspyStream (unsigned          data_type,
	       const char       *name,
	       int               min_value,
	       int               max_value,
	       int               zero_value,
	       int               default_value,
	       char             *string_pre,
	       char             *string_post,
	       unsigned          presentation,
	       unsigned          paint_style,
	       unsigned          max_stream_index,
	       gcspyColor       *color,
	       gcspy_bool_t      enable_summary);

  /**
   * @param id id to set this stream to
   */
  inline void set_id (unsigned id) {
    _id = id;
  }

  /**
   * @return id of this stream
   */
  inline int get_id()             { return _id; }

  /**
   * returns the data type of this stream
   * @return one of, byte_type, short_type, int_type
   */
  inline int get_data_type()      { return _data_type; }

  /**
   * Returns a pointer to data.  This method does not check the actual
   * type of data.  To get data as an byte/short/int use the relavent methods
   * below
   * @return a pointer data as a char array.
   */
  inline char *get_data() {    return _data;  }

  /**
   * returns a pointer to data array as a byte type.
   * TODO: Check this is acualy returning a pointer.
   * @return data array
   */
  inline char *get_byte_data() {
    gcspy_assert(_data_type == byte_type);
    return _data;
  }

  /**
   * returns a pointer to data array as a short type.
   * TODO: Check this is acualy returning a pointer.
   * @return data array
   */
  inline short *get_short_data() {
    gcspy_assert(_data_type == short_type);
    return (short *) _data;
  }

  /**
   * returns a pointer to data array as a int type.
   * TODO: Check this is actually returning a pointer.
   * @return data array
   */
  inline int *get_int_data() {
    gcspy_assert(_data_type == int_type);
    return (int *) _data;
  }

  /**
   * @return a pointer to the summary array.
   */
  inline int *get_summary() {
    return _summary;
  }

  /**
   * Gets summery length depending on the presentation type.
   * @return 	presentation_plain, presentation_plus, & presentation_max_var = 1
   * 			presentation_percent, & presentation_percent_var = 2
   * 			presentation_enum = number of enums
   */
  inline gcspy_length_t get_summary_len () {
    switch (_presentation) {
    case presentation_plain:
    case presentation_plus:
    case presentation_max_var:
      return 1;
    case presentation_percent:
    case presentation_percent_var:
      return 2;
    case presentation_enum:
      gcspy_assert(_enum_num > 0);
      return _enum_num;
    default:
      gcspy_assert( 0 );
    }
  }

  /**
   * Adds a enum name
   * TODO: find out what this really does.
   */
  void add_enum_name (gcspy_index_t index, char *name);

  /**
   * Creates correct size arrays of the correct type for the streams data.
   * @param tile_num the numbers of tiles in the stream
   */
  void setup_arrays (gcspy_length_t tile_num);

  /**
   * Resets all values in this streams data to their default values
   * @param tile_num number of tiles in this stream
   */
  void reset_data (gcspy_length_t tile_num);

  /**
   * resets the summery array to all 0s
   */
  void reset_summary (void);

  /**
   * Serialises the stream
   * @param output the output to serialse this stream to.
   */
  void serialise (gcspyBufferedOutput *output);

  /**
   * Increments the value of a tile
   * @param index The index of the tile you wish to increment
   * @param value The amound you wish to increment the tile by.
   */
  void increment (gcspy_index_t index, int value);

  /**
   * @param index the index into data you wish to retreave
   * @return returns the value of data at the index as a byte (char)
   */
  inline
  char getByte(gcspy_index_t index) {
	  return get_byte_data()[index];
  }

  /**
   * @param index the index into data you wish to retreave
   * @return returns the value of data at the index as a byte (char)
   */
  inline
  short getShort(gcspy_index_t index) {
	  return get_short_data()[index];
  }

  /**
   * @param index the index into data you wish to retreave
   * @return returns the value of data at the index as a byte (char)
   */
  inline
  int getint(gcspy_index_t index) {
	  return get_int_data()[index];
  }

  /**
   * Distribute a value across a sequence of tiles. This handles the case
   * when when an object spans two or more tiles and its value is to be
   * attributed to each tile proportionally.
   *
   * @param start the index of the starting tile
   * @param remainder the value left in the starting tile
   * @param blockSize the size of each tile
   * @param value the value to distribute
   */
  void distribute(int start, int remainder, int blockSize, int value);
};

#endif //_GCSPY_STREAM_HPP_
