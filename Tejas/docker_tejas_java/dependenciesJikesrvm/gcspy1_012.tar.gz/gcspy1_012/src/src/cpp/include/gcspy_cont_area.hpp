/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  gcspy_cont_area.hpp
 **
 **  Utilities for manipulating stream data in a contiguous memory area
 **/

#ifndef _GCSPY_CONT_AREA_HPP_

#define _GCSPY_CONT_AREA_HPP_

#include <stdio.h>
#include "gcspy_types.hpp"
#include "gcspy_utils.hpp"
#include "gcspy_space.hpp"

class gcspyContArea {
private:
  char           *_start;
  char           *_end;
  gcspy_size_t    _block_size;
  gcspy_length_t  _block_num;
  gcspy_index_t   _first_index;

  inline gcspy_bool_t is_boundary (char *addr) {
    gcspy_assert(addr_in_range(addr));
    return (((gcspy_size_t) addr % _block_size) == 0);
  }

  inline gcspy_index_t get_index (char *addr) {
    gcspy_assert(addr_in_range(addr));
    return ((gcspy_size_t) addr - (gcspy_size_t) _start) / _block_size;
  }

  inline char *get_addr (gcspy_index_t index) {
    gcspy_assert(index_in_range(index));
    return _start + ((index - _first_index) * _block_size);
  }

public:
  gcspyContArea (char         *start,
		 char         *end,
		 gcspy_index_t first_index,
		 gcspy_size_t  block_size);

  static gcspy_length_t calc_block_num (char *start, char *end,
					gcspy_size_t block_size);

  void set_perc (char *start, char *end, int *array);
  void add_one (char *start, char *end, int *array);
  void add_one (char *addr, int *array);
  void update_enum_asc  (char *addr, int val, char *array);
  void update_enum_desc (char *addr, int val, char *array);
  void setup_range_strings (gcspySpace *space);
  void resize (char *end);

  inline char *get_start ()  { return _start; }
  inline char *get_end ()    { return _end; }

  inline char *generate_range_string (gcspy_index_t index, char *buffer) {
    index -= _first_index;
    char *start = _start + (index * _block_size);
    char *end = _start + ((index+1) * _block_size);
    if (end > _end)
      end = _end;
    sprintf(buffer, "   [%08x-%08x)", start, end);
    return buffer;
  }

  inline gcspy_length_t get_block_num () {
    return _block_num;
  }

  inline gcspy_length_t get_block_size () {
    return _block_size;
  }

  inline gcspy_size_t get_area_size (void) {
    return (gcspy_size_t) _end - (gcspy_size_t) _start;
  }

  inline gcspy_bool_t addr_in_range (char *addr) {
    return (addr >= _start) && (addr < _end);
  }

  inline gcspy_bool_t index_in_range (gcspy_index_t index) {
    return ( (index >= _first_index) &&
	     (index < (_first_index + _block_num)) );
  }

  /* 1 per 128 bytes */
  static inline gcspy_length_t roots_per_block (gcspy_size_t block_size) {
    return block_size / 128;
  }

  /* assume that the min obj size is 16 bytes */
  static inline gcspy_length_t objects_per_block (gcspy_size_t block_size) {
    return block_size / 16;
  }

  /* assume that the min free chunk size is 32 bytes (it should really
     be 16 bytes, but normally we do not have sequential 16-byte free
     chunks, as they would be coalesced; hence 32 bytes refers to a
     16-byte free chunk, followed by a 16-byte object */
  static inline gcspy_length_t free_chunks_per_block (gcspy_size_t block_size) {
    return block_size / 32;
  }

  /* assume that all of the space of each block can be taken up by
     4-byte reference fields */
  static inline gcspy_length_t refs_per_block (gcspy_size_t block_size) {
    return block_size / 4;
  }

};

#endif //_GCSPY_CONT_AREA_HPP_
