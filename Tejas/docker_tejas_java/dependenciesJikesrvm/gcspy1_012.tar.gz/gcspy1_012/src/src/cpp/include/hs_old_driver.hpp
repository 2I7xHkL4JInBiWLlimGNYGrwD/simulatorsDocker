/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  hs_old_driver.hpp
 **
 **  Driver for the HS old generation M&C collector
 **/

#ifndef _HS_OLD_DRIVER_HPP_

#define _HS_OLD_DRIVER_HPP_

#include "hs_mc_driver.hpp"

class hsOldDriver : public hsMCDriver {
private:
  gcspyStream *_direct_alloc_stream;
  int    *_direct_alloc_data;
  int    *_direct_alloc_summary;

  gcspyStream *_promotion_stream;
  int    *_promotion_data;
  int    *_promotion_summary;

  gcspyStream *_refs_to_left_stream;
  int    *_refs_to_left_data;
  int    *_refs_to_left_summary;

  gcspyStream *_refs_to_right_stream;
  int    *_refs_to_right_data;
  int    *_refs_to_right_summary;

  gcspyStream *_refs_to_perm_stream;
  int    *_refs_to_perm_data;
  int    *_refs_to_perm_summary;

protected:
  virtual void retrieve_data_arrays (void);
  virtual void init_summaries (gcspy_size_t area_size);

public:
  hsOldDriver (gcspy_size_t block_size,
	       gcspy_size_t card_size,
	       char *start,
	       char *end);

  inline void set_direct_alloc (char *start, char *end) {
    _area->set_perc(start, end, _direct_alloc_data);
    _direct_alloc_summary[0] += (gcspy_size_t) end - (gcspy_size_t) start;
  }

  inline void set_promotion (char *start, char *end) {
    _area->set_perc(start, end, _promotion_data);
    _promotion_summary[0] += (gcspy_size_t) end - (gcspy_size_t) start;
  }

  inline void add_ref_to_left (char *addr) {
    _area->add_one(addr, _refs_to_left_data);
    _refs_to_left_summary[0] += 1;
  }

  inline void add_ref_to_right (char *addr) {
    _area->add_one(addr, _refs_to_right_data);
    _refs_to_right_summary[0] += 1;
  }

  inline void add_ref_to_perm (char *addr) {
    _area->add_one(addr, _refs_to_perm_data);
    _refs_to_perm_summary[0] += 1;
  }
};

#endif //_HS_OLD_DRIVER_HPP_
