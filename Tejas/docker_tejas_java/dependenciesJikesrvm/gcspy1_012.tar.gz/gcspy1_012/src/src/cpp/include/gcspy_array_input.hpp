/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  gcspy_array_input.hpp
 **
 **  Input from a byte array
 **/

#ifndef _GCSPY_ARRAY_INPUT_HPP_

#define _GCSPY_ARRAY_INPUT_HPP_

#include "gcspy_io.hpp"

class gcspyArrayInput : gcspyIO {

private:
  inline static int base_read (char *buffer) {
    int res;
    res = (int) *buffer;
    if (res < 0)
      res += 256;
    return res;
  }

public:  
  inline static int read_int (char *buffer) {
    int res = 0;

    res = (int) base_read(buffer);
    res <<= 8;
    res |= (int) base_read(buffer+1);
    res <<= 8;
    res |= (int) base_read(buffer+2);
    res <<= 8;
    res |= (int) base_read(buffer+3);

    return res;
  }

};

#endif //_GCSPY_ARRAY_INPUT_HPP_
