/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  gcspy_test_driver.hpp
 **
 **  Simple test driver
 **/

#ifndef _TEST_DRIVER_HPP_

#define _TEST_DRIVER_HPP_

#include "gcspy_space.hpp"

class testDriver : public gcspySpace {
private:
  enum PrivateConstants { 
    used_space_stream = 0,
    card_table_stream,
    object_stream
  };

  gcspyStream *_used_space_stream;
  gcspyStream *_card_table_stream;
  gcspyStream *_object_stream;

  int  *_used_space_data;
  int  *_used_space_summary;
  char *_card_table_data;
  int  *_card_table_summary;
  int  *_object_data;
  int  *_object_summary;

  void setup_tile_names (void);

public:
  enum PublicConstants {
    card_state_dirty = 0,
    card_state_younger,
    card_state_clean
  };

  void reset (gcspy_length_t tile_num);
  void object (gcspy_index_t index);
  void card (gcspy_index_t index, char state);

  testDriver (const char      *name,
	      gcspy_length_t   tile_num,
	      gcspy_bool_t     main_space);
};

#endif //_TEST_DRIVER_HPP_
