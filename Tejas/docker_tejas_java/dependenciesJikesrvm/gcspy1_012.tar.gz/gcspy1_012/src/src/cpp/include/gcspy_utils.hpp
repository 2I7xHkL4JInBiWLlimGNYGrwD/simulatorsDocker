/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  gcspy_utils.hpp
 **
 **  Misc Utilities
 **/

#ifndef _GCSPY_UTILS_HPP_

#define _GCSPY_UTILS_HPP_

#include <time.h>
#include <string.h>
#include "gcspy_types.hpp"

#define GCSPY_ASSERT                     1

#if GCSPY_ASSERT
#define gcspy_assert(_expr) \
do { \
  if (!(_expr)) \
    gcspy_raise_error("assertion failure: "#_expr); \
} while (0)
#else //GCSPY_ASSERT
#define gcspy_assert(_expr)
#endif //GCSPY_ASSERT

#define gcspy_raise_error(_messg) \
do { \
  gcspyUtils::raise_error(__FILE__, __LINE__, (_messg)); \
} while (0)

#define kilobyte_d  ((double) kilobyte)
#define megabyte_d  ((double) megabyte)

class gcspyUtils {

public:
  enum PublicConstants {
    kilobyte = 1024,
    megabyte = ( 1024 * 1024 )
  };

  static void raise_error (const char *file, int line, const char *messg);

  static char *format_size (gcspy_size_t size, char *buffer);
  static char *format_large_number (unsigned int num, char *buffer);

  inline static void copy_string (char *dst,
				  const char *src,
				  gcspy_length_t max_len) {
    gcspy_assert(strlen(src) <= max_len);
    strcpy(dst, src);
  }

  inline static char *clone_string (char *str) {
    gcspy_length_t len = strlen(str);
    char *ret = new char[len+1];
    if (ret != NULL)
      copy_string(ret, str, len);
    return ret;
  }

};

class gcspyTimeDate {

private:
  time_t _time;

public:
  inline gcspyTimeDate (void) { _time = time(NULL); }

  char *format_time (char *buffer);
  char *format_date (char *buffer);
  char *format_time_date (char *buffer);

};

#endif //_GCSPY_UTILS_HPP_
