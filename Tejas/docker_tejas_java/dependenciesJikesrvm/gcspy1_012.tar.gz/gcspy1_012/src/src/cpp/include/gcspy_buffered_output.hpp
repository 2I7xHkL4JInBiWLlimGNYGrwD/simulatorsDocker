/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  gcspy_buffered_output.hpp
 **
 **  Facilities for buffered output
 **/

#ifndef _GCSPY_BUFFERED_OUTPUT_HPP_

#define _GCSPY_BUFFERED_OUTPUT_HPP_

#include "gcspy_types.hpp"
#include "gcspy_io.hpp"
#include "gcspy_color_db.hpp"
#include "gcspy_comm.hpp"

class gcspyBufferedOutput : gcspyIO {

private:
  char *_buffer;
  char *_curr;
  char *_limit;
  gcspyClient *_client;

  void raise_error (void);

  inline void base_write (short v) {
    gcspy_assert(_curr < _limit);
    if (v > 127)
      v -= 256;
    *_curr = (char) v;
    ++_curr;
  }

public:
  inline gcspyBufferedOutput () { }

  inline gcspyBufferedOutput (char *buffer, gcspy_length_t len) {
    _buffer = buffer;
    _limit = _buffer + len;
    _curr = _buffer;
    _client = NULL;
  }

  inline gcspyBufferedOutput (gcspyClient *client) {
    _buffer = client->get_out_buffer();
    _limit = _buffer + client->get_max_len();
    _curr = _buffer;
    _client = client;
  }

  inline gcspy_length_t get_len () {
    return (_curr - _buffer);
  }

  inline void send (void) {
    gcspy_assert(_client != NULL);
    _client->send(get_len());
  }

  inline void close (void) {
    // currently a NOP
  }

  inline void write_boolean (gcspy_bool_t v) {
    if (v)
      write_byte(boolean_true);
    else
      write_byte(boolean_false);
  }

  inline void write_byte (char v) {
    gcspy_assert((_curr + 1) <= _limit);
    base_write((short) v);
  }

  inline void write_ubyte (unsigned char v) {
    gcspy_assert((_curr + 1) <= _limit);
    base_write((short) v);
  }

  inline void write_short (short v) {
    gcspy_assert((_curr + 2) <= _limit);
    base_write(v >> 8);
    base_write(v & low_8_mask);
  }

  inline void write_ushort (unsigned short v) {
    gcspy_assert((_curr + 2) <= _limit);
    base_write(v >> 8);
    base_write(v & low_8_mask);
  }

  inline void write_int (int v) {
    gcspy_assert((_curr + 4) <= _limit);
    base_write(v >> 24);
    base_write((v >> 16) & low_8_mask);
    base_write((v >> 8) & low_8_mask);
    base_write(v & low_8_mask);
  }

  inline void write_string (const char *v) {
    if (v != NULL) {
      const char *curr = v;
      while (*curr != '\0') {
	write_byte(*curr);
	++curr;
      }
    }
    write_byte(string_terminator);
  }

  inline void write_array_len (gcspy_length_t len) {
    write_int(len);
  }

  inline void write_empty_array () {
    write_array_len(0);
  }

  inline void write_byte_array (char *v, gcspy_length_t len) {
    gcspy_assert(v != NULL);
    char *curr = v;
    write_array_len(len);
    for (int i = 0; i < len; ++i) {
      write_byte(*curr);
      ++curr;
    }
  }

  inline void write_ubyte_array (unsigned char *v, gcspy_length_t len) {
    gcspy_assert(v != NULL);
    unsigned char *curr = v;
    write_array_len(len);
    for (int i = 0; i < len; ++i) {
      write_ubyte(*curr);
      ++curr;
    }
  }

  inline void write_short_array (short *v, gcspy_length_t len) {
    gcspy_assert(v != NULL);
    short *curr = v;
    write_array_len(len);
    for (int i = 0; i < len; ++i) {
      write_short(*curr);
      ++curr;
    }
  }

  inline void write_ushort_array (unsigned short *v, gcspy_length_t len) {
    gcspy_assert(v != NULL);
    unsigned short *curr = v;
    write_array_len(len);
    for (int i = 0; i < len; ++i) {
      write_ushort(*curr);
      ++curr;
    }
  }

  inline void write_int_array (int *v, gcspy_length_t len) {
    gcspy_assert(v != NULL);
    int *curr = v;
    write_array_len(len);
    for (int i = 0; i < len; ++i) {
      write_int(*curr);
      ++curr;
    }
  }

  inline void write_color (gcspyColor *color) {
    write_ubyte(color->get_red());
    write_ubyte(color->get_green());
    write_ubyte(color->get_blue());
  }

};

#endif //_GCSPY_BUFFERED_OUTPUT_HPP_
