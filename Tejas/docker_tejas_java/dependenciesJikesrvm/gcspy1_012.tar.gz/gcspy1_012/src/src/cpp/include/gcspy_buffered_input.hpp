/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  gcspy_buffered_input.hpp
 **
 **  Facilities for buffered input
 **/

#ifndef _GCSPY_BUFFERED_INPUT_HPP_

#define _GCSPY_BUFFERED_INPUT_HPP_

#include "gcspy_types.hpp"
#include "gcspy_io.hpp"
#include "gcspy_color_db.hpp"
#include "gcspy_comm.hpp"

class gcspyBufferedInput : gcspyIO {

private:
  char *_buffer;
  char *_curr;
  char *_limit;

  void raise_error (void);

  inline short base_read () {
    gcspy_assert(_curr < _limit);
    short res = (short) *_curr;
    ++_curr;
    if (res < 0)
      res += 256;
    return res;
  }

  inline gcspy_length_t read_array_len () {
    return read_int();
  }

public:
  inline gcspyBufferedInput (char *buffer, gcspy_length_t len) {
    _buffer = buffer;
    _limit = _buffer + len;
    _curr = _buffer;
  }

  inline gcspyBufferedInput (gcspyClient *client) {
    _buffer = client->get_in_buffer();
    _limit = _buffer + client->get_len();
    _curr = _buffer;
  }

  inline gcspy_bool_t has_finished (void) {
    return (_curr == _limit);
  }

  inline void close (void) {
    gcspy_assert(has_finished());
  }

  inline gcspy_bool_t read_boolean (void) {
    return read_byte();
  }

  inline char read_byte (void) {
    gcspy_assert((_curr + 1) <= _limit);
    return (char) base_read();
  }

  inline unsigned char read_ubyte (void) {
    gcspy_assert((_curr + 1) <= _limit);
    return (unsigned char) base_read();
  }

  inline short read_short (void) {
    short res;

    gcspy_assert((_curr + 2) <= _limit);

    res = base_read();
    res <<= 8;
    res |= base_read();

    return res;
  }

  inline unsigned short read_ushort (void) {
    unsigned short res;

    gcspy_assert((_curr + 2) <= _limit);

    res = base_read();
    res <<= 8;
    res |= base_read();

    return res;
  }

  inline int read_int (void) {
    int res;

    gcspy_assert((_curr + 4) <= _limit);

    res = base_read();
    res <<= 8;
    res |= base_read();
    res <<= 8;
    res |= base_read();
    res <<= 8;
    res |= base_read();

    return res;
  }

  inline const char *read_string (char *buffer) {
    char c;
    char *curr = buffer;

    c = read_byte();
    while (c != string_terminator) {
      *curr = c;
      ++curr;
      c = read_byte();
    }
    *curr = '\0';

    return buffer;
  }

  inline char *read_byte_array (char *buffer,
				gcspy_length_t *len) {
    gcspy_length_t length;
    char *curr = buffer;

    length = read_array_len();
    *len = length;
    for (int i = 0; i < length; ++i) {
      *curr = read_byte();
      ++curr;
    }

    return buffer;
  }

  inline unsigned char *read_ubyte_array (unsigned char *buffer,
					  gcspy_length_t *len) {
    gcspy_length_t length;
    unsigned char *curr = buffer;

    length = read_array_len();
    *len = length;
    for (int i = 0; i < length; ++i) {
      *curr = read_ubyte();
      ++curr;
    }

    return buffer;
  }

  inline short *read_short_array (short *buffer,
				  gcspy_length_t *len) {
    gcspy_length_t length;
    short *curr = buffer;

    length = read_array_len();
    *len = length;
    for (int i = 0; i < length; ++i) {
      *curr = read_short();
      ++curr;
    }

    return buffer;
  }

  inline unsigned short *read_ushort_array (unsigned short *buffer,
					    gcspy_length_t *len) {
    gcspy_length_t length;
    unsigned short *curr = buffer;

    length = read_array_len();
    *len = length;
    for (int i = 0; i < length; ++i) {
      *curr = read_ushort();
      ++curr;
    }

    return buffer;
  }

  inline int *read_int_array (int *buffer,
			      gcspy_length_t *len) {
    gcspy_length_t length;
    int *curr = buffer;

    length = read_array_len();
    *len = length;
    for (int i = 0; i < length; ++i) {
      *curr = read_int();
      ++curr;
    }

    return buffer;
  }


  inline gcspyColor *read_color (gcspyColor *color) {
    unsigned char red   = read_ubyte();
    unsigned char green = read_ubyte();
    unsigned char blue  = read_ubyte();

    color->set_red(red);
    color->set_green(green);
    color->set_blue(blue);

    return color;
  }

};

#endif //_GCSPY_BUFFERED_INPUT_HPP_
