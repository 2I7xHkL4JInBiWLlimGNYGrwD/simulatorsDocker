/**
 ** Copyright (c) 2002 Sun Microsystems, Inc.
 **
 ** See the file "license.terms" for information on usage and redistribution
 ** of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 **/

/**
 **  gcspy_array_output.hpp
 **
 **  Output from a byte array
 **/

#ifndef _GCSPY_ARRAY_OUTPUT_HPP_

#define _GCSPY_ARRAY_OUTPUT_HPP_

#include "gcspy_io.hpp"

class gcspyArrayOutput : gcspyIO {

private:
  inline static void base_write (char *buffer, int v) {
    if (v > 127)
      v -= 256;
    *buffer = (char) v;
  }

public:  
  inline static void write_int (char *buffer, int v) {
    base_write(buffer,   (int) (v >> 24));
    base_write(buffer+1, (int) (v >> 16) & low_8_mask);
    base_write(buffer+2, (int) (v >> 8)  & low_8_mask);
    base_write(buffer+3, (int) v         & low_8_mask);
  }

};

#endif //_GCSPY_ARRAY_OUTPUT_HPP_
