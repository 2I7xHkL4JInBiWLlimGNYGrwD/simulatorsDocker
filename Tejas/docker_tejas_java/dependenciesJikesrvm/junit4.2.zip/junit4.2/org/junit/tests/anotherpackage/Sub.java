package org.junit.tests.anotherpackage;

public class Sub extends Super {
	
}
