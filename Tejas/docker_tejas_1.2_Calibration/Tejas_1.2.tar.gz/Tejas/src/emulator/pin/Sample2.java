class Sample2
{
   public static int intMethod(int n) {
       return n*n;
   }

   public static boolean booleanMethod(boolean bool) {
        return !bool;
   }
 }
