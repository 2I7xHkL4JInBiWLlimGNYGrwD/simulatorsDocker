package emulatorinterface.translator.x86.registers;

public class TempRegisterNum {
	public int numTempIntRegister = 0;
	public int numTempFloatRegister = 0;
}
