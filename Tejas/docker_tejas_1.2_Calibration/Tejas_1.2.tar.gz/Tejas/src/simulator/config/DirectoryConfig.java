package config;

public class DirectoryConfig extends CacheConfig {
	
}
