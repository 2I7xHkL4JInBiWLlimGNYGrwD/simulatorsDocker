package config;

public enum EmulatorType {
	pin,
	qemu,
	none
}
