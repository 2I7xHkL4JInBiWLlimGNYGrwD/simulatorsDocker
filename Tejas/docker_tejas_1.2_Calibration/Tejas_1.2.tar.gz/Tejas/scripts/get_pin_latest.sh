wget https://software.intel.com/sites/landingpage/pintool/downloads/pin-3.7-97619-g0d0c92f4f-gcc-linux.tar.gz
tar -xzvf pin-3.7-97619-g0d0c92f4f-gcc-linux.tar.gz
cd pin-3.7-97619-g0d0c92f4f-gcc-linux
pwd
